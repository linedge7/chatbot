import { useState, useEffect } from "react";
import ChatInPut from "./components/ChatInput.jsx";
import ChatMessages from "./components/ChatMessages.jsx";
import responsesObj from "./responsesObj.js";

import "./App.css";
import { Chatbot } from "supersimpledev";

const appUtils = {
  SaveNewMessage(chatMessages) {
    useEffect(() => {
      localStorage.setItem("messages", JSON.stringify(chatMessages));
    }, [chatMessages]);
  },

  loadChatMessages() {
    return JSON.parse(localStorage.getItem("messages"));
  },

  clearChat(setChatmessages){
    localStorage.removeItem('messages');
    setChatmessages([])
  },

  CreateMoreChatbotResponses() {
    useEffect(() => {
      for (let i = 0; i <= responsesObj.length; i++) {
        Chatbot.addResponses(responsesObj[i]);
      }
    }, []);
  },
};
function App() {
  const [chatMessages, setChatmessages] = useState(
    appUtils.loadChatMessages() || [],
  );

  appUtils.SaveNewMessage(chatMessages);
  appUtils.CreateMoreChatbotResponses();
  let clearChat= "Clear chat!"
  return (
    <div className="app-container">
      <title>Chatbot</title>
      {chatMessages.length === 0 ? (
        <p className="title">
          Welcome to the chatbot project! Sent a message using the textbox below
        </p>
      ) : (
        <div>
          <div title="Click to clear chat" onClick={()=>{appUtils.clearChat(setChatmessages)}} className="clear-chat">{clearChat}</div>
          <p className="title">CHATBOT</p>
        </div>
      )}
      <ChatMessages chatMessages={chatMessages} />
      <ChatInPut
        setChatmessages={setChatmessages}
        chatMessages={chatMessages}
      />
    </div>
  );
}

export default App;
