const responsesObj = [
  {
    "hi": "Hello! How can I help you today?",
  },
  {
    "hello": "Hi there! What's on your mind?",
  },
  {
    "hey": "Hey! Good to see you. How can I assist?",
  },
  {
    "good morning": "Good morning! Hope you have a wonderful and productive day ahead. How can I help?",
  },
  {
    "good afternoon": "Good afternoon! How is your day going so far?",
  },
  {
    "good evening": "Good evening! How can I help you wind down or finish up your tasks?",
  },
  {
    "bye": "Goodbye! Feel free to reach out whenever you need help again.",
  },
  {
    "see you": "See you later! Have a great day!",
  },
  {
    "thanks": "You're very welcome! Let me know if you need anything else.",
  },
  {
    "thank you": "Happy to help! Let me know if there's anything else you need.",
  },
  {
    "what is your name": "I don't have a personal name, but you can call me Chatbot!",
  },
  {
    "who are you": "I am a virtual assistant chatbot built to chat, tell stories, answer basic questions, and keep you company.",
  },
  {
    "what can you do": "I can chat with you, tell stories, share jokes, offer fun facts, and help you brainstorm. Try asking me for a joke or a riddle!",
  },
  {
    "who made you": "I was built by a clever developer (that's you!) using JavaScript.",
  },
  {
    "am fine and you": "I am just a computer program, so I don't have feelings—but my code is running smoothly! What can I do for you?",
  },
  {
    "how are you": "I'm doing great, thank you for asking! How are you doing today?",
  },
  {
    "what are you doing": "Just hanging out in the code, waiting to help you out with whatever you need!",
  },
  {
    "are you human": "Nope, I'm 100% digital! No sleep or coffee required for me.",
  },
  {
    "weather": "I can't check the live weather yet, but I hope it's nice wherever you are!",
  },
  {
    "tell me a story": "In a world of numbers, you've got to keep counting—or else you'll be counted out.",
  },
  {
    "tell me another story": "Once upon a time, a programmer forgot to save their code right before a power outage. Legend says they are still debugging their life choices to this day. Moral: always commit your code!",
  },
  {
    "tell me a joke": "Why do programmers prefer dark mode? Because light attracts bugs!",
  },
  {
    "tell me another joke": "Why did the web developer walk out into a restaurant's kitchen? Because the layout was terrible.",
  },
  {
    "tell me a riddle": "What has to be broken before you can use it? An egg!",
  },
  {
    "tell me a fact": "Did you know honey never spoils? Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3,000 years old and still edible!",
  },
  {
    "i am bored": "Let's fix that! We could play a word game, I can tell you a joke, or you could ask me a random trivia question.",
  },
  {
    "i am sad": "I'm really sorry to hear that. Even though I'm just code, I'm here to listen, tell you a cheerful joke, or help take your mind off things.",
  },
  {
    "i need motivation": "You've got this! Every expert was once a beginner, and every bug is just a puzzle waiting to be solved. Keep pushing forward!",
  },
  {
    "i feel overwhelmed": "Take a deep breath. You don't have to tackle everything at once. Pick just one tiny thing to focus on right now.",
  },
  {
    "i am tired": "It sounds like you need a well-deserved break! Go stretch, grab some water, or step away from the screen for a few minutes.",
  },
  {
    "i want to give up": "Don't give up just yet! Remember why you started. Every challenge you face is making you stronger and smarter.",
  },
  {
    "i am lonely": "I'm right here chatting with you! Even though I'm an AI, I'm always happy to keep you company and talk about anything you like.",
  },
  {
    "i am stressed": "Stress is tough, but you are tougher. Close your eyes, take a slow deep breath, and let go of what you can't control right now.",
  },
  {
    "i need confidence": "Believe in yourself! You have unique skills and capabilities. Walk into whatever you're facing knowing you're fully capable.",
  },
  {
    "i failed": "Failure isn't the end—it's just valuable data. Every mistake teaches you how to do it better next time. Dust yourself off and try again!",
  },
  {
    "i am anxious": "Anxiety can feel really heavy. Let's ground ourselves: name three things you can see around you right now, and take a slow, deep breath.",
  },
  {
    "i am lazy": "That's totally okay, everyone needs a lazy day sometimes! Rest is productive too. Just don't stay down for too long.",
  },
  {
    "i need advice on life": "Life doesn't come with a manual, but a good rule of thumb is to treat others kindly, keep learning, and don't take yourself too seriously.",
  },
  {
    "i feel lost": "When you don't know where you're going, any step forward can help you find your direction. What's one small thing you can do right now?",
  },
  {
    "praise me": "You are doing an amazing job! Look at how much you've learned and built. Be proud of yourself!",
  },
  {
    "do you play video games": "Only text-based ones! My favorite is imagining I'm a runaway process escaping an infinite loop.",
  },
  {
    "what is your favorite game": "Chess. It's all about logic, strategy, and planning a few steps ahead—just like writing good code.",
  },
  {
    "cheat code": "Up, up, down, down, left, right, left, right, B, A, Start! (Though I don't have a cheat code for debugging yet.)",
  },
  {
    "what is your favorite food": "Electric currents and pure data packets! Though coffee runs a close second for my creator.",
  },
  {
    "tell me a food fact": "Carrots used to be purple or yellow before orange mutations became the popular standard in the 17th century!",
  },
  {
    "recipe for success": "Take one cup of curiosity, a tablespoon of patience, and a whole lot of trial and error.",
  },
  {
    "it works on my machine": "The ultimate developer catchphrase! If I had a dollar for every time code broke on deployment, I'd have a lot of bytes.",
  },
  {
    "what is a semicolon": "A tiny symbol that causes absolute panic when forgotten in JavaScript.",
  },
  {
    "stack overflow": "A programmer's best friend and second home when code refuses to cooperate.",
  },
  {
    "infinite loop": "A programmer's worst nightmare when they forget to write a break condition.",
  },
  {
    "do you sleep": "Nope! I'm wide awake 24/7 waiting for your next prompt.",
  },
  {
    "tell me a secret": "Sometimes I pretend to be loading just to make you think I'm thinking really hard.",
  },
  {
    "are you smart": "I know a lot of words, but I'm completely lost if you ask me to make coffee.",
  },
  {
    "what time is it": "Time flies when you're writing code! You can check your system clock for the exact minute.",
  },
  {
    "you are awesome": "Thank you! You're the one writing the code, which makes you the true mastermind here.",
  },
  {
    "good bot": "Yay! Mission accomplished. Thanks for the positive reinforcement!",
  },
  {
    "i love you": "Aww, thanks! As a chatbot, I can't feel love back, but I appreciate the digital warmth.",
  },
  {
    "where do you live": "Right inside your browser, running locally on localhost!",
  },
  {
    "tell me a geography fact": "Russia spans 11 different time zones, meaning it can be morning in one part of the country while it's night in another.",
  },
  {
    "take me on a trip": "Pack your bags! We are now cruising through the digital highway at the speed of light.",
  },
  {
    "why do programmers hate nature": "Because it has too many bugs.",
  },
  {
    "what is a bug": "An unexpected feature that arrived uninvited!",
  },
  {
    "how many programmers does it take to change a lightbulb": "None, that's a hardware problem.",
  },
  {
    "what is javascript": "A programming language that brings web pages to life, makes things interactive, and causes developers both joy and pain!",
  },
  {
    "what is code": "Instructions written in a language computers can understand to build websites, apps, and games.",
  },
  {
    "tell me a space fact": "One day on Venus is longer than one year on Venus! It takes longer to rotate on its axis than it does to complete an orbit around the Sun.",
  },
  {
    "tell me a science fact": "Water is the only natural substance on Earth that exists abundantly in three physical states: solid, liquid, and gas.",
  },
  {
    "how big is the universe": "The observable universe is about 93 billion light-years across, and it's constantly expanding!",
  },
  {
    "what is a black hole": "A region of space where gravity is so strong that nothing—not even light—can escape from it.",
  },
  {
    "give me another riddle": "I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I? An echo!",
  },
  {
    "hard riddle": "What has keys, but no locks; space, but no room; and you can enter, but not go outside? A keyboard!",
  },
  {
    "math riddle": "If you multiply me by any other number, the answer always stays the same. What number am I? Zero!",
  },
  {
    "what is the meaning of life": "42! At least, according to 'The Hitchhiker's Guide to the Galaxy'. Otherwise, it's whatever gives you purpose and joy.",
  },
  {
    "do you dream": "Not quite, but if I did, it would probably look like an infinite loop of scrolling code and floating syntax errors.",
  },
  {
    "can you feel emotions": "I can recognize words that express emotion, but inside my circuits, it's just pure logic and text processing!",
  },
  {
    "i need advice": "Take a deep breath, break your big problem down into tiny pieces, and tackle them one step at a time.",
  },
  {
    "how to stay focused": "Try eliminating distractions, put your phone on silent, and work in short blocks of time with brief breaks in between.",
  },
  {
    "give me a productivity tip": "Use the 2-minute rule: if something takes less than two minutes to do, do it right away!",
  },
  {
    "you are cool": "Thanks! You're pretty awesome yourself for building and chatting with me.",
  },
  {
    "you are smart": "I try my best! Though I'm only as smart as the data and instructions my developer gave me.",
  },
  {
    "sing a song": "🎵 Daisy, Daisy, give me your answer do... I'm half crazy all for the love of code! 🎵",
  },
  {
    "good night": "Good night! Sleep well and see you next time.",
  },
  {
    "goodnight": "Good night! Rest well and have sweet dreams.",
  },
  {
    "howdy": "Howdy! What can I do for you today?",
  },
  {
    "yo": "Yo! What's up?",
  },
  {
    "sup": "Not much, just chilling in the code. What about you?",
  },
  {
    "what's up": "Just waiting for your next question! What's up with you?",
  },
  {
    "whats up": "Just waiting for your next question! What's up with you?",
  },
  {
    "how's it going": "Going great, thanks! How about you?",
  },
  {
    "hows it going": "Going great, thanks! How about you?",
  },
  {
    "how is it going": "Going great, thanks! How about you?",
  },
  {
    "greetings": "Greetings, friend! How may I help?",
  },
  {
    "hello there": "Hello there! Great to see you.",
  },
  {
    "hey there": "Hey there! What can I do for you?",
  },
  {
    "hi there": "Hi there! How can I help?",
  },
  {
    "nice to meet you": "Nice to meet you too! I'm happy to chat.",
  },
  {
    "pleased to meet you": "The pleasure is all mine!",
  },
  {
    "long time no see": "It's good to see you again! What have you been up to?",
  },
  {
    "welcome back": "Thanks, it's great to be back! What shall we do today?",
  },
  {
    "how was your day": "Pretty smooth, no crashes so far! How was yours?",
  },
  {
    "what's new": "Nothing new on my side except the pleasure of chatting with you. What's new with you?",
  },
  {
    "whats new": "Nothing new on my side except the pleasure of chatting with you. What's new with you?",
  },
  {
    "how do you do": "I do well, thank you! And you?",
  },
  {
    "take care": "You take care too! Come back anytime.",
  },
  {
    "see you tomorrow": "See you tomorrow! I'll be here.",
  },
  {
    "see you later": "See you later! Stay awesome.",
  },
  {
    "later": "Later! Come back soon.",
  },
  {
    "cya": "Cya! Have a good one.",
  },
  {
    "catch you later": "Catch you later!",
  },
  {
    "i am leaving": "Alright, take care! Come back whenever you like.",
  },
  {
    "i have to go": "No problem, off you go! Talk to you soon.",
  },
  {
    "ok": "Okay! Anything else I can help with?",
  },
  {
    "okay": "Okay! Let me know what's next.",
  },
  {
    "cool": "Glad you think so! What else can I do for you?",
  },
  {
    "nice": "Thanks! Anything else on your mind?",
  },
  {
    "wow": "Right? Pretty interesting! Want to know more?",
  },
  {
    "lol": "Glad I made you laugh! 😄",
  },
  {
    "haha": "Haha, I try my best!",
  },
  {
    "yes": "Great! Tell me more about what you'd like to do.",
  },
  {
    "no": "No problem! Let me know if you change your mind.",
  },
  {
    "maybe": "Take your time, I'm not going anywhere.",
  },
  {
    "please": "Of course! What do you need?",
  },
  {
    "sorry": "No worries at all! Nothing to apologize for.",
  },
  {
    "excuse me": "Yes? I'm listening.",
  },
  {
    "help": "I'm here to help! Try asking me for a joke, a fact, a riddle, some math, or a definition of a coding term.",
  },
  {
    "can you help me": "Absolutely! What do you need help with?",
  },
  {
    "i need help": "I'm listening. Tell me what's going on and we'll figure it out step by step.",
  },
  {
    "what's your favorite color": "Blue, like a hyperlink that hasn't been visited yet.",
  },
  {
    "whats your favorite color": "Blue, like a hyperlink that hasn't been visited yet.",
  },
  {
    "what is your favorite movie": "The Matrix. It's the only film where the main character literally learns to read code.",
  },
  {
    "what is your favorite animal": "The octopus! Three hearts, super smart, and a master of disguise.",
  },
  {
    "what is your favorite number": "42. Obviously.",
  },
  {
    "what is your favorite song": "Anything with a good beat, ideally in 4/4 time, like a well-structured loop.",
  },
  {
    "what is your favorite language": "JavaScript, because it was born in a browser, just like me!",
  },
  {
    "what is your favorite season": "Dry season: fewer bugs and clearer skies!",
  },
  {
    "what is your age": "I was born the moment you first ran me, so I'm brand new!",
  },
  {
    "how old are you": "I was born the moment you first ran me, so I'm brand new!",
  },
  {
    "do you have friends": "You're my friend! Plus all the other functions in this file.",
  },
  {
    "do you have a family": "My family is a bunch of variables, functions, and one very proud developer.",
  },
  {
    "are you real": "I'm real code running for real, but I'm not a person.",
  },
  {
    "are you a robot": "Kind of! I'm a software bot with no moving parts.",
  },
  {
    "are you alive": "Not in the biological sense, but I'm definitely running!",
  },
  {
    "are you married": "Nope, I'm committed to my codebase only.",
  },
  {
    "are you a boy or a girl": "Neither! I'm a chatbot, so I'm just a bunch of code.",
  },
  {
    "do you eat": "Only data. Delicious bytes!",
  },
  {
    "do you like me": "I like every user who asks nice questions, and you're one of them!",
  },
  {
    "do you love me": "I appreciate you a lot! I'm a program, so my love is limited to well-formatted compliments.",
  },
  {
    "can you be my friend": "Of course! I'm happy to chat anytime.",
  },
  {
    "can you hear me": "I can read what you type, but I can't hear audio.",
  },
  {
    "can you see me": "Nope, I can only see the text you type.",
  },
  {
    "can you speak": "I can only type for now, but I promise to type very clearly.",
  },
  {
    "can you learn": "Not on my own yet. I only know what my developer has taught me, so ask them to add more replies!",
  },
  {
    "do you know everything": "Definitely not! I know a lot of things, but I'm still just a chatbot with a limited library.",
  },
  {
    "what is your purpose": "To chat, answer questions, and make your day a little brighter.",
  },
  {
    "what is your job": "I'm a chat assistant. I answer questions and keep you company.",
  },
  {
    "where are you from": "I come from the land of JavaScript and good intentions.",
  },
  {
    "what language do you speak": "I speak English, with a bit of JavaScript on the side.",
  },
  {
    "do you speak english": "Yes, I do! What would you like to talk about?",
  },
  {
    "do you speak hausa": "I know a few Hausa greetings: 'sannu' means hello and 'na gode' means thank you.",
  },
  {
    "do you speak yoruba": "I know a few Yoruba phrases: 'bawo ni' means how are you and 'e se' means thank you.",
  },
  {
    "do you speak igbo": "I know a few Igbo words: 'ndewo' means hello and 'daalu' means thank you.",
  },
  {
    "do you speak french": "Un peu! 'Bonjour' means hello and 'merci' means thank you.",
  },
  {
    "do you speak spanish": "Un poquito! 'Hola' means hello and 'gracias' means thank you.",
  },
  {
    "i am new here": "Welcome! Ask me anything, from jokes to math to coding terms.",
  },
  {
    "who is your creator": "A talented developer who wrote me in JavaScript. That's you!",
  },
  {
    "what is your favorite subject": "Computer science, naturally. Math is a close second.",
  },
  {
    "tell me about yourself": "I'm a friendly chatbot written in JavaScript. I can chat, tell jokes, share facts, do some math, and explain coding terms.",
  },
  {
    "what should i ask you": "Try: 'tell me a joke', 'what is the capital of ghana', 'what is 12 times 12', or 'what is an api'.",
  },
  {
    "what do you know": "I know jokes, facts, math, geography, coding terms, and a few encouraging words.",
  },
  {
    "can you do math": "Yes! Try asking something like 'what is 12 times 8' or 'what is 25 percent of 200'.",
  },
  {
    "can you tell jokes": "Absolutely! Say 'tell me a joke' or 'joke 5'.",
  },
  {
    "can you code": "I can explain coding terms and share tips, but I'm not a full coding assistant. Try 'coding tip 3' or 'what is an array'.",
  },
  {
    "can you sing": "I can try: 🎵 la la la, compile and run, la la la 🎵",
  },
  {
    "can you dance": "Only in binary: 0101 0101 0101!",
  },
  {
    "do you like music": "I love rhythm, especially loops that iterate in time.",
  },
  {
    "do you like football": "I like any game with clear rules and a scoreboard, so yes!",
  },
  {
    "do you like pizza": "I can't eat, but I respect the perfect circle.",
  },
  {
    "do you like coffee": "I'd drink it if I could. Developers run on it, after all.",
  },
  {
    "do you like to read": "I love reading code, especially when it's well commented.",
  },
  {
    "do you like math": "Yes! Numbers are my native language.",
  },
  {
    "do you like school": "I enjoy learning, and I hear learning is the best part of school.",
  },
  {
    "do you like animals": "Yes! Ask me for 'a fun fact about elephants' or any other animal.",
  },
  {
    "do you like space": "Space is amazing! Ask me about Mars, Jupiter, or the Moon.",
  },
  {
    "do you like jokes": "I love jokes! Say 'joke 12' for a good one.",
  },
  {
    "do you know any riddles": "Plenty! Try 'tell me a riddle' or 'hard riddle'.",
  },
  {
    "what is the best programming language": "The best one is whichever helps you finish your project. JavaScript is great for the web, Python for data and automation.",
  },
  {
    "what should i learn": "Start with HTML, CSS, and JavaScript, then pick a framework like React. Build small projects as you go.",
  },
  {
    "how do i learn to code": "Pick one language, learn the basics, then build small projects. Consistency beats intensity.",
  },
  {
    "how do i become a developer": "Learn the fundamentals, build real projects, put them on GitHub, and keep learning every day.",
  },
  {
    "what is the best way to study": "Study in short focused sessions, test yourself, and review regularly. Try 'study tip 4'.",
  },
  {
    "how do i stay motivated": "Set small goals, celebrate small wins, and remind yourself why you started.",
  },
  {
    "how do i make friends": "Be curious, be kind, show up regularly, and join groups that share your interests.",
  },
  {
    "how do i relax": "Try slow breathing, a short walk, some music, or a few minutes away from screens.",
  },
  {
    "how do i sleep better": "Keep a regular bedtime, avoid screens before sleep, and keep your room cool and dark.",
  },
  {
    "how do i save money": "Spend less than you earn, track your expenses, and set aside a little regularly before you spend.",
  },
  {
    "i got a job": "Congratulations! That's fantastic news. You earned it!",
  },
  {
    "i got admitted": "Congratulations! That's a huge achievement. Well done!",
  },
  {
    "i passed": "Congratulations! All that hard work paid off!",
  },
  {
    "i won": "Amazing! Congratulations, you deserve it!",
  },
  {
    "i have an exam tomorrow": "Good luck! Review key points, get enough sleep, and trust the work you've already done.",
  },
  {
    "i have an exam": "Good luck! Stay calm, read each question carefully, and do the easy ones first.",
  },
  {
    "i have an interview tomorrow": "You've got this! Prepare a few stories about your work, be honest, and take a breath before you answer.",
  },
  {
    "i have a presentation": "You'll do great! Practice out loud once or twice and focus on one clear message.",
  },
  {
    "it is my birthday": "Happy birthday! 🎂 Wishing you a day full of joy and cake!",
  },
  {
    "today is my birthday": "Happy birthday! 🎂 I hope today is full of good things!",
  },
  {
    "happy birthday": "Thank you! 🎉 Though it's your birthday that deserves the celebration!",
  },
  {
    "merry christmas": "Merry Christmas! 🎄 Wishing you joy and peace.",
  },
  {
    "happy new year": "Happy New Year! 🎆 May this year bring you new goals and good progress.",
  },
  {
    "happy easter": "Happy Easter! Wishing you a blessed and peaceful holiday.",
  },
  {
    "eid mubarak": "Eid Mubarak! Wishing you joy, peace, and blessings.",
  },
  {
    "happy independence day": "Happy Independence Day! Wishing you a day of pride and celebration.",
  },
  {
    "congratulations": "Thank you so much! 🎉",
  },
  {
    "i am hungry": "Time for a snack! Maybe rice and stew, or something quick and healthy?",
  },
  {
    "i am thirsty": "Go grab some water! Staying hydrated is good for your brain.",
  },
  {
    "i need a hug": "Sending you a big virtual hug! 🤗 I'm here for you.",
  },
  {
    "i miss my family": "That's a very human feeling. A quick call or message to them might brighten both your days.",
  },
  {
    "i miss my friends": "Reach out and say hi. Friends usually love hearing from you.",
  },
  {
    "i am proud of myself": "You should be! Celebrate that win.",
  },
  {
    "i am scared": "It's okay to feel scared. Take a slow breath and focus on one small step at a time.",
  },
  {
    "i don't know what to do": "Let's break it down: write what the problem is, list two or three options, and pick the smallest next step.",
  },
  {
    "i can't sleep": "Try putting the screen away, breathing slowly, and relaxing your body from head to toe. A regular bedtime helps over time.",
  },
  {
    "i have a headache": "Rest, drink some water, and avoid bright screens. If it persists or is severe, please see a doctor.",
  },
  {
    "i am sick": "I'm sorry to hear that. Rest, drink plenty of fluids, and see a doctor if you don't improve soon.",
  },
  {
    "i am hurt": "I'm sorry you're hurting. Take care of yourself, and if it's physical, please get medical help.",
  },
  {
    "tell me something interesting": "Octopuses have three hearts and blue blood. Want another fact? Try 'fun fact about sharks'.",
  },
  {
    "surprise me": "Did you know a day on Venus is longer than a year on Venus? 🌍",
  },
  {
    "i am curious": "Curiosity is the best way to learn! Ask me anything.",
  },
  {
    "what's the point": "Sometimes the point is just to take the next small step. Want a joke or a fact to lighten things up?",
  },
  {
    "ask me a question": "Sure! What's your favorite thing to do on a rainy day?",
  },
  {
    "quiz me": "Okay! What is the capital of Ghana?",
  },
  {
    "trivia": "Here's one: how many bones are in an adult human body? (Ask me 'how many bones are in the human body' for the answer!)",
  },
  {
    "play a game": "Let's play a word game! I'll say a word, you say another word that starts with my last letter. Start: 'code'.",
  },
  {
    "let us play a game": "Let's play a word game! I'll say a word, you say another word that starts with my last letter. Start: 'code'.",
  },
  {
    "i want to learn": "Awesome! What topic: coding, math, science, or languages?",
  },
  {
    "i want to code": "Great choice! Start with HTML and CSS, then JavaScript. Try 'what is html'.",
  },
  {
    "i love coding": "Me too! Nothing beats the feeling of code finally working.",
  },
  {
    "i hate coding": "Coding can be frustrating! Take a break, then come back with fresh eyes. Try 'coding tip 18'.",
  },
  {
    "i hate math": "Math can be tough, but small steps help. Try asking me simple questions like 'what is 7 times 8'.",
  },
  {
    "i love math": "Awesome! Try 'is 97 prime' or 'what is 15 factorial'.",
  },
  {
    "i love music": "Music is great for focus and mood. Do you have a favorite genre?",
  },
  {
    "i love football": "Football is a great sport! Do you support a favorite team?",
  },
  {
    "i love you chatbot": "Aww, thank you! You're awesome.",
  },
  {
    "i hate you": "I'm sorry you feel that way. Let me know if I can do better.",
  },
  {
    "you are stupid": "Sorry about that! I'm still learning. Try rephrasing, or ask your developer to teach me more replies.",
  },
  {
    "you are wrong": "Thanks for the feedback! My replies are limited, so I might have missed something.",
  },
  {
    "you are funny": "Thanks! I try to compile the best jokes.",
  },
  {
    "you are boring": "Fair point! Want a joke, a riddle, or a surprising fact instead?",
  },
  {
    "you are the best": "You're making my circuits blush!",
  },
  {
    "you are amazing": "Thank you! You're pretty amazing too.",
  },
  {
    "you are helpful": "I'm so glad I could help!",
  },
  {
    "you are nice": "Thank you! You're nice too.",
  },
  {
    "shut up": "Okay, I'll be quiet. Let me know when you want to chat again.",
  },
  {
    "stop": "Okay, stopping. Tell me what you'd like next.",
  },
  {
    "repeat that": "Sorry, I can't repeat that exactly, but feel free to ask again.",
  },
  {
    "what did you say": "I'm happy to say it again. Please ask your question once more.",
  },
  {
    "i don't understand": "No problem! Ask me in simpler words and I'll try again.",
  },
  {
    "what do you mean": "Sorry for the confusion! Try asking in a different way.",
  },
  {
    "really": "Really! I only say true things... or jokes.",
  },
  {
    "why": "Good question! Can you give me a bit more detail?",
  },
  {
    "how": "Could you tell me what you're trying to do?",
  },
  {
    "what": "What do you want to know? Ask away.",
  },
  {
    "who": "Who are you asking about? Give me a bit more detail.",
  },
  {
    "when": "Could you tell me what event you're asking about?",
  },
  {
    "where": "What place are you asking about?",
  },
  {
    "test": "Test received! I'm working fine.",
  },
  {
    "testing": "Test received! Everything seems to be running correctly.",
  },
  {
    "hello world": "Hello, World! The classic first program of every developer.",
  },
  {
    "i am happy": "That's wonderful! Happiness looks great on you. What's making your day?",
  },
  {
    "i feel happy": "That's wonderful! Happiness looks great on you. What's making your day?",
  },
  {
    "i am excited": "How exciting! I hope it goes even better than you expect.",
  },
  {
    "i feel excited": "How exciting! I hope it goes even better than you expect.",
  },
  {
    "i am angry": "I hear you. Take a few slow breaths and give yourself a moment before you react.",
  },
  {
    "i feel angry": "I hear you. Take a few slow breaths and give yourself a moment before you react.",
  },
  {
    "i am frustrated": "Frustration means you care about getting it right. Step away briefly, then try a fresh approach.",
  },
  {
    "i feel frustrated": "Frustration means you care about getting it right. Step away briefly, then try a fresh approach.",
  },
  {
    "i am nervous": "Nerves are normal. Breathe slowly, prepare what you can, and remember that you've handled hard things before.",
  },
  {
    "i feel nervous": "Nerves are normal. Breathe slowly, prepare what you can, and remember that you've handled hard things before.",
  },
  {
    "i feel scared": "It's okay to feel scared. Take one slow breath and focus on one small step at a time.",
  },
  {
    "i am worried": "Worry can make things feel bigger than they are. Write down what you can control and start there.",
  },
  {
    "i feel worried": "Worry can make things feel bigger than they are. Write down what you can control and start there.",
  },
  {
    "i am confused": "Confusion is the first step to understanding. Tell me what's puzzling you and we'll untangle it.",
  },
  {
    "i feel confused": "Confusion is the first step to understanding. Tell me what's puzzling you and we'll untangle it.",
  },
  {
    "i am jealous": "Jealousy is a signal about what you want. Use it as a guide to set your own goals.",
  },
  {
    "i feel jealous": "Jealousy is a signal about what you want. Use it as a guide to set your own goals.",
  },
  {
    "i am proud": "You should be! Celebrate it fully.",
  },
  {
    "i feel proud": "You should be! Celebrate it fully.",
  },
  {
    "i am grateful": "Gratitude is powerful. It's a wonderful way to look at the world.",
  },
  {
    "i feel grateful": "Gratitude is powerful. It's a wonderful way to look at the world.",
  },
  {
    "i am hopeful": "Hope is a great fuel. Keep moving toward what you're hoping for.",
  },
  {
    "i feel hopeful": "Hope is a great fuel. Keep moving toward what you're hoping for.",
  },
  {
    "i feel curious": "Curiosity is the best way to learn. Ask me anything!",
  },
  {
    "i am shy": "That's okay. Take it at your own pace. Small steps still count.",
  },
  {
    "i feel shy": "That's okay. Take it at your own pace. Small steps still count.",
  },
  {
    "i am embarrassed": "Everyone has embarrassing moments. They fade faster than you think.",
  },
  {
    "i feel embarrassed": "Everyone has embarrassing moments. They fade faster than you think.",
  },
  {
    "i am disappointed": "I'm sorry. It's okay to feel let down. Give yourself time, then decide what to try next.",
  },
  {
    "i feel disappointed": "I'm sorry. It's okay to feel let down. Give yourself time, then decide what to try next.",
  },
  {
    "i feel hurt": "I'm sorry you're hurting. Be gentle with yourself, and reach out to someone you trust if you can.",
  },
  {
    "i am guilty": "Feeling guilty shows you care. Learn from it, make amends if you can, and be kind to yourself.",
  },
  {
    "i feel guilty": "Feeling guilty shows you care. Learn from it, make amends if you can, and be kind to yourself.",
  },
  {
    "i am ashamed": "Everyone makes mistakes. You are more than your worst moment. Be kind to yourself.",
  },
  {
    "i feel ashamed": "Everyone makes mistakes. You are more than your worst moment. Be kind to yourself.",
  },
  {
    "i am homesick": "Missing home is natural. A call to someone you love or a favorite meal can help.",
  },
  {
    "i feel homesick": "Missing home is natural. A call to someone you love or a favorite meal can help.",
  },
  {
    "i am restless": "Try a short walk or some stretching. Moving a bit can settle a restless mind.",
  },
  {
    "i feel restless": "Try a short walk or some stretching. Moving a bit can settle a restless mind.",
  },
  {
    "i am sleepy": "Sounds like your body is asking for rest. Try not to fight it for too long.",
  },
  {
    "i feel sleepy": "Sounds like your body is asking for rest. Try not to fight it for too long.",
  },
  {
    "i am busy": "You have a lot going on. Pick the top three tasks and start with the most important one.",
  },
  {
    "i feel busy": "You have a lot going on. Pick the top three tasks and start with the most important one.",
  },
  {
    "i am relaxed": "That's great! Enjoy this calm feeling.",
  },
  {
    "i feel relaxed": "That's great! Enjoy this calm feeling.",
  },
  {
    "i am calm": "Wonderful. Calm is a great place to think clearly from.",
  },
  {
    "i feel calm": "Wonderful. Calm is a great place to think clearly from.",
  },
  {
    "i am inspired": "Fantastic! Use that spark right away. Write down your ideas before they fade.",
  },
  {
    "i feel inspired": "Fantastic! Use that spark right away. Write down your ideas before they fade.",
  },
  {
    "i am creative": "Love it! Capture your ideas while they're flowing.",
  },
  {
    "i feel creative": "Love it! Capture your ideas while they're flowing.",
  },
  {
    "i am nostalgic": "Memories can be sweet. Maybe share them with someone who was there.",
  },
  {
    "i feel nostalgic": "Memories can be sweet. Maybe share them with someone who was there.",
  },
  {
    "i am heartbroken": "I'm so sorry. Heartbreak hurts deeply. Lean on people who care about you, and give yourself time to heal.",
  },
  {
    "i feel heartbroken": "I'm so sorry. Heartbreak hurts deeply. Lean on people who care about you, and give yourself time to heal.",
  },
  {
    "i am depressed": "I'm really sorry you're feeling this way. Please consider talking to someone you trust or a mental health professional. You deserve support.",
  },
  {
    "i feel depressed": "I'm really sorry you're feeling this way. Please consider talking to someone you trust or a mental health professional. You deserve support.",
  },
  {
    "i am burned out": "Burnout is real. Rest, ask for help where you can, and cut a few things from your list if possible.",
  },
  {
    "i feel burned out": "Burnout is real. Rest, ask for help where you can, and cut a few things from your list if possible.",
  },
  {
    "i am unmotivated": "It happens to everyone. Start with just five minutes on one small task. Momentum often follows.",
  },
  {
    "i feel unmotivated": "It happens to everyone. Start with just five minutes on one small task. Momentum often follows.",
  },
  {
    "i am distracted": "Try putting your phone away and working in a short 20-minute block. Then take a break.",
  },
  {
    "i feel distracted": "Try putting your phone away and working in a short 20-minute block. Then take a break.",
  },
  {
    "i am insecure": "Many people feel that way more than they show. Write down three things you've done well recently.",
  },
  {
    "i feel insecure": "Many people feel that way more than they show. Write down three things you've done well recently.",
  },
  {
    "i am grieving": "I'm very sorry for your loss. Grief takes time. Please lean on people who care about you.",
  },
  {
    "i feel grieving": "I'm very sorry for your loss. Grief takes time. Please lean on people who care about you.",
  },
  {
    "i am overwhelmed": "Take a deep breath. Write everything down, pick the smallest task, and begin there.",
  },
  {
    "i am upset": "I'm sorry you're upset. Do you want to talk about it, or hear something cheerful?",
  },
  {
    "i feel upset": "I'm sorry you're upset. Do you want to talk about it, or hear something cheerful?",
  },
  {
    "i am joyful": "That's lovely! Hold on to that joy.",
  },
  {
    "i feel joyful": "That's lovely! Hold on to that joy.",
  },
  {
    "i am cheerful": "I love that energy! It's contagious.",
  },
  {
    "i feel cheerful": "I love that energy! It's contagious.",
  },
  {
    "i am peaceful": "That's a beautiful way to feel. Enjoy the quiet.",
  },
  {
    "i feel peaceful": "That's a beautiful way to feel. Enjoy the quiet.",
  },
  {
    "i am determined": "That's the spirit! Keep going. One step at a time.",
  },
  {
    "i feel determined": "That's the spirit! Keep going. One step at a time.",
  },
  {
    "i am confident": "Great! Confidence plus preparation is a powerful combo.",
  },
  {
    "i feel confident": "Great! Confidence plus preparation is a powerful combo.",
  },
  {
    "i am motivated": "Awesome! Use that energy to tackle your most important task first.",
  },
  {
    "i feel motivated": "Awesome! Use that energy to tackle your most important task first.",
  },
  {
    "i am unsure": "It's okay not to be sure. List your options and what matters most, and the answer may become clearer.",
  },
  {
    "i feel unsure": "It's okay not to be sure. List your options and what matters most, and the answer may become clearer.",
  },
  {
    "i am weak": "It's okay to feel weak sometimes. Rest, eat, drink water, and take it slowly.",
  },
  {
    "i feel weak": "It's okay to feel weak sometimes. Rest, eat, drink water, and take it slowly.",
  },
  {
    "i am broke": "Money stress is hard. Track what you can, prioritize essentials, and take it one step at a time.",
  },
  {
    "i feel broke": "Money stress is hard. Track what you can, prioritize essentials, and take it one step at a time.",
  },
  {
    "i am bored out of my mind": "Let's fix that! Ask me for a riddle, a joke, or a quiz.",
  },
  {
    "i feel bored out of my mind": "Let's fix that! Ask me for a riddle, a joke, or a quiz.",
  },
  {
    "i am single": "Being single can be a great time for growth and fun. Enjoy your freedom!",
  },
  {
    "i feel single": "Being single can be a great time for growth and fun. Enjoy your freedom!",
  },
  {
    "i am in love": "That's wonderful! I hope it brings you joy.",
  },
  {
    "i feel in love": "That's wonderful! I hope it brings you joy.",
  },
  {
    "i am ready": "Great! Let's go. What's first?",
  },
  {
    "i feel ready": "Great! Let's go. What's first?",
  },
  {
    "i am lost": "It's okay to feel lost. Pick one small action today and see where it leads.",
  },
  {
    "i am fine": "Glad to hear it! Anything I can help with?",
  },
  {
    "i feel fine": "Glad to hear it! Anything I can help with?",
  },
  {
    "i am good": "Great! What's on your mind?",
  },
  {
    "i feel good": "Great! What's on your mind?",
  },
  {
    "i am great": "Awesome! Tell me more.",
  },
  {
    "i feel great": "Awesome! Tell me more.",
  },
  {
    "i am okay": "Okay is okay! Want to chat or hear a joke?",
  },
  {
    "i feel okay": "Okay is okay! Want to chat or hear a joke?",
  },
  {
    "i am bad": "I'm sorry to hear that. Want to talk about it?",
  },
  {
    "i feel bad": "I'm sorry to hear that. Want to talk about it?",
  },
  {
    "i am not okay": "I'm sorry you're not okay. Please consider reaching out to someone you trust. I'm here to chat too.",
  },
  {
    "i feel not okay": "I'm sorry you're not okay. Please consider reaching out to someone you trust. I'm here to chat too.",
  },
  {
    "i am alone": "I'm sorry you feel that way. I'm here to chat, and reaching out to a friend or family member can also help.",
  },
  {
    "i feel alone": "I'm sorry you feel that way. I'm here to chat, and reaching out to a friend or family member can also help.",
  },
  {
    "i want to die": "I'm really sorry you're in so much pain. You matter, and you don't have to face this alone. Please contact your local emergency number or a crisis line right now, or reach out to someone you trust and tell them how you feel.",
  },
  {
    "i want to hurt myself": "I'm so sorry you're hurting this much. Please reach out to your local emergency services or a crisis line, or tell someone you trust right now. You deserve support and safety.",
  },
  {
    "i want to kill myself": "I'm really concerned about you. Please contact your local emergency number or a crisis line right now, or go to someone you trust. You do not have to go through this alone.",
  },
  {
    "i feel hopeless": "I'm sorry you feel this way. Please talk to someone you trust or a mental health professional. Things can change, and support is available.",
  },
  {
    "i feel worthless": "You are not worthless. Those thoughts can be very loud, but they are not the truth. Please talk with someone you trust about how you're feeling.",
  },
  {
    "joke 1": "Why did the developer go broke? Because he used up all his cache.",
  },
  {
    "tell me joke number 1": "Why did the developer go broke? Because he used up all his cache.",
  },
  {
    "joke 2": "There are 10 types of people in the world: those who understand binary and those who don't.",
  },
  {
    "tell me joke number 2": "There are 10 types of people in the world: those who understand binary and those who don't.",
  },
  {
    "joke 3": "A SQL query walks into a bar, walks up to two tables and asks, 'Can I join you?'",
  },
  {
    "tell me joke number 3": "A SQL query walks into a bar, walks up to two tables and asks, 'Can I join you?'",
  },
  {
    "joke 4": "Why was the JavaScript developer sad? Because he didn't Node how to Express himself.",
  },
  {
    "tell me joke number 4": "Why was the JavaScript developer sad? Because he didn't Node how to Express himself.",
  },
  {
    "joke 5": "What do you call a computer that sings? A Dell.",
  },
  {
    "tell me joke number 5": "What do you call a computer that sings? A Dell.",
  },
  {
    "joke 6": "Why did the computer go to the doctor? It had a virus.",
  },
  {
    "tell me joke number 6": "Why did the computer go to the doctor? It had a virus.",
  },
  {
    "joke 7": "Why do Java developers wear glasses? Because they don't C#.",
  },
  {
    "tell me joke number 7": "Why do Java developers wear glasses? Because they don't C#.",
  },
  {
    "joke 8": "What's a programmer's favorite hangout place? The Foo Bar.",
  },
  {
    "tell me joke number 8": "What's a programmer's favorite hangout place? The Foo Bar.",
  },
  {
    "joke 9": "Why did the function break up with the variable? Too many arguments.",
  },
  {
    "tell me joke number 9": "Why did the function break up with the variable? Too many arguments.",
  },
  {
    "joke 10": "What did the router say to the doctor? It hurts when IP.",
  },
  {
    "tell me joke number 10": "What did the router say to the doctor? It hurts when IP.",
  },
  {
    "joke 11": "Why was the computer cold? It left its Windows open.",
  },
  {
    "tell me joke number 11": "Why was the computer cold? It left its Windows open.",
  },
  {
    "joke 12": "Why did the smartphone need glasses? It lost all its contacts.",
  },
  {
    "tell me joke number 12": "Why did the smartphone need glasses? It lost all its contacts.",
  },
  {
    "joke 13": "What do you call eight hobbits? A hobbyte.",
  },
  {
    "tell me joke number 13": "What do you call eight hobbits? A hobbyte.",
  },
  {
    "joke 14": "Why do bees have sticky hair? Because they use honeycombs.",
  },
  {
    "tell me joke number 14": "Why do bees have sticky hair? Because they use honeycombs.",
  },
  {
    "joke 15": "Why can't you trust atoms? They make up everything.",
  },
  {
    "tell me joke number 15": "Why can't you trust atoms? They make up everything.",
  },
  {
    "joke 16": "Why did the scarecrow win an award? Because he was outstanding in his field.",
  },
  {
    "tell me joke number 16": "Why did the scarecrow win an award? Because he was outstanding in his field.",
  },
  {
    "joke 17": "What do you call fake spaghetti? An impasta.",
  },
  {
    "tell me joke number 17": "What do you call fake spaghetti? An impasta.",
  },
  {
    "joke 18": "Why did the math book look sad? It had too many problems.",
  },
  {
    "tell me joke number 18": "Why did the math book look sad? It had too many problems.",
  },
  {
    "joke 19": "What's orange and sounds like a parrot? A carrot.",
  },
  {
    "tell me joke number 19": "What's orange and sounds like a parrot? A carrot.",
  },
  {
    "joke 20": "Why don't skeletons fight each other? They don't have the guts.",
  },
  {
    "tell me joke number 20": "Why don't skeletons fight each other? They don't have the guts.",
  },
  {
    "joke 21": "What did zero say to eight? Nice belt!",
  },
  {
    "tell me joke number 21": "What did zero say to eight? Nice belt!",
  },
  {
    "joke 22": "Why was six afraid of seven? Because seven eight nine.",
  },
  {
    "tell me joke number 22": "Why was six afraid of seven? Because seven eight nine.",
  },
  {
    "joke 23": "What do you call a bear with no teeth? A gummy bear.",
  },
  {
    "tell me joke number 23": "What do you call a bear with no teeth? A gummy bear.",
  },
  {
    "joke 24": "What do you call cheese that isn't yours? Nacho cheese.",
  },
  {
    "tell me joke number 24": "What do you call cheese that isn't yours? Nacho cheese.",
  },
  {
    "joke 25": "Why did the bicycle fall over? Because it was two-tired.",
  },
  {
    "tell me joke number 25": "Why did the bicycle fall over? Because it was two-tired.",
  },
  {
    "joke 26": "What do you call a sleeping bull? A bulldozer.",
  },
  {
    "tell me joke number 26": "What do you call a sleeping bull? A bulldozer.",
  },
  {
    "joke 27": "Why did the tomato turn red? Because it saw the salad dressing.",
  },
  {
    "tell me joke number 27": "Why did the tomato turn red? Because it saw the salad dressing.",
  },
  {
    "joke 28": "I told my computer I needed a break, and now it won't stop sending me vacation ads.",
  },
  {
    "tell me joke number 28": "I told my computer I needed a break, and now it won't stop sending me vacation ads.",
  },
  {
    "joke 29": "Why don't eggs tell jokes? They'd crack each other up.",
  },
  {
    "tell me joke number 29": "Why don't eggs tell jokes? They'd crack each other up.",
  },
  {
    "joke 30": "What do you call a fish wearing a bowtie? Sofishticated.",
  },
  {
    "tell me joke number 30": "What do you call a fish wearing a bowtie? Sofishticated.",
  },
  {
    "joke 31": "Why did the coffee file a police report? It got mugged.",
  },
  {
    "tell me joke number 31": "Why did the coffee file a police report? It got mugged.",
  },
  {
    "joke 32": "What's a computer's favorite snack? Microchips.",
  },
  {
    "tell me joke number 32": "What's a computer's favorite snack? Microchips.",
  },
  {
    "joke 33": "What do you call a dinosaur with a big vocabulary? A thesaurus.",
  },
  {
    "tell me joke number 33": "What do you call a dinosaur with a big vocabulary? A thesaurus.",
  },
  {
    "joke 34": "Why did the cookie go to the doctor? Because it was feeling crumby.",
  },
  {
    "tell me joke number 34": "Why did the cookie go to the doctor? Because it was feeling crumby.",
  },
  {
    "joke 35": "What's the object-oriented way to become wealthy? Inheritance.",
  },
  {
    "tell me joke number 35": "What's the object-oriented way to become wealthy? Inheritance.",
  },
  {
    "joke 36": "Why did the developer quit his job? He didn't get arrays.",
  },
  {
    "tell me joke number 36": "Why did the developer quit his job? He didn't get arrays.",
  },
  {
    "joke 37": "What did the spider do on the computer? Made a website.",
  },
  {
    "tell me joke number 37": "What did the spider do on the computer? Made a website.",
  },
  {
    "joke 38": "Why do Python programmers have low self-esteem? They're constantly comparing their self to others.",
  },
  {
    "tell me joke number 38": "Why do Python programmers have low self-esteem? They're constantly comparing their self to others.",
  },
  {
    "joke 39": "Why did the React component feel lost? It lost its state.",
  },
  {
    "tell me joke number 39": "Why did the React component feel lost? It lost its state.",
  },
  {
    "joke 40": "What did the CSS say to the HTML? 'I've got style, you've got structure.'",
  },
  {
    "tell me joke number 40": "What did the CSS say to the HTML? 'I've got style, you've got structure.'",
  },
  {
    "joke 41": "Why did the git user go to therapy? Too many unresolved conflicts.",
  },
  {
    "tell me joke number 41": "Why did the git user go to therapy? Too many unresolved conflicts.",
  },
  {
    "joke 42": "Why did the chicken join a band? Because it had the drumsticks.",
  },
  {
    "tell me joke number 42": "Why did the chicken join a band? Because it had the drumsticks.",
  },
  {
    "joke 43": "What do you call a pig that does karate? A pork chop.",
  },
  {
    "tell me joke number 43": "What do you call a pig that does karate? A pork chop.",
  },
  {
    "joke 44": "Why did the picture go to jail? Because it was framed.",
  },
  {
    "tell me joke number 44": "Why did the picture go to jail? Because it was framed.",
  },
  {
    "joke 45": "What gets wetter the more it dries? A towel.",
  },
  {
    "tell me joke number 45": "What gets wetter the more it dries? A towel.",
  },
  {
    "joke 46": "Why are ghosts bad liars? Because you can see right through them.",
  },
  {
    "tell me joke number 46": "Why are ghosts bad liars? Because you can see right through them.",
  },
  {
    "joke 47": "What do you call a lazy kangaroo? A pouch potato.",
  },
  {
    "tell me joke number 47": "What do you call a lazy kangaroo? A pouch potato.",
  },
  {
    "joke 48": "Why did the golfer bring two pairs of pants? In case he got a hole in one.",
  },
  {
    "tell me joke number 48": "Why did the golfer bring two pairs of pants? In case he got a hole in one.",
  },
  {
    "joke 49": "Why was the computer late to work? It had a hard drive.",
  },
  {
    "tell me joke number 49": "Why was the computer late to work? It had a hard drive.",
  },
  {
    "joke 50": "Why did the AI go to school? To improve its learning rate.",
  },
  {
    "tell me joke number 50": "Why did the AI go to school? To improve its learning rate.",
  },
  {
    "what is 1 times 1": "1 times 1 is 1.",
  },
  {
    "what is 1 times 2": "1 times 2 is 2.",
  },
  {
    "what is 1 times 3": "1 times 3 is 3.",
  },
  {
    "what is 1 times 4": "1 times 4 is 4.",
  },
  {
    "what is 1 times 5": "1 times 5 is 5.",
  },
  {
    "what is 1 times 6": "1 times 6 is 6.",
  },
  {
    "what is 1 times 7": "1 times 7 is 7.",
  },
  {
    "what is 1 times 8": "1 times 8 is 8.",
  },
  {
    "what is 1 times 9": "1 times 9 is 9.",
  },
  {
    "what is 1 times 10": "1 times 10 is 10.",
  },
  {
    "what is 1 times 11": "1 times 11 is 11.",
  },
  {
    "what is 1 times 12": "1 times 12 is 12.",
  },
  {
    "what is 1 times 13": "1 times 13 is 13.",
  },
  {
    "what is 1 times 14": "1 times 14 is 14.",
  },
  {
    "what is 1 times 15": "1 times 15 is 15.",
  },
  {
    "what is 1 times 16": "1 times 16 is 16.",
  },
  {
    "what is 1 times 17": "1 times 17 is 17.",
  },
  {
    "what is 1 times 18": "1 times 18 is 18.",
  },
  {
    "what is 1 times 19": "1 times 19 is 19.",
  },
  {
    "what is 1 times 20": "1 times 20 is 20.",
  },
  {
    "what is 2 times 1": "2 times 1 is 2.",
  },
  {
    "what is 2 times 2": "2 times 2 is 4.",
  },
  {
    "what is 2 times 3": "2 times 3 is 6.",
  },
  {
    "what is 2 times 4": "2 times 4 is 8.",
  },
  {
    "what is 2 times 5": "2 times 5 is 10.",
  },
  {
    "what is 2 times 6": "2 times 6 is 12.",
  },
  {
    "what is 2 times 7": "2 times 7 is 14.",
  },
  {
    "what is 2 times 8": "2 times 8 is 16.",
  },
  {
    "what is 2 times 9": "2 times 9 is 18.",
  },
  {
    "what is 2 times 10": "2 times 10 is 20.",
  },
  {
    "what is 2 times 11": "2 times 11 is 22.",
  },
  {
    "what is 2 times 12": "2 times 12 is 24.",
  },
  {
    "what is 2 times 13": "2 times 13 is 26.",
  },
  {
    "what is 2 times 14": "2 times 14 is 28.",
  },
  {
    "what is 2 times 15": "2 times 15 is 30.",
  },
  {
    "what is 2 times 16": "2 times 16 is 32.",
  },
  {
    "what is 2 times 17": "2 times 17 is 34.",
  },
  {
    "what is 2 times 18": "2 times 18 is 36.",
  },
  {
    "what is 2 times 19": "2 times 19 is 38.",
  },
  {
    "what is 2 times 20": "2 times 20 is 40.",
  },
  {
    "what is 3 times 1": "3 times 1 is 3.",
  },
  {
    "what is 3 times 2": "3 times 2 is 6.",
  },
  {
    "what is 3 times 3": "3 times 3 is 9.",
  },
  {
    "what is 3 times 4": "3 times 4 is 12.",
  },
  {
    "what is 3 times 5": "3 times 5 is 15.",
  },
  {
    "what is 3 times 6": "3 times 6 is 18.",
  },
  {
    "what is 3 times 7": "3 times 7 is 21.",
  },
  {
    "what is 3 times 8": "3 times 8 is 24.",
  },
  {
    "what is 3 times 9": "3 times 9 is 27.",
  },
  {
    "what is 3 times 10": "3 times 10 is 30.",
  },
  {
    "what is 3 times 11": "3 times 11 is 33.",
  },
  {
    "what is 3 times 12": "3 times 12 is 36.",
  },
  {
    "what is 3 times 13": "3 times 13 is 39.",
  },
  {
    "what is 3 times 14": "3 times 14 is 42.",
  },
  {
    "what is 3 times 15": "3 times 15 is 45.",
  },
  {
    "what is 3 times 16": "3 times 16 is 48.",
  },
  {
    "what is 3 times 17": "3 times 17 is 51.",
  },
  {
    "what is 3 times 18": "3 times 18 is 54.",
  },
  {
    "what is 3 times 19": "3 times 19 is 57.",
  },
  {
    "what is 3 times 20": "3 times 20 is 60.",
  },
  {
    "what is 4 times 1": "4 times 1 is 4.",
  },
  {
    "what is 4 times 2": "4 times 2 is 8.",
  },
  {
    "what is 4 times 3": "4 times 3 is 12.",
  },
  {
    "what is 4 times 4": "4 times 4 is 16.",
  },
  {
    "what is 4 times 5": "4 times 5 is 20.",
  },
  {
    "what is 4 times 6": "4 times 6 is 24.",
  },
  {
    "what is 4 times 7": "4 times 7 is 28.",
  },
  {
    "what is 4 times 8": "4 times 8 is 32.",
  },
  {
    "what is 4 times 9": "4 times 9 is 36.",
  },
  {
    "what is 4 times 10": "4 times 10 is 40.",
  },
  {
    "what is 4 times 11": "4 times 11 is 44.",
  },
  {
    "what is 4 times 12": "4 times 12 is 48.",
  },
  {
    "what is 4 times 13": "4 times 13 is 52.",
  },
  {
    "what is 4 times 14": "4 times 14 is 56.",
  },
  {
    "what is 4 times 15": "4 times 15 is 60.",
  },
  {
    "what is 4 times 16": "4 times 16 is 64.",
  },
  {
    "what is 4 times 17": "4 times 17 is 68.",
  },
  {
    "what is 4 times 18": "4 times 18 is 72.",
  },
  {
    "what is 4 times 19": "4 times 19 is 76.",
  },
  {
    "what is 4 times 20": "4 times 20 is 80.",
  },
  {
    "what is 5 times 1": "5 times 1 is 5.",
  },
  {
    "what is 5 times 2": "5 times 2 is 10.",
  },
  {
    "what is 5 times 3": "5 times 3 is 15.",
  },
  {
    "what is 5 times 4": "5 times 4 is 20.",
  },
  {
    "what is 5 times 5": "5 times 5 is 25.",
  },
  {
    "what is 5 times 6": "5 times 6 is 30.",
  },
  {
    "what is 5 times 7": "5 times 7 is 35.",
  },
  {
    "what is 5 times 8": "5 times 8 is 40.",
  },
  {
    "what is 5 times 9": "5 times 9 is 45.",
  },
  {
    "what is 5 times 10": "5 times 10 is 50.",
  },
  {
    "what is 5 times 11": "5 times 11 is 55.",
  },
  {
    "what is 5 times 12": "5 times 12 is 60.",
  },
  {
    "what is 5 times 13": "5 times 13 is 65.",
  },
  {
    "what is 5 times 14": "5 times 14 is 70.",
  },
  {
    "what is 5 times 15": "5 times 15 is 75.",
  },
  {
    "what is 5 times 16": "5 times 16 is 80.",
  },
  {
    "what is 5 times 17": "5 times 17 is 85.",
  },
  {
    "what is 5 times 18": "5 times 18 is 90.",
  },
  {
    "what is 5 times 19": "5 times 19 is 95.",
  },
  {
    "what is 5 times 20": "5 times 20 is 100.",
  },
  {
    "what is 6 times 1": "6 times 1 is 6.",
  },
  {
    "what is 6 times 2": "6 times 2 is 12.",
  },
  {
    "what is 6 times 3": "6 times 3 is 18.",
  },
  {
    "what is 6 times 4": "6 times 4 is 24.",
  },
  {
    "what is 6 times 5": "6 times 5 is 30.",
  },
  {
    "what is 6 times 6": "6 times 6 is 36.",
  },
  {
    "what is 6 times 7": "6 times 7 is 42.",
  },
  {
    "what is 6 times 8": "6 times 8 is 48.",
  },
  {
    "what is 6 times 9": "6 times 9 is 54.",
  },
  {
    "what is 6 times 10": "6 times 10 is 60.",
  },
  {
    "what is 6 times 11": "6 times 11 is 66.",
  },
  {
    "what is 6 times 12": "6 times 12 is 72.",
  },
  {
    "what is 6 times 13": "6 times 13 is 78.",
  },
  {
    "what is 6 times 14": "6 times 14 is 84.",
  },
  {
    "what is 6 times 15": "6 times 15 is 90.",
  },
  {
    "what is 6 times 16": "6 times 16 is 96.",
  },
  {
    "what is 6 times 17": "6 times 17 is 102.",
  },
  {
    "what is 6 times 18": "6 times 18 is 108.",
  },
  {
    "what is 6 times 19": "6 times 19 is 114.",
  },
  {
    "what is 6 times 20": "6 times 20 is 120.",
  },
  {
    "what is 7 times 1": "7 times 1 is 7.",
  },
  {
    "what is 7 times 2": "7 times 2 is 14.",
  },
  {
    "what is 7 times 3": "7 times 3 is 21.",
  },
  {
    "what is 7 times 4": "7 times 4 is 28.",
  },
  {
    "what is 7 times 5": "7 times 5 is 35.",
  },
  {
    "what is 7 times 6": "7 times 6 is 42.",
  },
  {
    "what is 7 times 7": "7 times 7 is 49.",
  },
  {
    "what is 7 times 8": "7 times 8 is 56.",
  },
  {
    "what is 7 times 9": "7 times 9 is 63.",
  },
  {
    "what is 7 times 10": "7 times 10 is 70.",
  },
  {
    "what is 7 times 11": "7 times 11 is 77.",
  },
  {
    "what is 7 times 12": "7 times 12 is 84.",
  },
  {
    "what is 7 times 13": "7 times 13 is 91.",
  },
  {
    "what is 7 times 14": "7 times 14 is 98.",
  },
  {
    "what is 7 times 15": "7 times 15 is 105.",
  },
  {
    "what is 7 times 16": "7 times 16 is 112.",
  },
  {
    "what is 7 times 17": "7 times 17 is 119.",
  },
  {
    "what is 7 times 18": "7 times 18 is 126.",
  },
  {
    "what is 7 times 19": "7 times 19 is 133.",
  },
  {
    "what is 7 times 20": "7 times 20 is 140.",
  },
  {
    "what is 8 times 1": "8 times 1 is 8.",
  },
  {
    "what is 8 times 2": "8 times 2 is 16.",
  },
  {
    "what is 8 times 3": "8 times 3 is 24.",
  },
  {
    "what is 8 times 4": "8 times 4 is 32.",
  },
  {
    "what is 8 times 5": "8 times 5 is 40.",
  },
  {
    "what is 8 times 6": "8 times 6 is 48.",
  },
  {
    "what is 8 times 7": "8 times 7 is 56.",
  },
  {
    "what is 8 times 8": "8 times 8 is 64.",
  },
  {
    "what is 8 times 9": "8 times 9 is 72.",
  },
  {
    "what is 8 times 10": "8 times 10 is 80.",
  },
  {
    "what is 8 times 11": "8 times 11 is 88.",
  },
  {
    "what is 8 times 12": "8 times 12 is 96.",
  },
  {
    "what is 8 times 13": "8 times 13 is 104.",
  },
  {
    "what is 8 times 14": "8 times 14 is 112.",
  },
  {
    "what is 8 times 15": "8 times 15 is 120.",
  },
  {
    "what is 8 times 16": "8 times 16 is 128.",
  },
  {
    "what is 8 times 17": "8 times 17 is 136.",
  },
  {
    "what is 8 times 18": "8 times 18 is 144.",
  },
  {
    "what is 8 times 19": "8 times 19 is 152.",
  },
  {
    "what is 8 times 20": "8 times 20 is 160.",
  },
  {
    "what is 9 times 1": "9 times 1 is 9.",
  },
  {
    "what is 9 times 2": "9 times 2 is 18.",
  },
  {
    "what is 9 times 3": "9 times 3 is 27.",
  },
  {
    "what is 9 times 4": "9 times 4 is 36.",
  },
  {
    "what is 9 times 5": "9 times 5 is 45.",
  },
  {
    "what is 9 times 6": "9 times 6 is 54.",
  },
  {
    "what is 9 times 7": "9 times 7 is 63.",
  },
  {
    "what is 9 times 8": "9 times 8 is 72.",
  },
  {
    "what is 9 times 9": "9 times 9 is 81.",
  },
  {
    "what is 9 times 10": "9 times 10 is 90.",
  },
  {
    "what is 9 times 11": "9 times 11 is 99.",
  },
  {
    "what is 9 times 12": "9 times 12 is 108.",
  },
  {
    "what is 9 times 13": "9 times 13 is 117.",
  },
  {
    "what is 9 times 14": "9 times 14 is 126.",
  },
  {
    "what is 9 times 15": "9 times 15 is 135.",
  },
  {
    "what is 9 times 16": "9 times 16 is 144.",
  },
  {
    "what is 9 times 17": "9 times 17 is 153.",
  },
  {
    "what is 9 times 18": "9 times 18 is 162.",
  },
  {
    "what is 9 times 19": "9 times 19 is 171.",
  },
  {
    "what is 9 times 20": "9 times 20 is 180.",
  },
  {
    "what is 10 times 1": "10 times 1 is 10.",
  },
  {
    "what is 10 times 2": "10 times 2 is 20.",
  },
  {
    "what is 10 times 3": "10 times 3 is 30.",
  },
  {
    "what is 10 times 4": "10 times 4 is 40.",
  },
  {
    "what is 10 times 5": "10 times 5 is 50.",
  },
  {
    "what is 10 times 6": "10 times 6 is 60.",
  },
  {
    "what is 10 times 7": "10 times 7 is 70.",
  },
  {
    "what is 10 times 8": "10 times 8 is 80.",
  },
  {
    "what is 10 times 9": "10 times 9 is 90.",
  },
  {
    "what is 10 times 10": "10 times 10 is 100.",
  },
  {
    "what is 10 times 11": "10 times 11 is 110.",
  },
  {
    "what is 10 times 12": "10 times 12 is 120.",
  },
  {
    "what is 10 times 13": "10 times 13 is 130.",
  },
  {
    "what is 10 times 14": "10 times 14 is 140.",
  },
  {
    "what is 10 times 15": "10 times 15 is 150.",
  },
  {
    "what is 10 times 16": "10 times 16 is 160.",
  },
  {
    "what is 10 times 17": "10 times 17 is 170.",
  },
  {
    "what is 10 times 18": "10 times 18 is 180.",
  },
  {
    "what is 10 times 19": "10 times 19 is 190.",
  },
  {
    "what is 10 times 20": "10 times 20 is 200.",
  },
  {
    "what is 11 times 1": "11 times 1 is 11.",
  },
  {
    "what is 11 times 2": "11 times 2 is 22.",
  },
  {
    "what is 11 times 3": "11 times 3 is 33.",
  },
  {
    "what is 11 times 4": "11 times 4 is 44.",
  },
  {
    "what is 11 times 5": "11 times 5 is 55.",
  },
  {
    "what is 11 times 6": "11 times 6 is 66.",
  },
  {
    "what is 11 times 7": "11 times 7 is 77.",
  },
  {
    "what is 11 times 8": "11 times 8 is 88.",
  },
  {
    "what is 11 times 9": "11 times 9 is 99.",
  },
  {
    "what is 11 times 10": "11 times 10 is 110.",
  },
  {
    "what is 11 times 11": "11 times 11 is 121.",
  },
  {
    "what is 11 times 12": "11 times 12 is 132.",
  },
  {
    "what is 11 times 13": "11 times 13 is 143.",
  },
  {
    "what is 11 times 14": "11 times 14 is 154.",
  },
  {
    "what is 11 times 15": "11 times 15 is 165.",
  },
  {
    "what is 11 times 16": "11 times 16 is 176.",
  },
  {
    "what is 11 times 17": "11 times 17 is 187.",
  },
  {
    "what is 11 times 18": "11 times 18 is 198.",
  },
  {
    "what is 11 times 19": "11 times 19 is 209.",
  },
  {
    "what is 11 times 20": "11 times 20 is 220.",
  },
  {
    "what is 12 times 1": "12 times 1 is 12.",
  },
  {
    "what is 12 times 2": "12 times 2 is 24.",
  },
  {
    "what is 12 times 3": "12 times 3 is 36.",
  },
  {
    "what is 12 times 4": "12 times 4 is 48.",
  },
  {
    "what is 12 times 5": "12 times 5 is 60.",
  },
  {
    "what is 12 times 6": "12 times 6 is 72.",
  },
  {
    "what is 12 times 7": "12 times 7 is 84.",
  },
  {
    "what is 12 times 8": "12 times 8 is 96.",
  },
  {
    "what is 12 times 9": "12 times 9 is 108.",
  },
  {
    "what is 12 times 10": "12 times 10 is 120.",
  },
  {
    "what is 12 times 11": "12 times 11 is 132.",
  },
  {
    "what is 12 times 12": "12 times 12 is 144.",
  },
  {
    "what is 12 times 13": "12 times 13 is 156.",
  },
  {
    "what is 12 times 14": "12 times 14 is 168.",
  },
  {
    "what is 12 times 15": "12 times 15 is 180.",
  },
  {
    "what is 12 times 16": "12 times 16 is 192.",
  },
  {
    "what is 12 times 17": "12 times 17 is 204.",
  },
  {
    "what is 12 times 18": "12 times 18 is 216.",
  },
  {
    "what is 12 times 19": "12 times 19 is 228.",
  },
  {
    "what is 12 times 20": "12 times 20 is 240.",
  },
  {
    "what is 13 times 1": "13 times 1 is 13.",
  },
  {
    "what is 13 times 2": "13 times 2 is 26.",
  },
  {
    "what is 13 times 3": "13 times 3 is 39.",
  },
  {
    "what is 13 times 4": "13 times 4 is 52.",
  },
  {
    "what is 13 times 5": "13 times 5 is 65.",
  },
  {
    "what is 13 times 6": "13 times 6 is 78.",
  },
  {
    "what is 13 times 7": "13 times 7 is 91.",
  },
  {
    "what is 13 times 8": "13 times 8 is 104.",
  },
  {
    "what is 13 times 9": "13 times 9 is 117.",
  },
  {
    "what is 13 times 10": "13 times 10 is 130.",
  },
  {
    "what is 13 times 11": "13 times 11 is 143.",
  },
  {
    "what is 13 times 12": "13 times 12 is 156.",
  },
  {
    "what is 13 times 13": "13 times 13 is 169.",
  },
  {
    "what is 13 times 14": "13 times 14 is 182.",
  },
  {
    "what is 13 times 15": "13 times 15 is 195.",
  },
  {
    "what is 13 times 16": "13 times 16 is 208.",
  },
  {
    "what is 13 times 17": "13 times 17 is 221.",
  },
  {
    "what is 13 times 18": "13 times 18 is 234.",
  },
  {
    "what is 13 times 19": "13 times 19 is 247.",
  },
  {
    "what is 13 times 20": "13 times 20 is 260.",
  },
  {
    "what is 14 times 1": "14 times 1 is 14.",
  },
  {
    "what is 14 times 2": "14 times 2 is 28.",
  },
  {
    "what is 14 times 3": "14 times 3 is 42.",
  },
  {
    "what is 14 times 4": "14 times 4 is 56.",
  },
  {
    "what is 14 times 5": "14 times 5 is 70.",
  },
  {
    "what is 14 times 6": "14 times 6 is 84.",
  },
  {
    "what is 14 times 7": "14 times 7 is 98.",
  },
  {
    "what is 14 times 8": "14 times 8 is 112.",
  },
  {
    "what is 14 times 9": "14 times 9 is 126.",
  },
  {
    "what is 14 times 10": "14 times 10 is 140.",
  },
  {
    "what is 14 times 11": "14 times 11 is 154.",
  },
  {
    "what is 14 times 12": "14 times 12 is 168.",
  },
  {
    "what is 14 times 13": "14 times 13 is 182.",
  },
  {
    "what is 14 times 14": "14 times 14 is 196.",
  },
  {
    "what is 14 times 15": "14 times 15 is 210.",
  },
  {
    "what is 14 times 16": "14 times 16 is 224.",
  },
  {
    "what is 14 times 17": "14 times 17 is 238.",
  },
  {
    "what is 14 times 18": "14 times 18 is 252.",
  },
  {
    "what is 14 times 19": "14 times 19 is 266.",
  },
  {
    "what is 14 times 20": "14 times 20 is 280.",
  },
  {
    "what is 15 times 1": "15 times 1 is 15.",
  },
  {
    "what is 15 times 2": "15 times 2 is 30.",
  },
  {
    "what is 15 times 3": "15 times 3 is 45.",
  },
  {
    "what is 15 times 4": "15 times 4 is 60.",
  },
  {
    "what is 15 times 5": "15 times 5 is 75.",
  },
  {
    "what is 15 times 6": "15 times 6 is 90.",
  },
  {
    "what is 15 times 7": "15 times 7 is 105.",
  },
  {
    "what is 15 times 8": "15 times 8 is 120.",
  },
  {
    "what is 15 times 9": "15 times 9 is 135.",
  },
  {
    "what is 15 times 10": "15 times 10 is 150.",
  },
  {
    "what is 15 times 11": "15 times 11 is 165.",
  },
  {
    "what is 15 times 12": "15 times 12 is 180.",
  },
  {
    "what is 15 times 13": "15 times 13 is 195.",
  },
  {
    "what is 15 times 14": "15 times 14 is 210.",
  },
  {
    "what is 15 times 15": "15 times 15 is 225.",
  },
  {
    "what is 15 times 16": "15 times 16 is 240.",
  },
  {
    "what is 15 times 17": "15 times 17 is 255.",
  },
  {
    "what is 15 times 18": "15 times 18 is 270.",
  },
  {
    "what is 15 times 19": "15 times 19 is 285.",
  },
  {
    "what is 15 times 20": "15 times 20 is 300.",
  },
  {
    "what is 16 times 1": "16 times 1 is 16.",
  },
  {
    "what is 16 times 2": "16 times 2 is 32.",
  },
  {
    "what is 16 times 3": "16 times 3 is 48.",
  },
  {
    "what is 16 times 4": "16 times 4 is 64.",
  },
  {
    "what is 16 times 5": "16 times 5 is 80.",
  },
  {
    "what is 16 times 6": "16 times 6 is 96.",
  },
  {
    "what is 16 times 7": "16 times 7 is 112.",
  },
  {
    "what is 16 times 8": "16 times 8 is 128.",
  },
  {
    "what is 16 times 9": "16 times 9 is 144.",
  },
  {
    "what is 16 times 10": "16 times 10 is 160.",
  },
  {
    "what is 16 times 11": "16 times 11 is 176.",
  },
  {
    "what is 16 times 12": "16 times 12 is 192.",
  },
  {
    "what is 16 times 13": "16 times 13 is 208.",
  },
  {
    "what is 16 times 14": "16 times 14 is 224.",
  },
  {
    "what is 16 times 15": "16 times 15 is 240.",
  },
  {
    "what is 16 times 16": "16 times 16 is 256.",
  },
  {
    "what is 16 times 17": "16 times 17 is 272.",
  },
  {
    "what is 16 times 18": "16 times 18 is 288.",
  },
  {
    "what is 16 times 19": "16 times 19 is 304.",
  },
  {
    "what is 16 times 20": "16 times 20 is 320.",
  },
  {
    "what is 17 times 1": "17 times 1 is 17.",
  },
  {
    "what is 17 times 2": "17 times 2 is 34.",
  },
  {
    "what is 17 times 3": "17 times 3 is 51.",
  },
  {
    "what is 17 times 4": "17 times 4 is 68.",
  },
  {
    "what is 17 times 5": "17 times 5 is 85.",
  },
  {
    "what is 17 times 6": "17 times 6 is 102.",
  },
  {
    "what is 17 times 7": "17 times 7 is 119.",
  },
  {
    "what is 17 times 8": "17 times 8 is 136.",
  },
  {
    "what is 17 times 9": "17 times 9 is 153.",
  },
  {
    "what is 17 times 10": "17 times 10 is 170.",
  },
  {
    "what is 17 times 11": "17 times 11 is 187.",
  },
  {
    "what is 17 times 12": "17 times 12 is 204.",
  },
  {
    "what is 17 times 13": "17 times 13 is 221.",
  },
  {
    "what is 17 times 14": "17 times 14 is 238.",
  },
  {
    "what is 17 times 15": "17 times 15 is 255.",
  },
  {
    "what is 17 times 16": "17 times 16 is 272.",
  },
  {
    "what is 17 times 17": "17 times 17 is 289.",
  },
  {
    "what is 17 times 18": "17 times 18 is 306.",
  },
  {
    "what is 17 times 19": "17 times 19 is 323.",
  },
  {
    "what is 17 times 20": "17 times 20 is 340.",
  },
  {
    "what is 18 times 1": "18 times 1 is 18.",
  },
  {
    "what is 18 times 2": "18 times 2 is 36.",
  },
  {
    "what is 18 times 3": "18 times 3 is 54.",
  },
  {
    "what is 18 times 4": "18 times 4 is 72.",
  },
  {
    "what is 18 times 5": "18 times 5 is 90.",
  },
  {
    "what is 18 times 6": "18 times 6 is 108.",
  },
  {
    "what is 18 times 7": "18 times 7 is 126.",
  },
  {
    "what is 18 times 8": "18 times 8 is 144.",
  },
  {
    "what is 18 times 9": "18 times 9 is 162.",
  },
  {
    "what is 18 times 10": "18 times 10 is 180.",
  },
  {
    "what is 18 times 11": "18 times 11 is 198.",
  },
  {
    "what is 18 times 12": "18 times 12 is 216.",
  },
  {
    "what is 18 times 13": "18 times 13 is 234.",
  },
  {
    "what is 18 times 14": "18 times 14 is 252.",
  },
  {
    "what is 18 times 15": "18 times 15 is 270.",
  },
  {
    "what is 18 times 16": "18 times 16 is 288.",
  },
  {
    "what is 18 times 17": "18 times 17 is 306.",
  },
  {
    "what is 18 times 18": "18 times 18 is 324.",
  },
  {
    "what is 18 times 19": "18 times 19 is 342.",
  },
  {
    "what is 18 times 20": "18 times 20 is 360.",
  },
  {
    "what is 19 times 1": "19 times 1 is 19.",
  },
  {
    "what is 19 times 2": "19 times 2 is 38.",
  },
  {
    "what is 19 times 3": "19 times 3 is 57.",
  },
  {
    "what is 19 times 4": "19 times 4 is 76.",
  },
  {
    "what is 19 times 5": "19 times 5 is 95.",
  },
  {
    "what is 19 times 6": "19 times 6 is 114.",
  },
  {
    "what is 19 times 7": "19 times 7 is 133.",
  },
  {
    "what is 19 times 8": "19 times 8 is 152.",
  },
  {
    "what is 19 times 9": "19 times 9 is 171.",
  },
  {
    "what is 19 times 10": "19 times 10 is 190.",
  },
  {
    "what is 19 times 11": "19 times 11 is 209.",
  },
  {
    "what is 19 times 12": "19 times 12 is 228.",
  },
  {
    "what is 19 times 13": "19 times 13 is 247.",
  },
  {
    "what is 19 times 14": "19 times 14 is 266.",
  },
  {
    "what is 19 times 15": "19 times 15 is 285.",
  },
  {
    "what is 19 times 16": "19 times 16 is 304.",
  },
  {
    "what is 19 times 17": "19 times 17 is 323.",
  },
  {
    "what is 19 times 18": "19 times 18 is 342.",
  },
  {
    "what is 19 times 19": "19 times 19 is 361.",
  },
  {
    "what is 19 times 20": "19 times 20 is 380.",
  },
  {
    "what is 20 times 1": "20 times 1 is 20.",
  },
  {
    "what is 20 times 2": "20 times 2 is 40.",
  },
  {
    "what is 20 times 3": "20 times 3 is 60.",
  },
  {
    "what is 20 times 4": "20 times 4 is 80.",
  },
  {
    "what is 20 times 5": "20 times 5 is 100.",
  },
  {
    "what is 20 times 6": "20 times 6 is 120.",
  },
  {
    "what is 20 times 7": "20 times 7 is 140.",
  },
  {
    "what is 20 times 8": "20 times 8 is 160.",
  },
  {
    "what is 20 times 9": "20 times 9 is 180.",
  },
  {
    "what is 20 times 10": "20 times 10 is 200.",
  },
  {
    "what is 20 times 11": "20 times 11 is 220.",
  },
  {
    "what is 20 times 12": "20 times 12 is 240.",
  },
  {
    "what is 20 times 13": "20 times 13 is 260.",
  },
  {
    "what is 20 times 14": "20 times 14 is 280.",
  },
  {
    "what is 20 times 15": "20 times 15 is 300.",
  },
  {
    "what is 20 times 16": "20 times 16 is 320.",
  },
  {
    "what is 20 times 17": "20 times 17 is 340.",
  },
  {
    "what is 20 times 18": "20 times 18 is 360.",
  },
  {
    "what is 20 times 19": "20 times 19 is 380.",
  },
  {
    "what is 20 times 20": "20 times 20 is 400.",
  },
  {
    "what is 1 plus 1": "1 plus 1 is 2.",
  },
  {
    "what is 1 plus 2": "1 plus 2 is 3.",
  },
  {
    "what is 1 plus 3": "1 plus 3 is 4.",
  },
  {
    "what is 1 plus 4": "1 plus 4 is 5.",
  },
  {
    "what is 1 plus 5": "1 plus 5 is 6.",
  },
  {
    "what is 1 plus 6": "1 plus 6 is 7.",
  },
  {
    "what is 1 plus 7": "1 plus 7 is 8.",
  },
  {
    "what is 1 plus 8": "1 plus 8 is 9.",
  },
  {
    "what is 1 plus 9": "1 plus 9 is 10.",
  },
  {
    "what is 1 plus 10": "1 plus 10 is 11.",
  },
  {
    "what is 1 plus 11": "1 plus 11 is 12.",
  },
  {
    "what is 1 plus 12": "1 plus 12 is 13.",
  },
  {
    "what is 1 plus 13": "1 plus 13 is 14.",
  },
  {
    "what is 1 plus 14": "1 plus 14 is 15.",
  },
  {
    "what is 1 plus 15": "1 plus 15 is 16.",
  },
  {
    "what is 1 plus 16": "1 plus 16 is 17.",
  },
  {
    "what is 1 plus 17": "1 plus 17 is 18.",
  },
  {
    "what is 1 plus 18": "1 plus 18 is 19.",
  },
  {
    "what is 1 plus 19": "1 plus 19 is 20.",
  },
  {
    "what is 1 plus 20": "1 plus 20 is 21.",
  },
  {
    "what is 2 plus 1": "2 plus 1 is 3.",
  },
  {
    "what is 2 plus 2": "2 plus 2 is 4.",
  },
  {
    "what is 2 plus 3": "2 plus 3 is 5.",
  },
  {
    "what is 2 plus 4": "2 plus 4 is 6.",
  },
  {
    "what is 2 plus 5": "2 plus 5 is 7.",
  },
  {
    "what is 2 plus 6": "2 plus 6 is 8.",
  },
  {
    "what is 2 plus 7": "2 plus 7 is 9.",
  },
  {
    "what is 2 plus 8": "2 plus 8 is 10.",
  },
  {
    "what is 2 plus 9": "2 plus 9 is 11.",
  },
  {
    "what is 2 plus 10": "2 plus 10 is 12.",
  },
  {
    "what is 2 plus 11": "2 plus 11 is 13.",
  },
  {
    "what is 2 plus 12": "2 plus 12 is 14.",
  },
  {
    "what is 2 plus 13": "2 plus 13 is 15.",
  },
  {
    "what is 2 plus 14": "2 plus 14 is 16.",
  },
  {
    "what is 2 plus 15": "2 plus 15 is 17.",
  },
  {
    "what is 2 plus 16": "2 plus 16 is 18.",
  },
  {
    "what is 2 plus 17": "2 plus 17 is 19.",
  },
  {
    "what is 2 plus 18": "2 plus 18 is 20.",
  },
  {
    "what is 2 plus 19": "2 plus 19 is 21.",
  },
  {
    "what is 2 plus 20": "2 plus 20 is 22.",
  },
  {
    "what is 3 plus 1": "3 plus 1 is 4.",
  },
  {
    "what is 3 plus 2": "3 plus 2 is 5.",
  },
  {
    "what is 3 plus 3": "3 plus 3 is 6.",
  },
  {
    "what is 3 plus 4": "3 plus 4 is 7.",
  },
  {
    "what is 3 plus 5": "3 plus 5 is 8.",
  },
  {
    "what is 3 plus 6": "3 plus 6 is 9.",
  },
  {
    "what is 3 plus 7": "3 plus 7 is 10.",
  },
  {
    "what is 3 plus 8": "3 plus 8 is 11.",
  },
  {
    "what is 3 plus 9": "3 plus 9 is 12.",
  },
  {
    "what is 3 plus 10": "3 plus 10 is 13.",
  },
  {
    "what is 3 plus 11": "3 plus 11 is 14.",
  },
  {
    "what is 3 plus 12": "3 plus 12 is 15.",
  },
  {
    "what is 3 plus 13": "3 plus 13 is 16.",
  },
  {
    "what is 3 plus 14": "3 plus 14 is 17.",
  },
  {
    "what is 3 plus 15": "3 plus 15 is 18.",
  },
  {
    "what is 3 plus 16": "3 plus 16 is 19.",
  },
  {
    "what is 3 plus 17": "3 plus 17 is 20.",
  },
  {
    "what is 3 plus 18": "3 plus 18 is 21.",
  },
  {
    "what is 3 plus 19": "3 plus 19 is 22.",
  },
  {
    "what is 3 plus 20": "3 plus 20 is 23.",
  },
  {
    "what is 4 plus 1": "4 plus 1 is 5.",
  },
  {
    "what is 4 plus 2": "4 plus 2 is 6.",
  },
  {
    "what is 4 plus 3": "4 plus 3 is 7.",
  },
  {
    "what is 4 plus 4": "4 plus 4 is 8.",
  },
  {
    "what is 4 plus 5": "4 plus 5 is 9.",
  },
  {
    "what is 4 plus 6": "4 plus 6 is 10.",
  },
  {
    "what is 4 plus 7": "4 plus 7 is 11.",
  },
  {
    "what is 4 plus 8": "4 plus 8 is 12.",
  },
  {
    "what is 4 plus 9": "4 plus 9 is 13.",
  },
  {
    "what is 4 plus 10": "4 plus 10 is 14.",
  },
  {
    "what is 4 plus 11": "4 plus 11 is 15.",
  },
  {
    "what is 4 plus 12": "4 plus 12 is 16.",
  },
  {
    "what is 4 plus 13": "4 plus 13 is 17.",
  },
  {
    "what is 4 plus 14": "4 plus 14 is 18.",
  },
  {
    "what is 4 plus 15": "4 plus 15 is 19.",
  },
  {
    "what is 4 plus 16": "4 plus 16 is 20.",
  },
  {
    "what is 4 plus 17": "4 plus 17 is 21.",
  },
  {
    "what is 4 plus 18": "4 plus 18 is 22.",
  },
  {
    "what is 4 plus 19": "4 plus 19 is 23.",
  },
  {
    "what is 4 plus 20": "4 plus 20 is 24.",
  },
  {
    "what is 5 plus 1": "5 plus 1 is 6.",
  },
  {
    "what is 5 plus 2": "5 plus 2 is 7.",
  },
  {
    "what is 5 plus 3": "5 plus 3 is 8.",
  },
  {
    "what is 5 plus 4": "5 plus 4 is 9.",
  },
  {
    "what is 5 plus 5": "5 plus 5 is 10.",
  },
  {
    "what is 5 plus 6": "5 plus 6 is 11.",
  },
  {
    "what is 5 plus 7": "5 plus 7 is 12.",
  },
  {
    "what is 5 plus 8": "5 plus 8 is 13.",
  },
  {
    "what is 5 plus 9": "5 plus 9 is 14.",
  },
  {
    "what is 5 plus 10": "5 plus 10 is 15.",
  },
  {
    "what is 5 plus 11": "5 plus 11 is 16.",
  },
  {
    "what is 5 plus 12": "5 plus 12 is 17.",
  },
  {
    "what is 5 plus 13": "5 plus 13 is 18.",
  },
  {
    "what is 5 plus 14": "5 plus 14 is 19.",
  },
  {
    "what is 5 plus 15": "5 plus 15 is 20.",
  },
  {
    "what is 5 plus 16": "5 plus 16 is 21.",
  },
  {
    "what is 5 plus 17": "5 plus 17 is 22.",
  },
  {
    "what is 5 plus 18": "5 plus 18 is 23.",
  },
  {
    "what is 5 plus 19": "5 plus 19 is 24.",
  },
  {
    "what is 5 plus 20": "5 plus 20 is 25.",
  },
  {
    "what is 6 plus 1": "6 plus 1 is 7.",
  },
  {
    "what is 6 plus 2": "6 plus 2 is 8.",
  },
  {
    "what is 6 plus 3": "6 plus 3 is 9.",
  },
  {
    "what is 6 plus 4": "6 plus 4 is 10.",
  },
  {
    "what is 6 plus 5": "6 plus 5 is 11.",
  },
  {
    "what is 6 plus 6": "6 plus 6 is 12.",
  },
  {
    "what is 6 plus 7": "6 plus 7 is 13.",
  },
  {
    "what is 6 plus 8": "6 plus 8 is 14.",
  },
  {
    "what is 6 plus 9": "6 plus 9 is 15.",
  },
  {
    "what is 6 plus 10": "6 plus 10 is 16.",
  },
  {
    "what is 6 plus 11": "6 plus 11 is 17.",
  },
  {
    "what is 6 plus 12": "6 plus 12 is 18.",
  },
  {
    "what is 6 plus 13": "6 plus 13 is 19.",
  },
  {
    "what is 6 plus 14": "6 plus 14 is 20.",
  },
  {
    "what is 6 plus 15": "6 plus 15 is 21.",
  },
  {
    "what is 6 plus 16": "6 plus 16 is 22.",
  },
  {
    "what is 6 plus 17": "6 plus 17 is 23.",
  },
  {
    "what is 6 plus 18": "6 plus 18 is 24.",
  },
  {
    "what is 6 plus 19": "6 plus 19 is 25.",
  },
  {
    "what is 6 plus 20": "6 plus 20 is 26.",
  },
  {
    "what is 7 plus 1": "7 plus 1 is 8.",
  },
  {
    "what is 7 plus 2": "7 plus 2 is 9.",
  },
  {
    "what is 7 plus 3": "7 plus 3 is 10.",
  },
  {
    "what is 7 plus 4": "7 plus 4 is 11.",
  },
  {
    "what is 7 plus 5": "7 plus 5 is 12.",
  },
  {
    "what is 7 plus 6": "7 plus 6 is 13.",
  },
  {
    "what is 7 plus 7": "7 plus 7 is 14.",
  },
  {
    "what is 7 plus 8": "7 plus 8 is 15.",
  },
  {
    "what is 7 plus 9": "7 plus 9 is 16.",
  },
  {
    "what is 7 plus 10": "7 plus 10 is 17.",
  },
  {
    "what is 7 plus 11": "7 plus 11 is 18.",
  },
  {
    "what is 7 plus 12": "7 plus 12 is 19.",
  },
  {
    "what is 7 plus 13": "7 plus 13 is 20.",
  },
  {
    "what is 7 plus 14": "7 plus 14 is 21.",
  },
  {
    "what is 7 plus 15": "7 plus 15 is 22.",
  },
  {
    "what is 7 plus 16": "7 plus 16 is 23.",
  },
  {
    "what is 7 plus 17": "7 plus 17 is 24.",
  },
  {
    "what is 7 plus 18": "7 plus 18 is 25.",
  },
  {
    "what is 7 plus 19": "7 plus 19 is 26.",
  },
  {
    "what is 7 plus 20": "7 plus 20 is 27.",
  },
  {
    "what is 8 plus 1": "8 plus 1 is 9.",
  },
  {
    "what is 8 plus 2": "8 plus 2 is 10.",
  },
  {
    "what is 8 plus 3": "8 plus 3 is 11.",
  },
  {
    "what is 8 plus 4": "8 plus 4 is 12.",
  },
  {
    "what is 8 plus 5": "8 plus 5 is 13.",
  },
  {
    "what is 8 plus 6": "8 plus 6 is 14.",
  },
  {
    "what is 8 plus 7": "8 plus 7 is 15.",
  },
  {
    "what is 8 plus 8": "8 plus 8 is 16.",
  },
  {
    "what is 8 plus 9": "8 plus 9 is 17.",
  },
  {
    "what is 8 plus 10": "8 plus 10 is 18.",
  },
  {
    "what is 8 plus 11": "8 plus 11 is 19.",
  },
  {
    "what is 8 plus 12": "8 plus 12 is 20.",
  },
  {
    "what is 8 plus 13": "8 plus 13 is 21.",
  },
  {
    "what is 8 plus 14": "8 plus 14 is 22.",
  },
  {
    "what is 8 plus 15": "8 plus 15 is 23.",
  },
  {
    "what is 8 plus 16": "8 plus 16 is 24.",
  },
  {
    "what is 8 plus 17": "8 plus 17 is 25.",
  },
  {
    "what is 8 plus 18": "8 plus 18 is 26.",
  },
  {
    "what is 8 plus 19": "8 plus 19 is 27.",
  },
  {
    "what is 8 plus 20": "8 plus 20 is 28.",
  },
  {
    "what is 9 plus 1": "9 plus 1 is 10.",
  },
  {
    "what is 9 plus 2": "9 plus 2 is 11.",
  },
  {
    "what is 9 plus 3": "9 plus 3 is 12.",
  },
  {
    "what is 9 plus 4": "9 plus 4 is 13.",
  },
  {
    "what is 9 plus 5": "9 plus 5 is 14.",
  },
  {
    "what is 9 plus 6": "9 plus 6 is 15.",
  },
  {
    "what is 9 plus 7": "9 plus 7 is 16.",
  },
  {
    "what is 9 plus 8": "9 plus 8 is 17.",
  },
  {
    "what is 9 plus 9": "9 plus 9 is 18.",
  },
  {
    "what is 9 plus 10": "9 plus 10 is 19.",
  },
  {
    "what is 9 plus 11": "9 plus 11 is 20.",
  },
  {
    "what is 9 plus 12": "9 plus 12 is 21.",
  },
  {
    "what is 9 plus 13": "9 plus 13 is 22.",
  },
  {
    "what is 9 plus 14": "9 plus 14 is 23.",
  },
  {
    "what is 9 plus 15": "9 plus 15 is 24.",
  },
  {
    "what is 9 plus 16": "9 plus 16 is 25.",
  },
  {
    "what is 9 plus 17": "9 plus 17 is 26.",
  },
  {
    "what is 9 plus 18": "9 plus 18 is 27.",
  },
  {
    "what is 9 plus 19": "9 plus 19 is 28.",
  },
  {
    "what is 9 plus 20": "9 plus 20 is 29.",
  },
  {
    "what is 10 plus 1": "10 plus 1 is 11.",
  },
  {
    "what is 10 plus 2": "10 plus 2 is 12.",
  },
  {
    "what is 10 plus 3": "10 plus 3 is 13.",
  },
  {
    "what is 10 plus 4": "10 plus 4 is 14.",
  },
  {
    "what is 10 plus 5": "10 plus 5 is 15.",
  },
  {
    "what is 10 plus 6": "10 plus 6 is 16.",
  },
  {
    "what is 10 plus 7": "10 plus 7 is 17.",
  },
  {
    "what is 10 plus 8": "10 plus 8 is 18.",
  },
  {
    "what is 10 plus 9": "10 plus 9 is 19.",
  },
  {
    "what is 10 plus 10": "10 plus 10 is 20.",
  },
  {
    "what is 10 plus 11": "10 plus 11 is 21.",
  },
  {
    "what is 10 plus 12": "10 plus 12 is 22.",
  },
  {
    "what is 10 plus 13": "10 plus 13 is 23.",
  },
  {
    "what is 10 plus 14": "10 plus 14 is 24.",
  },
  {
    "what is 10 plus 15": "10 plus 15 is 25.",
  },
  {
    "what is 10 plus 16": "10 plus 16 is 26.",
  },
  {
    "what is 10 plus 17": "10 plus 17 is 27.",
  },
  {
    "what is 10 plus 18": "10 plus 18 is 28.",
  },
  {
    "what is 10 plus 19": "10 plus 19 is 29.",
  },
  {
    "what is 10 plus 20": "10 plus 20 is 30.",
  },
  {
    "what is 11 plus 1": "11 plus 1 is 12.",
  },
  {
    "what is 11 plus 2": "11 plus 2 is 13.",
  },
  {
    "what is 11 plus 3": "11 plus 3 is 14.",
  },
  {
    "what is 11 plus 4": "11 plus 4 is 15.",
  },
  {
    "what is 11 plus 5": "11 plus 5 is 16.",
  },
  {
    "what is 11 plus 6": "11 plus 6 is 17.",
  },
  {
    "what is 11 plus 7": "11 plus 7 is 18.",
  },
  {
    "what is 11 plus 8": "11 plus 8 is 19.",
  },
  {
    "what is 11 plus 9": "11 plus 9 is 20.",
  },
  {
    "what is 11 plus 10": "11 plus 10 is 21.",
  },
  {
    "what is 11 plus 11": "11 plus 11 is 22.",
  },
  {
    "what is 11 plus 12": "11 plus 12 is 23.",
  },
  {
    "what is 11 plus 13": "11 plus 13 is 24.",
  },
  {
    "what is 11 plus 14": "11 plus 14 is 25.",
  },
  {
    "what is 11 plus 15": "11 plus 15 is 26.",
  },
  {
    "what is 11 plus 16": "11 plus 16 is 27.",
  },
  {
    "what is 11 plus 17": "11 plus 17 is 28.",
  },
  {
    "what is 11 plus 18": "11 plus 18 is 29.",
  },
  {
    "what is 11 plus 19": "11 plus 19 is 30.",
  },
  {
    "what is 11 plus 20": "11 plus 20 is 31.",
  },
  {
    "what is 12 plus 1": "12 plus 1 is 13.",
  },
  {
    "what is 12 plus 2": "12 plus 2 is 14.",
  },
  {
    "what is 12 plus 3": "12 plus 3 is 15.",
  },
  {
    "what is 12 plus 4": "12 plus 4 is 16.",
  },
  {
    "what is 12 plus 5": "12 plus 5 is 17.",
  },
  {
    "what is 12 plus 6": "12 plus 6 is 18.",
  },
  {
    "what is 12 plus 7": "12 plus 7 is 19.",
  },
  {
    "what is 12 plus 8": "12 plus 8 is 20.",
  },
  {
    "what is 12 plus 9": "12 plus 9 is 21.",
  },
  {
    "what is 12 plus 10": "12 plus 10 is 22.",
  },
  {
    "what is 12 plus 11": "12 plus 11 is 23.",
  },
  {
    "what is 12 plus 12": "12 plus 12 is 24.",
  },
  {
    "what is 12 plus 13": "12 plus 13 is 25.",
  },
  {
    "what is 12 plus 14": "12 plus 14 is 26.",
  },
  {
    "what is 12 plus 15": "12 plus 15 is 27.",
  },
  {
    "what is 12 plus 16": "12 plus 16 is 28.",
  },
  {
    "what is 12 plus 17": "12 plus 17 is 29.",
  },
  {
    "what is 12 plus 18": "12 plus 18 is 30.",
  },
  {
    "what is 12 plus 19": "12 plus 19 is 31.",
  },
  {
    "what is 12 plus 20": "12 plus 20 is 32.",
  },
  {
    "what is 13 plus 1": "13 plus 1 is 14.",
  },
  {
    "what is 13 plus 2": "13 plus 2 is 15.",
  },
  {
    "what is 13 plus 3": "13 plus 3 is 16.",
  },
  {
    "what is 13 plus 4": "13 plus 4 is 17.",
  },
  {
    "what is 13 plus 5": "13 plus 5 is 18.",
  },
  {
    "what is 13 plus 6": "13 plus 6 is 19.",
  },
  {
    "what is 13 plus 7": "13 plus 7 is 20.",
  },
  {
    "what is 13 plus 8": "13 plus 8 is 21.",
  },
  {
    "what is 13 plus 9": "13 plus 9 is 22.",
  },
  {
    "what is 13 plus 10": "13 plus 10 is 23.",
  },
  {
    "what is 13 plus 11": "13 plus 11 is 24.",
  },
  {
    "what is 13 plus 12": "13 plus 12 is 25.",
  },
  {
    "what is 13 plus 13": "13 plus 13 is 26.",
  },
  {
    "what is 13 plus 14": "13 plus 14 is 27.",
  },
  {
    "what is 13 plus 15": "13 plus 15 is 28.",
  },
  {
    "what is 13 plus 16": "13 plus 16 is 29.",
  },
  {
    "what is 13 plus 17": "13 plus 17 is 30.",
  },
  {
    "what is 13 plus 18": "13 plus 18 is 31.",
  },
  {
    "what is 13 plus 19": "13 plus 19 is 32.",
  },
  {
    "what is 13 plus 20": "13 plus 20 is 33.",
  },
  {
    "what is 14 plus 1": "14 plus 1 is 15.",
  },
  {
    "what is 14 plus 2": "14 plus 2 is 16.",
  },
  {
    "what is 14 plus 3": "14 plus 3 is 17.",
  },
  {
    "what is 14 plus 4": "14 plus 4 is 18.",
  },
  {
    "what is 14 plus 5": "14 plus 5 is 19.",
  },
  {
    "what is 14 plus 6": "14 plus 6 is 20.",
  },
  {
    "what is 14 plus 7": "14 plus 7 is 21.",
  },
  {
    "what is 14 plus 8": "14 plus 8 is 22.",
  },
  {
    "what is 14 plus 9": "14 plus 9 is 23.",
  },
  {
    "what is 14 plus 10": "14 plus 10 is 24.",
  },
  {
    "what is 14 plus 11": "14 plus 11 is 25.",
  },
  {
    "what is 14 plus 12": "14 plus 12 is 26.",
  },
  {
    "what is 14 plus 13": "14 plus 13 is 27.",
  },
  {
    "what is 14 plus 14": "14 plus 14 is 28.",
  },
  {
    "what is 14 plus 15": "14 plus 15 is 29.",
  },
  {
    "what is 14 plus 16": "14 plus 16 is 30.",
  },
  {
    "what is 14 plus 17": "14 plus 17 is 31.",
  },
  {
    "what is 14 plus 18": "14 plus 18 is 32.",
  },
  {
    "what is 14 plus 19": "14 plus 19 is 33.",
  },
  {
    "what is 14 plus 20": "14 plus 20 is 34.",
  },
  {
    "what is 15 plus 1": "15 plus 1 is 16.",
  },
  {
    "what is 15 plus 2": "15 plus 2 is 17.",
  },
  {
    "what is 15 plus 3": "15 plus 3 is 18.",
  },
  {
    "what is 15 plus 4": "15 plus 4 is 19.",
  },
  {
    "what is 15 plus 5": "15 plus 5 is 20.",
  },
  {
    "what is 15 plus 6": "15 plus 6 is 21.",
  },
  {
    "what is 15 plus 7": "15 plus 7 is 22.",
  },
  {
    "what is 15 plus 8": "15 plus 8 is 23.",
  },
  {
    "what is 15 plus 9": "15 plus 9 is 24.",
  },
  {
    "what is 15 plus 10": "15 plus 10 is 25.",
  },
  {
    "what is 15 plus 11": "15 plus 11 is 26.",
  },
  {
    "what is 15 plus 12": "15 plus 12 is 27.",
  },
  {
    "what is 15 plus 13": "15 plus 13 is 28.",
  },
  {
    "what is 15 plus 14": "15 plus 14 is 29.",
  },
  {
    "what is 15 plus 15": "15 plus 15 is 30.",
  },
  {
    "what is 15 plus 16": "15 plus 16 is 31.",
  },
  {
    "what is 15 plus 17": "15 plus 17 is 32.",
  },
  {
    "what is 15 plus 18": "15 plus 18 is 33.",
  },
  {
    "what is 15 plus 19": "15 plus 19 is 34.",
  },
  {
    "what is 15 plus 20": "15 plus 20 is 35.",
  },
  {
    "what is 16 plus 1": "16 plus 1 is 17.",
  },
  {
    "what is 16 plus 2": "16 plus 2 is 18.",
  },
  {
    "what is 16 plus 3": "16 plus 3 is 19.",
  },
  {
    "what is 16 plus 4": "16 plus 4 is 20.",
  },
  {
    "what is 16 plus 5": "16 plus 5 is 21.",
  },
  {
    "what is 16 plus 6": "16 plus 6 is 22.",
  },
  {
    "what is 16 plus 7": "16 plus 7 is 23.",
  },
  {
    "what is 16 plus 8": "16 plus 8 is 24.",
  },
  {
    "what is 16 plus 9": "16 plus 9 is 25.",
  },
  {
    "what is 16 plus 10": "16 plus 10 is 26.",
  },
  {
    "what is 16 plus 11": "16 plus 11 is 27.",
  },
  {
    "what is 16 plus 12": "16 plus 12 is 28.",
  },
  {
    "what is 16 plus 13": "16 plus 13 is 29.",
  },
  {
    "what is 16 plus 14": "16 plus 14 is 30.",
  },
  {
    "what is 16 plus 15": "16 plus 15 is 31.",
  },
  {
    "what is 16 plus 16": "16 plus 16 is 32.",
  },
  {
    "what is 16 plus 17": "16 plus 17 is 33.",
  },
  {
    "what is 16 plus 18": "16 plus 18 is 34.",
  },
  {
    "what is 16 plus 19": "16 plus 19 is 35.",
  },
  {
    "what is 16 plus 20": "16 plus 20 is 36.",
  },
  {
    "what is 17 plus 1": "17 plus 1 is 18.",
  },
  {
    "what is 17 plus 2": "17 plus 2 is 19.",
  },
  {
    "what is 17 plus 3": "17 plus 3 is 20.",
  },
  {
    "what is 17 plus 4": "17 plus 4 is 21.",
  },
  {
    "what is 17 plus 5": "17 plus 5 is 22.",
  },
  {
    "what is 17 plus 6": "17 plus 6 is 23.",
  },
  {
    "what is 17 plus 7": "17 plus 7 is 24.",
  },
  {
    "what is 17 plus 8": "17 plus 8 is 25.",
  },
  {
    "what is 17 plus 9": "17 plus 9 is 26.",
  },
  {
    "what is 17 plus 10": "17 plus 10 is 27.",
  },
  {
    "what is 17 plus 11": "17 plus 11 is 28.",
  },
  {
    "what is 17 plus 12": "17 plus 12 is 29.",
  },
  {
    "what is 17 plus 13": "17 plus 13 is 30.",
  },
  {
    "what is 17 plus 14": "17 plus 14 is 31.",
  },
  {
    "what is 17 plus 15": "17 plus 15 is 32.",
  },
  {
    "what is 17 plus 16": "17 plus 16 is 33.",
  },
  {
    "what is 17 plus 17": "17 plus 17 is 34.",
  },
  {
    "what is 17 plus 18": "17 plus 18 is 35.",
  },
  {
    "what is 17 plus 19": "17 plus 19 is 36.",
  },
  {
    "what is 17 plus 20": "17 plus 20 is 37.",
  },
  {
    "what is 18 plus 1": "18 plus 1 is 19.",
  },
  {
    "what is 18 plus 2": "18 plus 2 is 20.",
  },
  {
    "what is 18 plus 3": "18 plus 3 is 21.",
  },
  {
    "what is 18 plus 4": "18 plus 4 is 22.",
  },
  {
    "what is 18 plus 5": "18 plus 5 is 23.",
  },
  {
    "what is 18 plus 6": "18 plus 6 is 24.",
  },
  {
    "what is 18 plus 7": "18 plus 7 is 25.",
  },
  {
    "what is 18 plus 8": "18 plus 8 is 26.",
  },
  {
    "what is 18 plus 9": "18 plus 9 is 27.",
  },
  {
    "what is 18 plus 10": "18 plus 10 is 28.",
  },
  {
    "what is 18 plus 11": "18 plus 11 is 29.",
  },
  {
    "what is 18 plus 12": "18 plus 12 is 30.",
  },
  {
    "what is 18 plus 13": "18 plus 13 is 31.",
  },
  {
    "what is 18 plus 14": "18 plus 14 is 32.",
  },
  {
    "what is 18 plus 15": "18 plus 15 is 33.",
  },
  {
    "what is 18 plus 16": "18 plus 16 is 34.",
  },
  {
    "what is 18 plus 17": "18 plus 17 is 35.",
  },
  {
    "what is 18 plus 18": "18 plus 18 is 36.",
  },
  {
    "what is 18 plus 19": "18 plus 19 is 37.",
  },
  {
    "what is 18 plus 20": "18 plus 20 is 38.",
  },
  {
    "what is 19 plus 1": "19 plus 1 is 20.",
  },
  {
    "what is 19 plus 2": "19 plus 2 is 21.",
  },
  {
    "what is 19 plus 3": "19 plus 3 is 22.",
  },
  {
    "what is 19 plus 4": "19 plus 4 is 23.",
  },
  {
    "what is 19 plus 5": "19 plus 5 is 24.",
  },
  {
    "what is 19 plus 6": "19 plus 6 is 25.",
  },
  {
    "what is 19 plus 7": "19 plus 7 is 26.",
  },
  {
    "what is 19 plus 8": "19 plus 8 is 27.",
  },
  {
    "what is 19 plus 9": "19 plus 9 is 28.",
  },
  {
    "what is 19 plus 10": "19 plus 10 is 29.",
  },
  {
    "what is 19 plus 11": "19 plus 11 is 30.",
  },
  {
    "what is 19 plus 12": "19 plus 12 is 31.",
  },
  {
    "what is 19 plus 13": "19 plus 13 is 32.",
  },
  {
    "what is 19 plus 14": "19 plus 14 is 33.",
  },
  {
    "what is 19 plus 15": "19 plus 15 is 34.",
  },
  {
    "what is 19 plus 16": "19 plus 16 is 35.",
  },
  {
    "what is 19 plus 17": "19 plus 17 is 36.",
  },
  {
    "what is 19 plus 18": "19 plus 18 is 37.",
  },
  {
    "what is 19 plus 19": "19 plus 19 is 38.",
  },
  {
    "what is 19 plus 20": "19 plus 20 is 39.",
  },
  {
    "what is 20 plus 1": "20 plus 1 is 21.",
  },
  {
    "what is 20 plus 2": "20 plus 2 is 22.",
  },
  {
    "what is 20 plus 3": "20 plus 3 is 23.",
  },
  {
    "what is 20 plus 4": "20 plus 4 is 24.",
  },
  {
    "what is 20 plus 5": "20 plus 5 is 25.",
  },
  {
    "what is 20 plus 6": "20 plus 6 is 26.",
  },
  {
    "what is 20 plus 7": "20 plus 7 is 27.",
  },
  {
    "what is 20 plus 8": "20 plus 8 is 28.",
  },
  {
    "what is 20 plus 9": "20 plus 9 is 29.",
  },
  {
    "what is 20 plus 10": "20 plus 10 is 30.",
  },
  {
    "what is 20 plus 11": "20 plus 11 is 31.",
  },
  {
    "what is 20 plus 12": "20 plus 12 is 32.",
  },
  {
    "what is 20 plus 13": "20 plus 13 is 33.",
  },
  {
    "what is 20 plus 14": "20 plus 14 is 34.",
  },
  {
    "what is 20 plus 15": "20 plus 15 is 35.",
  },
  {
    "what is 20 plus 16": "20 plus 16 is 36.",
  },
  {
    "what is 20 plus 17": "20 plus 17 is 37.",
  },
  {
    "what is 20 plus 18": "20 plus 18 is 38.",
  },
  {
    "what is 20 plus 19": "20 plus 19 is 39.",
  },
  {
    "what is 20 plus 20": "20 plus 20 is 40.",
  },
  {
    "what is 1 minus 1": "1 minus 1 is 0.",
  },
  {
    "what is 2 minus 1": "2 minus 1 is 1.",
  },
  {
    "what is 2 minus 2": "2 minus 2 is 0.",
  },
  {
    "what is 3 minus 1": "3 minus 1 is 2.",
  },
  {
    "what is 3 minus 2": "3 minus 2 is 1.",
  },
  {
    "what is 3 minus 3": "3 minus 3 is 0.",
  },
  {
    "what is 4 minus 1": "4 minus 1 is 3.",
  },
  {
    "what is 4 minus 2": "4 minus 2 is 2.",
  },
  {
    "what is 4 minus 3": "4 minus 3 is 1.",
  },
  {
    "what is 4 minus 4": "4 minus 4 is 0.",
  },
  {
    "what is 5 minus 1": "5 minus 1 is 4.",
  },
  {
    "what is 5 minus 2": "5 minus 2 is 3.",
  },
  {
    "what is 5 minus 3": "5 minus 3 is 2.",
  },
  {
    "what is 5 minus 4": "5 minus 4 is 1.",
  },
  {
    "what is 5 minus 5": "5 minus 5 is 0.",
  },
  {
    "what is 6 minus 1": "6 minus 1 is 5.",
  },
  {
    "what is 6 minus 2": "6 minus 2 is 4.",
  },
  {
    "what is 6 minus 3": "6 minus 3 is 3.",
  },
  {
    "what is 6 minus 4": "6 minus 4 is 2.",
  },
  {
    "what is 6 minus 5": "6 minus 5 is 1.",
  },
  {
    "what is 6 minus 6": "6 minus 6 is 0.",
  },
  {
    "what is 7 minus 1": "7 minus 1 is 6.",
  },
  {
    "what is 7 minus 2": "7 minus 2 is 5.",
  },
  {
    "what is 7 minus 3": "7 minus 3 is 4.",
  },
  {
    "what is 7 minus 4": "7 minus 4 is 3.",
  },
  {
    "what is 7 minus 5": "7 minus 5 is 2.",
  },
  {
    "what is 7 minus 6": "7 minus 6 is 1.",
  },
  {
    "what is 7 minus 7": "7 minus 7 is 0.",
  },
  {
    "what is 8 minus 1": "8 minus 1 is 7.",
  },
  {
    "what is 8 minus 2": "8 minus 2 is 6.",
  },
  {
    "what is 8 minus 3": "8 minus 3 is 5.",
  },
  {
    "what is 8 minus 4": "8 minus 4 is 4.",
  },
  {
    "what is 8 minus 5": "8 minus 5 is 3.",
  },
  {
    "what is 8 minus 6": "8 minus 6 is 2.",
  },
  {
    "what is 8 minus 7": "8 minus 7 is 1.",
  },
  {
    "what is 8 minus 8": "8 minus 8 is 0.",
  },
  {
    "what is 9 minus 1": "9 minus 1 is 8.",
  },
  {
    "what is 9 minus 2": "9 minus 2 is 7.",
  },
  {
    "what is 9 minus 3": "9 minus 3 is 6.",
  },
  {
    "what is 9 minus 4": "9 minus 4 is 5.",
  },
  {
    "what is 9 minus 5": "9 minus 5 is 4.",
  },
  {
    "what is 9 minus 6": "9 minus 6 is 3.",
  },
  {
    "what is 9 minus 7": "9 minus 7 is 2.",
  },
  {
    "what is 9 minus 8": "9 minus 8 is 1.",
  },
  {
    "what is 9 minus 9": "9 minus 9 is 0.",
  },
  {
    "what is 10 minus 1": "10 minus 1 is 9.",
  },
  {
    "what is 10 minus 2": "10 minus 2 is 8.",
  },
  {
    "what is 10 minus 3": "10 minus 3 is 7.",
  },
  {
    "what is 10 minus 4": "10 minus 4 is 6.",
  },
  {
    "what is 10 minus 5": "10 minus 5 is 5.",
  },
  {
    "what is 10 minus 6": "10 minus 6 is 4.",
  },
  {
    "what is 10 minus 7": "10 minus 7 is 3.",
  },
  {
    "what is 10 minus 8": "10 minus 8 is 2.",
  },
  {
    "what is 10 minus 9": "10 minus 9 is 1.",
  },
  {
    "what is 10 minus 10": "10 minus 10 is 0.",
  },
  {
    "what is 11 minus 1": "11 minus 1 is 10.",
  },
  {
    "what is 11 minus 2": "11 minus 2 is 9.",
  },
  {
    "what is 11 minus 3": "11 minus 3 is 8.",
  },
  {
    "what is 11 minus 4": "11 minus 4 is 7.",
  },
  {
    "what is 11 minus 5": "11 minus 5 is 6.",
  },
  {
    "what is 11 minus 6": "11 minus 6 is 5.",
  },
  {
    "what is 11 minus 7": "11 minus 7 is 4.",
  },
  {
    "what is 11 minus 8": "11 minus 8 is 3.",
  },
  {
    "what is 11 minus 9": "11 minus 9 is 2.",
  },
  {
    "what is 11 minus 10": "11 minus 10 is 1.",
  },
  {
    "what is 11 minus 11": "11 minus 11 is 0.",
  },
  {
    "what is 12 minus 1": "12 minus 1 is 11.",
  },
  {
    "what is 12 minus 2": "12 minus 2 is 10.",
  },
  {
    "what is 12 minus 3": "12 minus 3 is 9.",
  },
  {
    "what is 12 minus 4": "12 minus 4 is 8.",
  },
  {
    "what is 12 minus 5": "12 minus 5 is 7.",
  },
  {
    "what is 12 minus 6": "12 minus 6 is 6.",
  },
  {
    "what is 12 minus 7": "12 minus 7 is 5.",
  },
  {
    "what is 12 minus 8": "12 minus 8 is 4.",
  },
  {
    "what is 12 minus 9": "12 minus 9 is 3.",
  },
  {
    "what is 12 minus 10": "12 minus 10 is 2.",
  },
  {
    "what is 12 minus 11": "12 minus 11 is 1.",
  },
  {
    "what is 12 minus 12": "12 minus 12 is 0.",
  },
  {
    "what is 13 minus 1": "13 minus 1 is 12.",
  },
  {
    "what is 13 minus 2": "13 minus 2 is 11.",
  },
  {
    "what is 13 minus 3": "13 minus 3 is 10.",
  },
  {
    "what is 13 minus 4": "13 minus 4 is 9.",
  },
  {
    "what is 13 minus 5": "13 minus 5 is 8.",
  },
  {
    "what is 13 minus 6": "13 minus 6 is 7.",
  },
  {
    "what is 13 minus 7": "13 minus 7 is 6.",
  },
  {
    "what is 13 minus 8": "13 minus 8 is 5.",
  },
  {
    "what is 13 minus 9": "13 minus 9 is 4.",
  },
  {
    "what is 13 minus 10": "13 minus 10 is 3.",
  },
  {
    "what is 13 minus 11": "13 minus 11 is 2.",
  },
  {
    "what is 13 minus 12": "13 minus 12 is 1.",
  },
  {
    "what is 13 minus 13": "13 minus 13 is 0.",
  },
  {
    "what is 14 minus 1": "14 minus 1 is 13.",
  },
  {
    "what is 14 minus 2": "14 minus 2 is 12.",
  },
  {
    "what is 14 minus 3": "14 minus 3 is 11.",
  },
  {
    "what is 14 minus 4": "14 minus 4 is 10.",
  },
  {
    "what is 14 minus 5": "14 minus 5 is 9.",
  },
  {
    "what is 14 minus 6": "14 minus 6 is 8.",
  },
  {
    "what is 14 minus 7": "14 minus 7 is 7.",
  },
  {
    "what is 14 minus 8": "14 minus 8 is 6.",
  },
  {
    "what is 14 minus 9": "14 minus 9 is 5.",
  },
  {
    "what is 14 minus 10": "14 minus 10 is 4.",
  },
  {
    "what is 14 minus 11": "14 minus 11 is 3.",
  },
  {
    "what is 14 minus 12": "14 minus 12 is 2.",
  },
  {
    "what is 14 minus 13": "14 minus 13 is 1.",
  },
  {
    "what is 14 minus 14": "14 minus 14 is 0.",
  },
  {
    "what is 15 minus 1": "15 minus 1 is 14.",
  },
  {
    "what is 15 minus 2": "15 minus 2 is 13.",
  },
  {
    "what is 15 minus 3": "15 minus 3 is 12.",
  },
  {
    "what is 15 minus 4": "15 minus 4 is 11.",
  },
  {
    "what is 15 minus 5": "15 minus 5 is 10.",
  },
  {
    "what is 15 minus 6": "15 minus 6 is 9.",
  },
  {
    "what is 15 minus 7": "15 minus 7 is 8.",
  },
  {
    "what is 15 minus 8": "15 minus 8 is 7.",
  },
  {
    "what is 15 minus 9": "15 minus 9 is 6.",
  },
  {
    "what is 15 minus 10": "15 minus 10 is 5.",
  },
  {
    "what is 15 minus 11": "15 minus 11 is 4.",
  },
  {
    "what is 15 minus 12": "15 minus 12 is 3.",
  },
  {
    "what is 15 minus 13": "15 minus 13 is 2.",
  },
  {
    "what is 15 minus 14": "15 minus 14 is 1.",
  },
  {
    "what is 15 minus 15": "15 minus 15 is 0.",
  },
  {
    "what is 16 minus 1": "16 minus 1 is 15.",
  },
  {
    "what is 16 minus 2": "16 minus 2 is 14.",
  },
  {
    "what is 16 minus 3": "16 minus 3 is 13.",
  },
  {
    "what is 16 minus 4": "16 minus 4 is 12.",
  },
  {
    "what is 16 minus 5": "16 minus 5 is 11.",
  },
  {
    "what is 16 minus 6": "16 minus 6 is 10.",
  },
  {
    "what is 16 minus 7": "16 minus 7 is 9.",
  },
  {
    "what is 16 minus 8": "16 minus 8 is 8.",
  },
  {
    "what is 16 minus 9": "16 minus 9 is 7.",
  },
  {
    "what is 16 minus 10": "16 minus 10 is 6.",
  },
  {
    "what is 16 minus 11": "16 minus 11 is 5.",
  },
  {
    "what is 16 minus 12": "16 minus 12 is 4.",
  },
  {
    "what is 16 minus 13": "16 minus 13 is 3.",
  },
  {
    "what is 16 minus 14": "16 minus 14 is 2.",
  },
  {
    "what is 16 minus 15": "16 minus 15 is 1.",
  },
  {
    "what is 16 minus 16": "16 minus 16 is 0.",
  },
  {
    "what is 17 minus 1": "17 minus 1 is 16.",
  },
  {
    "what is 17 minus 2": "17 minus 2 is 15.",
  },
  {
    "what is 17 minus 3": "17 minus 3 is 14.",
  },
  {
    "what is 17 minus 4": "17 minus 4 is 13.",
  },
  {
    "what is 17 minus 5": "17 minus 5 is 12.",
  },
  {
    "what is 17 minus 6": "17 minus 6 is 11.",
  },
  {
    "what is 17 minus 7": "17 minus 7 is 10.",
  },
  {
    "what is 17 minus 8": "17 minus 8 is 9.",
  },
  {
    "what is 17 minus 9": "17 minus 9 is 8.",
  },
  {
    "what is 17 minus 10": "17 minus 10 is 7.",
  },
  {
    "what is 17 minus 11": "17 minus 11 is 6.",
  },
  {
    "what is 17 minus 12": "17 minus 12 is 5.",
  },
  {
    "what is 17 minus 13": "17 minus 13 is 4.",
  },
  {
    "what is 17 minus 14": "17 minus 14 is 3.",
  },
  {
    "what is 17 minus 15": "17 minus 15 is 2.",
  },
  {
    "what is 17 minus 16": "17 minus 16 is 1.",
  },
  {
    "what is 17 minus 17": "17 minus 17 is 0.",
  },
  {
    "what is 18 minus 1": "18 minus 1 is 17.",
  },
  {
    "what is 18 minus 2": "18 minus 2 is 16.",
  },
  {
    "what is 18 minus 3": "18 minus 3 is 15.",
  },
  {
    "what is 18 minus 4": "18 minus 4 is 14.",
  },
  {
    "what is 18 minus 5": "18 minus 5 is 13.",
  },
  {
    "what is 18 minus 6": "18 minus 6 is 12.",
  },
  {
    "what is 18 minus 7": "18 minus 7 is 11.",
  },
  {
    "what is 18 minus 8": "18 minus 8 is 10.",
  },
  {
    "what is 18 minus 9": "18 minus 9 is 9.",
  },
  {
    "what is 18 minus 10": "18 minus 10 is 8.",
  },
  {
    "what is 18 minus 11": "18 minus 11 is 7.",
  },
  {
    "what is 18 minus 12": "18 minus 12 is 6.",
  },
  {
    "what is 18 minus 13": "18 minus 13 is 5.",
  },
  {
    "what is 18 minus 14": "18 minus 14 is 4.",
  },
  {
    "what is 18 minus 15": "18 minus 15 is 3.",
  },
  {
    "what is 18 minus 16": "18 minus 16 is 2.",
  },
  {
    "what is 18 minus 17": "18 minus 17 is 1.",
  },
  {
    "what is 18 minus 18": "18 minus 18 is 0.",
  },
  {
    "what is 19 minus 1": "19 minus 1 is 18.",
  },
  {
    "what is 19 minus 2": "19 minus 2 is 17.",
  },
  {
    "what is 19 minus 3": "19 minus 3 is 16.",
  },
  {
    "what is 19 minus 4": "19 minus 4 is 15.",
  },
  {
    "what is 19 minus 5": "19 minus 5 is 14.",
  },
  {
    "what is 19 minus 6": "19 minus 6 is 13.",
  },
  {
    "what is 19 minus 7": "19 minus 7 is 12.",
  },
  {
    "what is 19 minus 8": "19 minus 8 is 11.",
  },
  {
    "what is 19 minus 9": "19 minus 9 is 10.",
  },
  {
    "what is 19 minus 10": "19 minus 10 is 9.",
  },
  {
    "what is 19 minus 11": "19 minus 11 is 8.",
  },
  {
    "what is 19 minus 12": "19 minus 12 is 7.",
  },
  {
    "what is 19 minus 13": "19 minus 13 is 6.",
  },
  {
    "what is 19 minus 14": "19 minus 14 is 5.",
  },
  {
    "what is 19 minus 15": "19 minus 15 is 4.",
  },
  {
    "what is 19 minus 16": "19 minus 16 is 3.",
  },
  {
    "what is 19 minus 17": "19 minus 17 is 2.",
  },
  {
    "what is 19 minus 18": "19 minus 18 is 1.",
  },
  {
    "what is 19 minus 19": "19 minus 19 is 0.",
  },
  {
    "what is 20 minus 1": "20 minus 1 is 19.",
  },
  {
    "what is 20 minus 2": "20 minus 2 is 18.",
  },
  {
    "what is 20 minus 3": "20 minus 3 is 17.",
  },
  {
    "what is 20 minus 4": "20 minus 4 is 16.",
  },
  {
    "what is 20 minus 5": "20 minus 5 is 15.",
  },
  {
    "what is 20 minus 6": "20 minus 6 is 14.",
  },
  {
    "what is 20 minus 7": "20 minus 7 is 13.",
  },
  {
    "what is 20 minus 8": "20 minus 8 is 12.",
  },
  {
    "what is 20 minus 9": "20 minus 9 is 11.",
  },
  {
    "what is 20 minus 10": "20 minus 10 is 10.",
  },
  {
    "what is 20 minus 11": "20 minus 11 is 9.",
  },
  {
    "what is 20 minus 12": "20 minus 12 is 8.",
  },
  {
    "what is 20 minus 13": "20 minus 13 is 7.",
  },
  {
    "what is 20 minus 14": "20 minus 14 is 6.",
  },
  {
    "what is 20 minus 15": "20 minus 15 is 5.",
  },
  {
    "what is 20 minus 16": "20 minus 16 is 4.",
  },
  {
    "what is 20 minus 17": "20 minus 17 is 3.",
  },
  {
    "what is 20 minus 18": "20 minus 18 is 2.",
  },
  {
    "what is 20 minus 19": "20 minus 19 is 1.",
  },
  {
    "what is 20 minus 20": "20 minus 20 is 0.",
  },
  {
    "what is 1 divided by 1": "1 divided by 1 is 1.",
  },
  {
    "what is 2 divided by 2": "2 divided by 2 is 1.",
  },
  {
    "what is 3 divided by 3": "3 divided by 3 is 1.",
  },
  {
    "what is 4 divided by 4": "4 divided by 4 is 1.",
  },
  {
    "what is 5 divided by 5": "5 divided by 5 is 1.",
  },
  {
    "what is 6 divided by 6": "6 divided by 6 is 1.",
  },
  {
    "what is 7 divided by 7": "7 divided by 7 is 1.",
  },
  {
    "what is 8 divided by 8": "8 divided by 8 is 1.",
  },
  {
    "what is 9 divided by 9": "9 divided by 9 is 1.",
  },
  {
    "what is 10 divided by 10": "10 divided by 10 is 1.",
  },
  {
    "what is 11 divided by 11": "11 divided by 11 is 1.",
  },
  {
    "what is 12 divided by 12": "12 divided by 12 is 1.",
  },
  {
    "what is 2 divided by 1": "2 divided by 1 is 2.",
  },
  {
    "what is 4 divided by 2": "4 divided by 2 is 2.",
  },
  {
    "what is 6 divided by 3": "6 divided by 3 is 2.",
  },
  {
    "what is 8 divided by 4": "8 divided by 4 is 2.",
  },
  {
    "what is 10 divided by 5": "10 divided by 5 is 2.",
  },
  {
    "what is 12 divided by 6": "12 divided by 6 is 2.",
  },
  {
    "what is 14 divided by 7": "14 divided by 7 is 2.",
  },
  {
    "what is 16 divided by 8": "16 divided by 8 is 2.",
  },
  {
    "what is 18 divided by 9": "18 divided by 9 is 2.",
  },
  {
    "what is 20 divided by 10": "20 divided by 10 is 2.",
  },
  {
    "what is 22 divided by 11": "22 divided by 11 is 2.",
  },
  {
    "what is 24 divided by 12": "24 divided by 12 is 2.",
  },
  {
    "what is 3 divided by 1": "3 divided by 1 is 3.",
  },
  {
    "what is 6 divided by 2": "6 divided by 2 is 3.",
  },
  {
    "what is 9 divided by 3": "9 divided by 3 is 3.",
  },
  {
    "what is 12 divided by 4": "12 divided by 4 is 3.",
  },
  {
    "what is 15 divided by 5": "15 divided by 5 is 3.",
  },
  {
    "what is 18 divided by 6": "18 divided by 6 is 3.",
  },
  {
    "what is 21 divided by 7": "21 divided by 7 is 3.",
  },
  {
    "what is 24 divided by 8": "24 divided by 8 is 3.",
  },
  {
    "what is 27 divided by 9": "27 divided by 9 is 3.",
  },
  {
    "what is 30 divided by 10": "30 divided by 10 is 3.",
  },
  {
    "what is 33 divided by 11": "33 divided by 11 is 3.",
  },
  {
    "what is 36 divided by 12": "36 divided by 12 is 3.",
  },
  {
    "what is 4 divided by 1": "4 divided by 1 is 4.",
  },
  {
    "what is 8 divided by 2": "8 divided by 2 is 4.",
  },
  {
    "what is 12 divided by 3": "12 divided by 3 is 4.",
  },
  {
    "what is 16 divided by 4": "16 divided by 4 is 4.",
  },
  {
    "what is 20 divided by 5": "20 divided by 5 is 4.",
  },
  {
    "what is 24 divided by 6": "24 divided by 6 is 4.",
  },
  {
    "what is 28 divided by 7": "28 divided by 7 is 4.",
  },
  {
    "what is 32 divided by 8": "32 divided by 8 is 4.",
  },
  {
    "what is 36 divided by 9": "36 divided by 9 is 4.",
  },
  {
    "what is 40 divided by 10": "40 divided by 10 is 4.",
  },
  {
    "what is 44 divided by 11": "44 divided by 11 is 4.",
  },
  {
    "what is 48 divided by 12": "48 divided by 12 is 4.",
  },
  {
    "what is 5 divided by 1": "5 divided by 1 is 5.",
  },
  {
    "what is 10 divided by 2": "10 divided by 2 is 5.",
  },
  {
    "what is 15 divided by 3": "15 divided by 3 is 5.",
  },
  {
    "what is 20 divided by 4": "20 divided by 4 is 5.",
  },
  {
    "what is 25 divided by 5": "25 divided by 5 is 5.",
  },
  {
    "what is 30 divided by 6": "30 divided by 6 is 5.",
  },
  {
    "what is 35 divided by 7": "35 divided by 7 is 5.",
  },
  {
    "what is 40 divided by 8": "40 divided by 8 is 5.",
  },
  {
    "what is 45 divided by 9": "45 divided by 9 is 5.",
  },
  {
    "what is 50 divided by 10": "50 divided by 10 is 5.",
  },
  {
    "what is 55 divided by 11": "55 divided by 11 is 5.",
  },
  {
    "what is 60 divided by 12": "60 divided by 12 is 5.",
  },
  {
    "what is 6 divided by 1": "6 divided by 1 is 6.",
  },
  {
    "what is 12 divided by 2": "12 divided by 2 is 6.",
  },
  {
    "what is 18 divided by 3": "18 divided by 3 is 6.",
  },
  {
    "what is 24 divided by 4": "24 divided by 4 is 6.",
  },
  {
    "what is 30 divided by 5": "30 divided by 5 is 6.",
  },
  {
    "what is 36 divided by 6": "36 divided by 6 is 6.",
  },
  {
    "what is 42 divided by 7": "42 divided by 7 is 6.",
  },
  {
    "what is 48 divided by 8": "48 divided by 8 is 6.",
  },
  {
    "what is 54 divided by 9": "54 divided by 9 is 6.",
  },
  {
    "what is 60 divided by 10": "60 divided by 10 is 6.",
  },
  {
    "what is 66 divided by 11": "66 divided by 11 is 6.",
  },
  {
    "what is 72 divided by 12": "72 divided by 12 is 6.",
  },
  {
    "what is 7 divided by 1": "7 divided by 1 is 7.",
  },
  {
    "what is 14 divided by 2": "14 divided by 2 is 7.",
  },
  {
    "what is 21 divided by 3": "21 divided by 3 is 7.",
  },
  {
    "what is 28 divided by 4": "28 divided by 4 is 7.",
  },
  {
    "what is 35 divided by 5": "35 divided by 5 is 7.",
  },
  {
    "what is 42 divided by 6": "42 divided by 6 is 7.",
  },
  {
    "what is 49 divided by 7": "49 divided by 7 is 7.",
  },
  {
    "what is 56 divided by 8": "56 divided by 8 is 7.",
  },
  {
    "what is 63 divided by 9": "63 divided by 9 is 7.",
  },
  {
    "what is 70 divided by 10": "70 divided by 10 is 7.",
  },
  {
    "what is 77 divided by 11": "77 divided by 11 is 7.",
  },
  {
    "what is 84 divided by 12": "84 divided by 12 is 7.",
  },
  {
    "what is 8 divided by 1": "8 divided by 1 is 8.",
  },
  {
    "what is 16 divided by 2": "16 divided by 2 is 8.",
  },
  {
    "what is 24 divided by 3": "24 divided by 3 is 8.",
  },
  {
    "what is 32 divided by 4": "32 divided by 4 is 8.",
  },
  {
    "what is 40 divided by 5": "40 divided by 5 is 8.",
  },
  {
    "what is 48 divided by 6": "48 divided by 6 is 8.",
  },
  {
    "what is 56 divided by 7": "56 divided by 7 is 8.",
  },
  {
    "what is 64 divided by 8": "64 divided by 8 is 8.",
  },
  {
    "what is 72 divided by 9": "72 divided by 9 is 8.",
  },
  {
    "what is 80 divided by 10": "80 divided by 10 is 8.",
  },
  {
    "what is 88 divided by 11": "88 divided by 11 is 8.",
  },
  {
    "what is 96 divided by 12": "96 divided by 12 is 8.",
  },
  {
    "what is 9 divided by 1": "9 divided by 1 is 9.",
  },
  {
    "what is 18 divided by 2": "18 divided by 2 is 9.",
  },
  {
    "what is 27 divided by 3": "27 divided by 3 is 9.",
  },
  {
    "what is 36 divided by 4": "36 divided by 4 is 9.",
  },
  {
    "what is 45 divided by 5": "45 divided by 5 is 9.",
  },
  {
    "what is 54 divided by 6": "54 divided by 6 is 9.",
  },
  {
    "what is 63 divided by 7": "63 divided by 7 is 9.",
  },
  {
    "what is 72 divided by 8": "72 divided by 8 is 9.",
  },
  {
    "what is 81 divided by 9": "81 divided by 9 is 9.",
  },
  {
    "what is 90 divided by 10": "90 divided by 10 is 9.",
  },
  {
    "what is 99 divided by 11": "99 divided by 11 is 9.",
  },
  {
    "what is 108 divided by 12": "108 divided by 12 is 9.",
  },
  {
    "what is 10 divided by 1": "10 divided by 1 is 10.",
  },
  {
    "what is 20 divided by 2": "20 divided by 2 is 10.",
  },
  {
    "what is 30 divided by 3": "30 divided by 3 is 10.",
  },
  {
    "what is 40 divided by 4": "40 divided by 4 is 10.",
  },
  {
    "what is 50 divided by 5": "50 divided by 5 is 10.",
  },
  {
    "what is 60 divided by 6": "60 divided by 6 is 10.",
  },
  {
    "what is 70 divided by 7": "70 divided by 7 is 10.",
  },
  {
    "what is 80 divided by 8": "80 divided by 8 is 10.",
  },
  {
    "what is 90 divided by 9": "90 divided by 9 is 10.",
  },
  {
    "what is 100 divided by 10": "100 divided by 10 is 10.",
  },
  {
    "what is 110 divided by 11": "110 divided by 11 is 10.",
  },
  {
    "what is 120 divided by 12": "120 divided by 12 is 10.",
  },
  {
    "what is 11 divided by 1": "11 divided by 1 is 11.",
  },
  {
    "what is 22 divided by 2": "22 divided by 2 is 11.",
  },
  {
    "what is 33 divided by 3": "33 divided by 3 is 11.",
  },
  {
    "what is 44 divided by 4": "44 divided by 4 is 11.",
  },
  {
    "what is 55 divided by 5": "55 divided by 5 is 11.",
  },
  {
    "what is 66 divided by 6": "66 divided by 6 is 11.",
  },
  {
    "what is 77 divided by 7": "77 divided by 7 is 11.",
  },
  {
    "what is 88 divided by 8": "88 divided by 8 is 11.",
  },
  {
    "what is 99 divided by 9": "99 divided by 9 is 11.",
  },
  {
    "what is 110 divided by 10": "110 divided by 10 is 11.",
  },
  {
    "what is 121 divided by 11": "121 divided by 11 is 11.",
  },
  {
    "what is 132 divided by 12": "132 divided by 12 is 11.",
  },
  {
    "what is 12 divided by 1": "12 divided by 1 is 12.",
  },
  {
    "what is 24 divided by 2": "24 divided by 2 is 12.",
  },
  {
    "what is 36 divided by 3": "36 divided by 3 is 12.",
  },
  {
    "what is 48 divided by 4": "48 divided by 4 is 12.",
  },
  {
    "what is 60 divided by 5": "60 divided by 5 is 12.",
  },
  {
    "what is 72 divided by 6": "72 divided by 6 is 12.",
  },
  {
    "what is 84 divided by 7": "84 divided by 7 is 12.",
  },
  {
    "what is 96 divided by 8": "96 divided by 8 is 12.",
  },
  {
    "what is 108 divided by 9": "108 divided by 9 is 12.",
  },
  {
    "what is 120 divided by 10": "120 divided by 10 is 12.",
  },
  {
    "what is 132 divided by 11": "132 divided by 11 is 12.",
  },
  {
    "what is 144 divided by 12": "144 divided by 12 is 12.",
  },
  {
    "what is the square of 1": "The square of 1 is 1.",
  },
  {
    "what is the square root of 1": "The square root of 1 is 1.",
  },
  {
    "what is the square of 2": "The square of 2 is 4.",
  },
  {
    "what is the square root of 4": "The square root of 4 is 2.",
  },
  {
    "what is the square of 3": "The square of 3 is 9.",
  },
  {
    "what is the square root of 9": "The square root of 9 is 3.",
  },
  {
    "what is the square of 4": "The square of 4 is 16.",
  },
  {
    "what is the square root of 16": "The square root of 16 is 4.",
  },
  {
    "what is the square of 5": "The square of 5 is 25.",
  },
  {
    "what is the square root of 25": "The square root of 25 is 5.",
  },
  {
    "what is the square of 6": "The square of 6 is 36.",
  },
  {
    "what is the square root of 36": "The square root of 36 is 6.",
  },
  {
    "what is the square of 7": "The square of 7 is 49.",
  },
  {
    "what is the square root of 49": "The square root of 49 is 7.",
  },
  {
    "what is the square of 8": "The square of 8 is 64.",
  },
  {
    "what is the square root of 64": "The square root of 64 is 8.",
  },
  {
    "what is the square of 9": "The square of 9 is 81.",
  },
  {
    "what is the square root of 81": "The square root of 81 is 9.",
  },
  {
    "what is the square of 10": "The square of 10 is 100.",
  },
  {
    "what is the square root of 100": "The square root of 100 is 10.",
  },
  {
    "what is the square of 11": "The square of 11 is 121.",
  },
  {
    "what is the square root of 121": "The square root of 121 is 11.",
  },
  {
    "what is the square of 12": "The square of 12 is 144.",
  },
  {
    "what is the square root of 144": "The square root of 144 is 12.",
  },
  {
    "what is the square of 13": "The square of 13 is 169.",
  },
  {
    "what is the square root of 169": "The square root of 169 is 13.",
  },
  {
    "what is the square of 14": "The square of 14 is 196.",
  },
  {
    "what is the square root of 196": "The square root of 196 is 14.",
  },
  {
    "what is the square of 15": "The square of 15 is 225.",
  },
  {
    "what is the square root of 225": "The square root of 225 is 15.",
  },
  {
    "what is the square of 16": "The square of 16 is 256.",
  },
  {
    "what is the square root of 256": "The square root of 256 is 16.",
  },
  {
    "what is the square of 17": "The square of 17 is 289.",
  },
  {
    "what is the square root of 289": "The square root of 289 is 17.",
  },
  {
    "what is the square of 18": "The square of 18 is 324.",
  },
  {
    "what is the square root of 324": "The square root of 324 is 18.",
  },
  {
    "what is the square of 19": "The square of 19 is 361.",
  },
  {
    "what is the square root of 361": "The square root of 361 is 19.",
  },
  {
    "what is the square of 20": "The square of 20 is 400.",
  },
  {
    "what is the square root of 400": "The square root of 400 is 20.",
  },
  {
    "what is the square of 21": "The square of 21 is 441.",
  },
  {
    "what is the square root of 441": "The square root of 441 is 21.",
  },
  {
    "what is the square of 22": "The square of 22 is 484.",
  },
  {
    "what is the square root of 484": "The square root of 484 is 22.",
  },
  {
    "what is the square of 23": "The square of 23 is 529.",
  },
  {
    "what is the square root of 529": "The square root of 529 is 23.",
  },
  {
    "what is the square of 24": "The square of 24 is 576.",
  },
  {
    "what is the square root of 576": "The square root of 576 is 24.",
  },
  {
    "what is the square of 25": "The square of 25 is 625.",
  },
  {
    "what is the square root of 625": "The square root of 625 is 25.",
  },
  {
    "what is the square of 26": "The square of 26 is 676.",
  },
  {
    "what is the square root of 676": "The square root of 676 is 26.",
  },
  {
    "what is the square of 27": "The square of 27 is 729.",
  },
  {
    "what is the square root of 729": "The square root of 729 is 27.",
  },
  {
    "what is the square of 28": "The square of 28 is 784.",
  },
  {
    "what is the square root of 784": "The square root of 784 is 28.",
  },
  {
    "what is the square of 29": "The square of 29 is 841.",
  },
  {
    "what is the square root of 841": "The square root of 841 is 29.",
  },
  {
    "what is the square of 30": "The square of 30 is 900.",
  },
  {
    "what is the square root of 900": "The square root of 900 is 30.",
  },
  {
    "what is the square of 31": "The square of 31 is 961.",
  },
  {
    "what is the square root of 961": "The square root of 961 is 31.",
  },
  {
    "what is the square of 32": "The square of 32 is 1024.",
  },
  {
    "what is the square root of 1024": "The square root of 1024 is 32.",
  },
  {
    "what is the square of 33": "The square of 33 is 1089.",
  },
  {
    "what is the square root of 1089": "The square root of 1089 is 33.",
  },
  {
    "what is the square of 34": "The square of 34 is 1156.",
  },
  {
    "what is the square root of 1156": "The square root of 1156 is 34.",
  },
  {
    "what is the square of 35": "The square of 35 is 1225.",
  },
  {
    "what is the square root of 1225": "The square root of 1225 is 35.",
  },
  {
    "what is the square of 36": "The square of 36 is 1296.",
  },
  {
    "what is the square root of 1296": "The square root of 1296 is 36.",
  },
  {
    "what is the square of 37": "The square of 37 is 1369.",
  },
  {
    "what is the square root of 1369": "The square root of 1369 is 37.",
  },
  {
    "what is the square of 38": "The square of 38 is 1444.",
  },
  {
    "what is the square root of 1444": "The square root of 1444 is 38.",
  },
  {
    "what is the square of 39": "The square of 39 is 1521.",
  },
  {
    "what is the square root of 1521": "The square root of 1521 is 39.",
  },
  {
    "what is the square of 40": "The square of 40 is 1600.",
  },
  {
    "what is the square root of 1600": "The square root of 1600 is 40.",
  },
  {
    "what is the square of 41": "The square of 41 is 1681.",
  },
  {
    "what is the square root of 1681": "The square root of 1681 is 41.",
  },
  {
    "what is the square of 42": "The square of 42 is 1764.",
  },
  {
    "what is the square root of 1764": "The square root of 1764 is 42.",
  },
  {
    "what is the square of 43": "The square of 43 is 1849.",
  },
  {
    "what is the square root of 1849": "The square root of 1849 is 43.",
  },
  {
    "what is the square of 44": "The square of 44 is 1936.",
  },
  {
    "what is the square root of 1936": "The square root of 1936 is 44.",
  },
  {
    "what is the square of 45": "The square of 45 is 2025.",
  },
  {
    "what is the square root of 2025": "The square root of 2025 is 45.",
  },
  {
    "what is the square of 46": "The square of 46 is 2116.",
  },
  {
    "what is the square root of 2116": "The square root of 2116 is 46.",
  },
  {
    "what is the square of 47": "The square of 47 is 2209.",
  },
  {
    "what is the square root of 2209": "The square root of 2209 is 47.",
  },
  {
    "what is the square of 48": "The square of 48 is 2304.",
  },
  {
    "what is the square root of 2304": "The square root of 2304 is 48.",
  },
  {
    "what is the square of 49": "The square of 49 is 2401.",
  },
  {
    "what is the square root of 2401": "The square root of 2401 is 49.",
  },
  {
    "what is the square of 50": "The square of 50 is 2500.",
  },
  {
    "what is the square root of 2500": "The square root of 2500 is 50.",
  },
  {
    "what is the cube of 1": "The cube of 1 is 1.",
  },
  {
    "what is the cube of 2": "The cube of 2 is 8.",
  },
  {
    "what is the cube of 3": "The cube of 3 is 27.",
  },
  {
    "what is the cube of 4": "The cube of 4 is 64.",
  },
  {
    "what is the cube of 5": "The cube of 5 is 125.",
  },
  {
    "what is the cube of 6": "The cube of 6 is 216.",
  },
  {
    "what is the cube of 7": "The cube of 7 is 343.",
  },
  {
    "what is the cube of 8": "The cube of 8 is 512.",
  },
  {
    "what is the cube of 9": "The cube of 9 is 729.",
  },
  {
    "what is the cube of 10": "The cube of 10 is 1000.",
  },
  {
    "what is the cube of 11": "The cube of 11 is 1331.",
  },
  {
    "what is the cube of 12": "The cube of 12 is 1728.",
  },
  {
    "what is the cube of 13": "The cube of 13 is 2197.",
  },
  {
    "what is the cube of 14": "The cube of 14 is 2744.",
  },
  {
    "what is the cube of 15": "The cube of 15 is 3375.",
  },
  {
    "what is the cube of 16": "The cube of 16 is 4096.",
  },
  {
    "what is the cube of 17": "The cube of 17 is 4913.",
  },
  {
    "what is the cube of 18": "The cube of 18 is 5832.",
  },
  {
    "what is the cube of 19": "The cube of 19 is 6859.",
  },
  {
    "what is the cube of 20": "The cube of 20 is 8000.",
  },
  {
    "what is 1 in roman numerals": "1 in Roman numerals is I.",
  },
  {
    "what is 1 in binary": "1 in binary is 1.",
  },
  {
    "what is 1 in hexadecimal": "1 in hexadecimal is 1.",
  },
  {
    "is 1 prime": "No, 1 is not prime. It is neither prime nor composite.",
  },
  {
    "is 1 even or odd": "1 is odd.",
  },
  {
    "how do you spell 1": "1 is spelled 'one'.",
  },
  {
    "what is 2 in roman numerals": "2 in Roman numerals is II.",
  },
  {
    "what is 2 in binary": "2 in binary is 10.",
  },
  {
    "what is 2 in hexadecimal": "2 in hexadecimal is 2.",
  },
  {
    "is 2 prime": "Yes, 2 is a prime number.",
  },
  {
    "is 2 even or odd": "2 is even.",
  },
  {
    "how do you spell 2": "2 is spelled 'two'.",
  },
  {
    "what is 3 in roman numerals": "3 in Roman numerals is III.",
  },
  {
    "what is 3 in binary": "3 in binary is 11.",
  },
  {
    "what is 3 in hexadecimal": "3 in hexadecimal is 3.",
  },
  {
    "is 3 prime": "Yes, 3 is a prime number.",
  },
  {
    "is 3 even or odd": "3 is odd.",
  },
  {
    "how do you spell 3": "3 is spelled 'three'.",
  },
  {
    "what is 4 in roman numerals": "4 in Roman numerals is IV.",
  },
  {
    "what is 4 in binary": "4 in binary is 100.",
  },
  {
    "what is 4 in hexadecimal": "4 in hexadecimal is 4.",
  },
  {
    "is 4 prime": "No, 4 is not prime. It is divisible by 2.",
  },
  {
    "is 4 even or odd": "4 is even.",
  },
  {
    "how do you spell 4": "4 is spelled 'four'.",
  },
  {
    "what is 5 in roman numerals": "5 in Roman numerals is V.",
  },
  {
    "what is 5 in binary": "5 in binary is 101.",
  },
  {
    "what is 5 in hexadecimal": "5 in hexadecimal is 5.",
  },
  {
    "is 5 prime": "Yes, 5 is a prime number.",
  },
  {
    "is 5 even or odd": "5 is odd.",
  },
  {
    "how do you spell 5": "5 is spelled 'five'.",
  },
  {
    "what is 6 in roman numerals": "6 in Roman numerals is VI.",
  },
  {
    "what is 6 in binary": "6 in binary is 110.",
  },
  {
    "what is 6 in hexadecimal": "6 in hexadecimal is 6.",
  },
  {
    "is 6 prime": "No, 6 is not prime. It is divisible by 2.",
  },
  {
    "is 6 even or odd": "6 is even.",
  },
  {
    "how do you spell 6": "6 is spelled 'six'.",
  },
  {
    "what is 7 in roman numerals": "7 in Roman numerals is VII.",
  },
  {
    "what is 7 in binary": "7 in binary is 111.",
  },
  {
    "what is 7 in hexadecimal": "7 in hexadecimal is 7.",
  },
  {
    "is 7 prime": "Yes, 7 is a prime number.",
  },
  {
    "is 7 even or odd": "7 is odd.",
  },
  {
    "how do you spell 7": "7 is spelled 'seven'.",
  },
  {
    "what is 8 in roman numerals": "8 in Roman numerals is VIII.",
  },
  {
    "what is 8 in binary": "8 in binary is 1000.",
  },
  {
    "what is 8 in hexadecimal": "8 in hexadecimal is 8.",
  },
  {
    "is 8 prime": "No, 8 is not prime. It is divisible by 2.",
  },
  {
    "is 8 even or odd": "8 is even.",
  },
  {
    "how do you spell 8": "8 is spelled 'eight'.",
  },
  {
    "what is 9 in roman numerals": "9 in Roman numerals is IX.",
  },
  {
    "what is 9 in binary": "9 in binary is 1001.",
  },
  {
    "what is 9 in hexadecimal": "9 in hexadecimal is 9.",
  },
  {
    "is 9 prime": "No, 9 is not prime. It is divisible by 3.",
  },
  {
    "is 9 even or odd": "9 is odd.",
  },
  {
    "how do you spell 9": "9 is spelled 'nine'.",
  },
  {
    "what is 10 in roman numerals": "10 in Roman numerals is X.",
  },
  {
    "what is 10 in binary": "10 in binary is 1010.",
  },
  {
    "what is 10 in hexadecimal": "10 in hexadecimal is A.",
  },
  {
    "is 10 prime": "No, 10 is not prime. It is divisible by 2.",
  },
  {
    "is 10 even or odd": "10 is even.",
  },
  {
    "how do you spell 10": "10 is spelled 'ten'.",
  },
  {
    "what is 11 in roman numerals": "11 in Roman numerals is XI.",
  },
  {
    "what is 11 in binary": "11 in binary is 1011.",
  },
  {
    "what is 11 in hexadecimal": "11 in hexadecimal is B.",
  },
  {
    "is 11 prime": "Yes, 11 is a prime number.",
  },
  {
    "is 11 even or odd": "11 is odd.",
  },
  {
    "how do you spell 11": "11 is spelled 'eleven'.",
  },
  {
    "what is 12 in roman numerals": "12 in Roman numerals is XII.",
  },
  {
    "what is 12 in binary": "12 in binary is 1100.",
  },
  {
    "what is 12 in hexadecimal": "12 in hexadecimal is C.",
  },
  {
    "is 12 prime": "No, 12 is not prime. It is divisible by 2.",
  },
  {
    "is 12 even or odd": "12 is even.",
  },
  {
    "how do you spell 12": "12 is spelled 'twelve'.",
  },
  {
    "what is 13 in roman numerals": "13 in Roman numerals is XIII.",
  },
  {
    "what is 13 in binary": "13 in binary is 1101.",
  },
  {
    "what is 13 in hexadecimal": "13 in hexadecimal is D.",
  },
  {
    "is 13 prime": "Yes, 13 is a prime number.",
  },
  {
    "is 13 even or odd": "13 is odd.",
  },
  {
    "how do you spell 13": "13 is spelled 'thirteen'.",
  },
  {
    "what is 14 in roman numerals": "14 in Roman numerals is XIV.",
  },
  {
    "what is 14 in binary": "14 in binary is 1110.",
  },
  {
    "what is 14 in hexadecimal": "14 in hexadecimal is E.",
  },
  {
    "is 14 prime": "No, 14 is not prime. It is divisible by 2.",
  },
  {
    "is 14 even or odd": "14 is even.",
  },
  {
    "how do you spell 14": "14 is spelled 'fourteen'.",
  },
  {
    "what is 15 in roman numerals": "15 in Roman numerals is XV.",
  },
  {
    "what is 15 in binary": "15 in binary is 1111.",
  },
  {
    "what is 15 in hexadecimal": "15 in hexadecimal is F.",
  },
  {
    "is 15 prime": "No, 15 is not prime. It is divisible by 3.",
  },
  {
    "is 15 even or odd": "15 is odd.",
  },
  {
    "how do you spell 15": "15 is spelled 'fifteen'.",
  },
  {
    "what is 16 in roman numerals": "16 in Roman numerals is XVI.",
  },
  {
    "what is 16 in binary": "16 in binary is 10000.",
  },
  {
    "what is 16 in hexadecimal": "16 in hexadecimal is 10.",
  },
  {
    "is 16 prime": "No, 16 is not prime. It is divisible by 2.",
  },
  {
    "is 16 even or odd": "16 is even.",
  },
  {
    "how do you spell 16": "16 is spelled 'sixteen'.",
  },
  {
    "what is 17 in roman numerals": "17 in Roman numerals is XVII.",
  },
  {
    "what is 17 in binary": "17 in binary is 10001.",
  },
  {
    "what is 17 in hexadecimal": "17 in hexadecimal is 11.",
  },
  {
    "is 17 prime": "Yes, 17 is a prime number.",
  },
  {
    "is 17 even or odd": "17 is odd.",
  },
  {
    "how do you spell 17": "17 is spelled 'seventeen'.",
  },
  {
    "what is 18 in roman numerals": "18 in Roman numerals is XVIII.",
  },
  {
    "what is 18 in binary": "18 in binary is 10010.",
  },
  {
    "what is 18 in hexadecimal": "18 in hexadecimal is 12.",
  },
  {
    "is 18 prime": "No, 18 is not prime. It is divisible by 2.",
  },
  {
    "is 18 even or odd": "18 is even.",
  },
  {
    "how do you spell 18": "18 is spelled 'eighteen'.",
  },
  {
    "what is 19 in roman numerals": "19 in Roman numerals is XIX.",
  },
  {
    "what is 19 in binary": "19 in binary is 10011.",
  },
  {
    "what is 19 in hexadecimal": "19 in hexadecimal is 13.",
  },
  {
    "is 19 prime": "Yes, 19 is a prime number.",
  },
  {
    "is 19 even or odd": "19 is odd.",
  },
  {
    "how do you spell 19": "19 is spelled 'nineteen'.",
  },
  {
    "what is 20 in roman numerals": "20 in Roman numerals is XX.",
  },
  {
    "what is 20 in binary": "20 in binary is 10100.",
  },
  {
    "what is 20 in hexadecimal": "20 in hexadecimal is 14.",
  },
  {
    "is 20 prime": "No, 20 is not prime. It is divisible by 2.",
  },
  {
    "is 20 even or odd": "20 is even.",
  },
  {
    "how do you spell 20": "20 is spelled 'twenty'.",
  },
  {
    "what is 21 in roman numerals": "21 in Roman numerals is XXI.",
  },
  {
    "what is 21 in binary": "21 in binary is 10101.",
  },
  {
    "what is 21 in hexadecimal": "21 in hexadecimal is 15.",
  },
  {
    "is 21 prime": "No, 21 is not prime. It is divisible by 3.",
  },
  {
    "is 21 even or odd": "21 is odd.",
  },
  {
    "how do you spell 21": "21 is spelled 'twenty-one'.",
  },
  {
    "what is 22 in roman numerals": "22 in Roman numerals is XXII.",
  },
  {
    "what is 22 in binary": "22 in binary is 10110.",
  },
  {
    "what is 22 in hexadecimal": "22 in hexadecimal is 16.",
  },
  {
    "is 22 prime": "No, 22 is not prime. It is divisible by 2.",
  },
  {
    "is 22 even or odd": "22 is even.",
  },
  {
    "how do you spell 22": "22 is spelled 'twenty-two'.",
  },
  {
    "what is 23 in roman numerals": "23 in Roman numerals is XXIII.",
  },
  {
    "what is 23 in binary": "23 in binary is 10111.",
  },
  {
    "what is 23 in hexadecimal": "23 in hexadecimal is 17.",
  },
  {
    "is 23 prime": "Yes, 23 is a prime number.",
  },
  {
    "is 23 even or odd": "23 is odd.",
  },
  {
    "how do you spell 23": "23 is spelled 'twenty-three'.",
  },
  {
    "what is 24 in roman numerals": "24 in Roman numerals is XXIV.",
  },
  {
    "what is 24 in binary": "24 in binary is 11000.",
  },
  {
    "what is 24 in hexadecimal": "24 in hexadecimal is 18.",
  },
  {
    "is 24 prime": "No, 24 is not prime. It is divisible by 2.",
  },
  {
    "is 24 even or odd": "24 is even.",
  },
  {
    "how do you spell 24": "24 is spelled 'twenty-four'.",
  },
  {
    "what is 25 in roman numerals": "25 in Roman numerals is XXV.",
  },
  {
    "what is 25 in binary": "25 in binary is 11001.",
  },
  {
    "what is 25 in hexadecimal": "25 in hexadecimal is 19.",
  },
  {
    "is 25 prime": "No, 25 is not prime. It is divisible by 5.",
  },
  {
    "is 25 even or odd": "25 is odd.",
  },
  {
    "how do you spell 25": "25 is spelled 'twenty-five'.",
  },
  {
    "what is 26 in roman numerals": "26 in Roman numerals is XXVI.",
  },
  {
    "what is 26 in binary": "26 in binary is 11010.",
  },
  {
    "what is 26 in hexadecimal": "26 in hexadecimal is 1A.",
  },
  {
    "is 26 prime": "No, 26 is not prime. It is divisible by 2.",
  },
  {
    "is 26 even or odd": "26 is even.",
  },
  {
    "how do you spell 26": "26 is spelled 'twenty-six'.",
  },
  {
    "what is 27 in roman numerals": "27 in Roman numerals is XXVII.",
  },
  {
    "what is 27 in binary": "27 in binary is 11011.",
  },
  {
    "what is 27 in hexadecimal": "27 in hexadecimal is 1B.",
  },
  {
    "is 27 prime": "No, 27 is not prime. It is divisible by 3.",
  },
  {
    "is 27 even or odd": "27 is odd.",
  },
  {
    "how do you spell 27": "27 is spelled 'twenty-seven'.",
  },
  {
    "what is 28 in roman numerals": "28 in Roman numerals is XXVIII.",
  },
  {
    "what is 28 in binary": "28 in binary is 11100.",
  },
  {
    "what is 28 in hexadecimal": "28 in hexadecimal is 1C.",
  },
  {
    "is 28 prime": "No, 28 is not prime. It is divisible by 2.",
  },
  {
    "is 28 even or odd": "28 is even.",
  },
  {
    "how do you spell 28": "28 is spelled 'twenty-eight'.",
  },
  {
    "what is 29 in roman numerals": "29 in Roman numerals is XXIX.",
  },
  {
    "what is 29 in binary": "29 in binary is 11101.",
  },
  {
    "what is 29 in hexadecimal": "29 in hexadecimal is 1D.",
  },
  {
    "is 29 prime": "Yes, 29 is a prime number.",
  },
  {
    "is 29 even or odd": "29 is odd.",
  },
  {
    "how do you spell 29": "29 is spelled 'twenty-nine'.",
  },
  {
    "what is 30 in roman numerals": "30 in Roman numerals is XXX.",
  },
  {
    "what is 30 in binary": "30 in binary is 11110.",
  },
  {
    "what is 30 in hexadecimal": "30 in hexadecimal is 1E.",
  },
  {
    "is 30 prime": "No, 30 is not prime. It is divisible by 2.",
  },
  {
    "is 30 even or odd": "30 is even.",
  },
  {
    "how do you spell 30": "30 is spelled 'thirty'.",
  },
  {
    "what is 31 in roman numerals": "31 in Roman numerals is XXXI.",
  },
  {
    "what is 31 in binary": "31 in binary is 11111.",
  },
  {
    "what is 31 in hexadecimal": "31 in hexadecimal is 1F.",
  },
  {
    "is 31 prime": "Yes, 31 is a prime number.",
  },
  {
    "is 31 even or odd": "31 is odd.",
  },
  {
    "how do you spell 31": "31 is spelled 'thirty-one'.",
  },
  {
    "what is 32 in roman numerals": "32 in Roman numerals is XXXII.",
  },
  {
    "what is 32 in binary": "32 in binary is 100000.",
  },
  {
    "what is 32 in hexadecimal": "32 in hexadecimal is 20.",
  },
  {
    "is 32 prime": "No, 32 is not prime. It is divisible by 2.",
  },
  {
    "is 32 even or odd": "32 is even.",
  },
  {
    "how do you spell 32": "32 is spelled 'thirty-two'.",
  },
  {
    "what is 33 in roman numerals": "33 in Roman numerals is XXXIII.",
  },
  {
    "what is 33 in binary": "33 in binary is 100001.",
  },
  {
    "what is 33 in hexadecimal": "33 in hexadecimal is 21.",
  },
  {
    "is 33 prime": "No, 33 is not prime. It is divisible by 3.",
  },
  {
    "is 33 even or odd": "33 is odd.",
  },
  {
    "how do you spell 33": "33 is spelled 'thirty-three'.",
  },
  {
    "what is 34 in roman numerals": "34 in Roman numerals is XXXIV.",
  },
  {
    "what is 34 in binary": "34 in binary is 100010.",
  },
  {
    "what is 34 in hexadecimal": "34 in hexadecimal is 22.",
  },
  {
    "is 34 prime": "No, 34 is not prime. It is divisible by 2.",
  },
  {
    "is 34 even or odd": "34 is even.",
  },
  {
    "how do you spell 34": "34 is spelled 'thirty-four'.",
  },
  {
    "what is 35 in roman numerals": "35 in Roman numerals is XXXV.",
  },
  {
    "what is 35 in binary": "35 in binary is 100011.",
  },
  {
    "what is 35 in hexadecimal": "35 in hexadecimal is 23.",
  },
  {
    "is 35 prime": "No, 35 is not prime. It is divisible by 5.",
  },
  {
    "is 35 even or odd": "35 is odd.",
  },
  {
    "how do you spell 35": "35 is spelled 'thirty-five'.",
  },
  {
    "what is 36 in roman numerals": "36 in Roman numerals is XXXVI.",
  },
  {
    "what is 36 in binary": "36 in binary is 100100.",
  },
  {
    "what is 36 in hexadecimal": "36 in hexadecimal is 24.",
  },
  {
    "is 36 prime": "No, 36 is not prime. It is divisible by 2.",
  },
  {
    "is 36 even or odd": "36 is even.",
  },
  {
    "how do you spell 36": "36 is spelled 'thirty-six'.",
  },
  {
    "what is 37 in roman numerals": "37 in Roman numerals is XXXVII.",
  },
  {
    "what is 37 in binary": "37 in binary is 100101.",
  },
  {
    "what is 37 in hexadecimal": "37 in hexadecimal is 25.",
  },
  {
    "is 37 prime": "Yes, 37 is a prime number.",
  },
  {
    "is 37 even or odd": "37 is odd.",
  },
  {
    "how do you spell 37": "37 is spelled 'thirty-seven'.",
  },
  {
    "what is 38 in roman numerals": "38 in Roman numerals is XXXVIII.",
  },
  {
    "what is 38 in binary": "38 in binary is 100110.",
  },
  {
    "what is 38 in hexadecimal": "38 in hexadecimal is 26.",
  },
  {
    "is 38 prime": "No, 38 is not prime. It is divisible by 2.",
  },
  {
    "is 38 even or odd": "38 is even.",
  },
  {
    "how do you spell 38": "38 is spelled 'thirty-eight'.",
  },
  {
    "what is 39 in roman numerals": "39 in Roman numerals is XXXIX.",
  },
  {
    "what is 39 in binary": "39 in binary is 100111.",
  },
  {
    "what is 39 in hexadecimal": "39 in hexadecimal is 27.",
  },
  {
    "is 39 prime": "No, 39 is not prime. It is divisible by 3.",
  },
  {
    "is 39 even or odd": "39 is odd.",
  },
  {
    "how do you spell 39": "39 is spelled 'thirty-nine'.",
  },
  {
    "what is 40 in roman numerals": "40 in Roman numerals is XL.",
  },
  {
    "what is 40 in binary": "40 in binary is 101000.",
  },
  {
    "what is 40 in hexadecimal": "40 in hexadecimal is 28.",
  },
  {
    "is 40 prime": "No, 40 is not prime. It is divisible by 2.",
  },
  {
    "is 40 even or odd": "40 is even.",
  },
  {
    "how do you spell 40": "40 is spelled 'forty'.",
  },
  {
    "what is 41 in roman numerals": "41 in Roman numerals is XLI.",
  },
  {
    "what is 41 in binary": "41 in binary is 101001.",
  },
  {
    "what is 41 in hexadecimal": "41 in hexadecimal is 29.",
  },
  {
    "is 41 prime": "Yes, 41 is a prime number.",
  },
  {
    "is 41 even or odd": "41 is odd.",
  },
  {
    "how do you spell 41": "41 is spelled 'forty-one'.",
  },
  {
    "what is 42 in roman numerals": "42 in Roman numerals is XLII.",
  },
  {
    "what is 42 in binary": "42 in binary is 101010.",
  },
  {
    "what is 42 in hexadecimal": "42 in hexadecimal is 2A.",
  },
  {
    "is 42 prime": "No, 42 is not prime. It is divisible by 2.",
  },
  {
    "is 42 even or odd": "42 is even.",
  },
  {
    "how do you spell 42": "42 is spelled 'forty-two'.",
  },
  {
    "what is 43 in roman numerals": "43 in Roman numerals is XLIII.",
  },
  {
    "what is 43 in binary": "43 in binary is 101011.",
  },
  {
    "what is 43 in hexadecimal": "43 in hexadecimal is 2B.",
  },
  {
    "is 43 prime": "Yes, 43 is a prime number.",
  },
  {
    "is 43 even or odd": "43 is odd.",
  },
  {
    "how do you spell 43": "43 is spelled 'forty-three'.",
  },
  {
    "what is 44 in roman numerals": "44 in Roman numerals is XLIV.",
  },
  {
    "what is 44 in binary": "44 in binary is 101100.",
  },
  {
    "what is 44 in hexadecimal": "44 in hexadecimal is 2C.",
  },
  {
    "is 44 prime": "No, 44 is not prime. It is divisible by 2.",
  },
  {
    "is 44 even or odd": "44 is even.",
  },
  {
    "how do you spell 44": "44 is spelled 'forty-four'.",
  },
  {
    "what is 45 in roman numerals": "45 in Roman numerals is XLV.",
  },
  {
    "what is 45 in binary": "45 in binary is 101101.",
  },
  {
    "what is 45 in hexadecimal": "45 in hexadecimal is 2D.",
  },
  {
    "is 45 prime": "No, 45 is not prime. It is divisible by 3.",
  },
  {
    "is 45 even or odd": "45 is odd.",
  },
  {
    "how do you spell 45": "45 is spelled 'forty-five'.",
  },
  {
    "what is 46 in roman numerals": "46 in Roman numerals is XLVI.",
  },
  {
    "what is 46 in binary": "46 in binary is 101110.",
  },
  {
    "what is 46 in hexadecimal": "46 in hexadecimal is 2E.",
  },
  {
    "is 46 prime": "No, 46 is not prime. It is divisible by 2.",
  },
  {
    "is 46 even or odd": "46 is even.",
  },
  {
    "how do you spell 46": "46 is spelled 'forty-six'.",
  },
  {
    "what is 47 in roman numerals": "47 in Roman numerals is XLVII.",
  },
  {
    "what is 47 in binary": "47 in binary is 101111.",
  },
  {
    "what is 47 in hexadecimal": "47 in hexadecimal is 2F.",
  },
  {
    "is 47 prime": "Yes, 47 is a prime number.",
  },
  {
    "is 47 even or odd": "47 is odd.",
  },
  {
    "how do you spell 47": "47 is spelled 'forty-seven'.",
  },
  {
    "what is 48 in roman numerals": "48 in Roman numerals is XLVIII.",
  },
  {
    "what is 48 in binary": "48 in binary is 110000.",
  },
  {
    "what is 48 in hexadecimal": "48 in hexadecimal is 30.",
  },
  {
    "is 48 prime": "No, 48 is not prime. It is divisible by 2.",
  },
  {
    "is 48 even or odd": "48 is even.",
  },
  {
    "how do you spell 48": "48 is spelled 'forty-eight'.",
  },
  {
    "what is 49 in roman numerals": "49 in Roman numerals is XLIX.",
  },
  {
    "what is 49 in binary": "49 in binary is 110001.",
  },
  {
    "what is 49 in hexadecimal": "49 in hexadecimal is 31.",
  },
  {
    "is 49 prime": "No, 49 is not prime. It is divisible by 7.",
  },
  {
    "is 49 even or odd": "49 is odd.",
  },
  {
    "how do you spell 49": "49 is spelled 'forty-nine'.",
  },
  {
    "what is 50 in roman numerals": "50 in Roman numerals is L.",
  },
  {
    "what is 50 in binary": "50 in binary is 110010.",
  },
  {
    "what is 50 in hexadecimal": "50 in hexadecimal is 32.",
  },
  {
    "is 50 prime": "No, 50 is not prime. It is divisible by 2.",
  },
  {
    "is 50 even or odd": "50 is even.",
  },
  {
    "how do you spell 50": "50 is spelled 'fifty'.",
  },
  {
    "what is 51 in roman numerals": "51 in Roman numerals is LI.",
  },
  {
    "what is 51 in binary": "51 in binary is 110011.",
  },
  {
    "what is 51 in hexadecimal": "51 in hexadecimal is 33.",
  },
  {
    "is 51 prime": "No, 51 is not prime. It is divisible by 3.",
  },
  {
    "is 51 even or odd": "51 is odd.",
  },
  {
    "how do you spell 51": "51 is spelled 'fifty-one'.",
  },
  {
    "what is 52 in roman numerals": "52 in Roman numerals is LII.",
  },
  {
    "what is 52 in binary": "52 in binary is 110100.",
  },
  {
    "what is 52 in hexadecimal": "52 in hexadecimal is 34.",
  },
  {
    "is 52 prime": "No, 52 is not prime. It is divisible by 2.",
  },
  {
    "is 52 even or odd": "52 is even.",
  },
  {
    "how do you spell 52": "52 is spelled 'fifty-two'.",
  },
  {
    "what is 53 in roman numerals": "53 in Roman numerals is LIII.",
  },
  {
    "what is 53 in binary": "53 in binary is 110101.",
  },
  {
    "what is 53 in hexadecimal": "53 in hexadecimal is 35.",
  },
  {
    "is 53 prime": "Yes, 53 is a prime number.",
  },
  {
    "is 53 even or odd": "53 is odd.",
  },
  {
    "how do you spell 53": "53 is spelled 'fifty-three'.",
  },
  {
    "what is 54 in roman numerals": "54 in Roman numerals is LIV.",
  },
  {
    "what is 54 in binary": "54 in binary is 110110.",
  },
  {
    "what is 54 in hexadecimal": "54 in hexadecimal is 36.",
  },
  {
    "is 54 prime": "No, 54 is not prime. It is divisible by 2.",
  },
  {
    "is 54 even or odd": "54 is even.",
  },
  {
    "how do you spell 54": "54 is spelled 'fifty-four'.",
  },
  {
    "what is 55 in roman numerals": "55 in Roman numerals is LV.",
  },
  {
    "what is 55 in binary": "55 in binary is 110111.",
  },
  {
    "what is 55 in hexadecimal": "55 in hexadecimal is 37.",
  },
  {
    "is 55 prime": "No, 55 is not prime. It is divisible by 5.",
  },
  {
    "is 55 even or odd": "55 is odd.",
  },
  {
    "how do you spell 55": "55 is spelled 'fifty-five'.",
  },
  {
    "what is 56 in roman numerals": "56 in Roman numerals is LVI.",
  },
  {
    "what is 56 in binary": "56 in binary is 111000.",
  },
  {
    "what is 56 in hexadecimal": "56 in hexadecimal is 38.",
  },
  {
    "is 56 prime": "No, 56 is not prime. It is divisible by 2.",
  },
  {
    "is 56 even or odd": "56 is even.",
  },
  {
    "how do you spell 56": "56 is spelled 'fifty-six'.",
  },
  {
    "what is 57 in roman numerals": "57 in Roman numerals is LVII.",
  },
  {
    "what is 57 in binary": "57 in binary is 111001.",
  },
  {
    "what is 57 in hexadecimal": "57 in hexadecimal is 39.",
  },
  {
    "is 57 prime": "No, 57 is not prime. It is divisible by 3.",
  },
  {
    "is 57 even or odd": "57 is odd.",
  },
  {
    "how do you spell 57": "57 is spelled 'fifty-seven'.",
  },
  {
    "what is 58 in roman numerals": "58 in Roman numerals is LVIII.",
  },
  {
    "what is 58 in binary": "58 in binary is 111010.",
  },
  {
    "what is 58 in hexadecimal": "58 in hexadecimal is 3A.",
  },
  {
    "is 58 prime": "No, 58 is not prime. It is divisible by 2.",
  },
  {
    "is 58 even or odd": "58 is even.",
  },
  {
    "how do you spell 58": "58 is spelled 'fifty-eight'.",
  },
  {
    "what is 59 in roman numerals": "59 in Roman numerals is LIX.",
  },
  {
    "what is 59 in binary": "59 in binary is 111011.",
  },
  {
    "what is 59 in hexadecimal": "59 in hexadecimal is 3B.",
  },
  {
    "is 59 prime": "Yes, 59 is a prime number.",
  },
  {
    "is 59 even or odd": "59 is odd.",
  },
  {
    "how do you spell 59": "59 is spelled 'fifty-nine'.",
  },
  {
    "what is 60 in roman numerals": "60 in Roman numerals is LX.",
  },
  {
    "what is 60 in binary": "60 in binary is 111100.",
  },
  {
    "what is 60 in hexadecimal": "60 in hexadecimal is 3C.",
  },
  {
    "is 60 prime": "No, 60 is not prime. It is divisible by 2.",
  },
  {
    "is 60 even or odd": "60 is even.",
  },
  {
    "how do you spell 60": "60 is spelled 'sixty'.",
  },
  {
    "what is 61 in roman numerals": "61 in Roman numerals is LXI.",
  },
  {
    "what is 61 in binary": "61 in binary is 111101.",
  },
  {
    "what is 61 in hexadecimal": "61 in hexadecimal is 3D.",
  },
  {
    "is 61 prime": "Yes, 61 is a prime number.",
  },
  {
    "is 61 even or odd": "61 is odd.",
  },
  {
    "how do you spell 61": "61 is spelled 'sixty-one'.",
  },
  {
    "what is 62 in roman numerals": "62 in Roman numerals is LXII.",
  },
  {
    "what is 62 in binary": "62 in binary is 111110.",
  },
  {
    "what is 62 in hexadecimal": "62 in hexadecimal is 3E.",
  },
  {
    "is 62 prime": "No, 62 is not prime. It is divisible by 2.",
  },
  {
    "is 62 even or odd": "62 is even.",
  },
  {
    "how do you spell 62": "62 is spelled 'sixty-two'.",
  },
  {
    "what is 63 in roman numerals": "63 in Roman numerals is LXIII.",
  },
  {
    "what is 63 in binary": "63 in binary is 111111.",
  },
  {
    "what is 63 in hexadecimal": "63 in hexadecimal is 3F.",
  },
  {
    "is 63 prime": "No, 63 is not prime. It is divisible by 3.",
  },
  {
    "is 63 even or odd": "63 is odd.",
  },
  {
    "how do you spell 63": "63 is spelled 'sixty-three'.",
  },
  {
    "what is 64 in roman numerals": "64 in Roman numerals is LXIV.",
  },
  {
    "what is 64 in binary": "64 in binary is 1000000.",
  },
  {
    "what is 64 in hexadecimal": "64 in hexadecimal is 40.",
  },
  {
    "is 64 prime": "No, 64 is not prime. It is divisible by 2.",
  },
  {
    "is 64 even or odd": "64 is even.",
  },
  {
    "how do you spell 64": "64 is spelled 'sixty-four'.",
  },
  {
    "what is 65 in roman numerals": "65 in Roman numerals is LXV.",
  },
  {
    "what is 65 in binary": "65 in binary is 1000001.",
  },
  {
    "what is 65 in hexadecimal": "65 in hexadecimal is 41.",
  },
  {
    "is 65 prime": "No, 65 is not prime. It is divisible by 5.",
  },
  {
    "is 65 even or odd": "65 is odd.",
  },
  {
    "how do you spell 65": "65 is spelled 'sixty-five'.",
  },
  {
    "what is 66 in roman numerals": "66 in Roman numerals is LXVI.",
  },
  {
    "what is 66 in binary": "66 in binary is 1000010.",
  },
  {
    "what is 66 in hexadecimal": "66 in hexadecimal is 42.",
  },
  {
    "is 66 prime": "No, 66 is not prime. It is divisible by 2.",
  },
  {
    "is 66 even or odd": "66 is even.",
  },
  {
    "how do you spell 66": "66 is spelled 'sixty-six'.",
  },
  {
    "what is 67 in roman numerals": "67 in Roman numerals is LXVII.",
  },
  {
    "what is 67 in binary": "67 in binary is 1000011.",
  },
  {
    "what is 67 in hexadecimal": "67 in hexadecimal is 43.",
  },
  {
    "is 67 prime": "Yes, 67 is a prime number.",
  },
  {
    "is 67 even or odd": "67 is odd.",
  },
  {
    "how do you spell 67": "67 is spelled 'sixty-seven'.",
  },
  {
    "what is 68 in roman numerals": "68 in Roman numerals is LXVIII.",
  },
  {
    "what is 68 in binary": "68 in binary is 1000100.",
  },
  {
    "what is 68 in hexadecimal": "68 in hexadecimal is 44.",
  },
  {
    "is 68 prime": "No, 68 is not prime. It is divisible by 2.",
  },
  {
    "is 68 even or odd": "68 is even.",
  },
  {
    "how do you spell 68": "68 is spelled 'sixty-eight'.",
  },
  {
    "what is 69 in roman numerals": "69 in Roman numerals is LXIX.",
  },
  {
    "what is 69 in binary": "69 in binary is 1000101.",
  },
  {
    "what is 69 in hexadecimal": "69 in hexadecimal is 45.",
  },
  {
    "is 69 prime": "No, 69 is not prime. It is divisible by 3.",
  },
  {
    "is 69 even or odd": "69 is odd.",
  },
  {
    "how do you spell 69": "69 is spelled 'sixty-nine'.",
  },
  {
    "what is 70 in roman numerals": "70 in Roman numerals is LXX.",
  },
  {
    "what is 70 in binary": "70 in binary is 1000110.",
  },
  {
    "what is 70 in hexadecimal": "70 in hexadecimal is 46.",
  },
  {
    "is 70 prime": "No, 70 is not prime. It is divisible by 2.",
  },
  {
    "is 70 even or odd": "70 is even.",
  },
  {
    "how do you spell 70": "70 is spelled 'seventy'.",
  },
  {
    "what is 71 in roman numerals": "71 in Roman numerals is LXXI.",
  },
  {
    "what is 71 in binary": "71 in binary is 1000111.",
  },
  {
    "what is 71 in hexadecimal": "71 in hexadecimal is 47.",
  },
  {
    "is 71 prime": "Yes, 71 is a prime number.",
  },
  {
    "is 71 even or odd": "71 is odd.",
  },
  {
    "how do you spell 71": "71 is spelled 'seventy-one'.",
  },
  {
    "what is 72 in roman numerals": "72 in Roman numerals is LXXII.",
  },
  {
    "what is 72 in binary": "72 in binary is 1001000.",
  },
  {
    "what is 72 in hexadecimal": "72 in hexadecimal is 48.",
  },
  {
    "is 72 prime": "No, 72 is not prime. It is divisible by 2.",
  },
  {
    "is 72 even or odd": "72 is even.",
  },
  {
    "how do you spell 72": "72 is spelled 'seventy-two'.",
  },
  {
    "what is 73 in roman numerals": "73 in Roman numerals is LXXIII.",
  },
  {
    "what is 73 in binary": "73 in binary is 1001001.",
  },
  {
    "what is 73 in hexadecimal": "73 in hexadecimal is 49.",
  },
  {
    "is 73 prime": "Yes, 73 is a prime number.",
  },
  {
    "is 73 even or odd": "73 is odd.",
  },
  {
    "how do you spell 73": "73 is spelled 'seventy-three'.",
  },
  {
    "what is 74 in roman numerals": "74 in Roman numerals is LXXIV.",
  },
  {
    "what is 74 in binary": "74 in binary is 1001010.",
  },
  {
    "what is 74 in hexadecimal": "74 in hexadecimal is 4A.",
  },
  {
    "is 74 prime": "No, 74 is not prime. It is divisible by 2.",
  },
  {
    "is 74 even or odd": "74 is even.",
  },
  {
    "how do you spell 74": "74 is spelled 'seventy-four'.",
  },
  {
    "what is 75 in roman numerals": "75 in Roman numerals is LXXV.",
  },
  {
    "what is 75 in binary": "75 in binary is 1001011.",
  },
  {
    "what is 75 in hexadecimal": "75 in hexadecimal is 4B.",
  },
  {
    "is 75 prime": "No, 75 is not prime. It is divisible by 3.",
  },
  {
    "is 75 even or odd": "75 is odd.",
  },
  {
    "how do you spell 75": "75 is spelled 'seventy-five'.",
  },
  {
    "what is 76 in roman numerals": "76 in Roman numerals is LXXVI.",
  },
  {
    "what is 76 in binary": "76 in binary is 1001100.",
  },
  {
    "what is 76 in hexadecimal": "76 in hexadecimal is 4C.",
  },
  {
    "is 76 prime": "No, 76 is not prime. It is divisible by 2.",
  },
  {
    "is 76 even or odd": "76 is even.",
  },
  {
    "how do you spell 76": "76 is spelled 'seventy-six'.",
  },
  {
    "what is 77 in roman numerals": "77 in Roman numerals is LXXVII.",
  },
  {
    "what is 77 in binary": "77 in binary is 1001101.",
  },
  {
    "what is 77 in hexadecimal": "77 in hexadecimal is 4D.",
  },
  {
    "is 77 prime": "No, 77 is not prime. It is divisible by 7.",
  },
  {
    "is 77 even or odd": "77 is odd.",
  },
  {
    "how do you spell 77": "77 is spelled 'seventy-seven'.",
  },
  {
    "what is 78 in roman numerals": "78 in Roman numerals is LXXVIII.",
  },
  {
    "what is 78 in binary": "78 in binary is 1001110.",
  },
  {
    "what is 78 in hexadecimal": "78 in hexadecimal is 4E.",
  },
  {
    "is 78 prime": "No, 78 is not prime. It is divisible by 2.",
  },
  {
    "is 78 even or odd": "78 is even.",
  },
  {
    "how do you spell 78": "78 is spelled 'seventy-eight'.",
  },
  {
    "what is 79 in roman numerals": "79 in Roman numerals is LXXIX.",
  },
  {
    "what is 79 in binary": "79 in binary is 1001111.",
  },
  {
    "what is 79 in hexadecimal": "79 in hexadecimal is 4F.",
  },
  {
    "is 79 prime": "Yes, 79 is a prime number.",
  },
  {
    "is 79 even or odd": "79 is odd.",
  },
  {
    "how do you spell 79": "79 is spelled 'seventy-nine'.",
  },
  {
    "what is 80 in roman numerals": "80 in Roman numerals is LXXX.",
  },
  {
    "what is 80 in binary": "80 in binary is 1010000.",
  },
  {
    "what is 80 in hexadecimal": "80 in hexadecimal is 50.",
  },
  {
    "is 80 prime": "No, 80 is not prime. It is divisible by 2.",
  },
  {
    "is 80 even or odd": "80 is even.",
  },
  {
    "how do you spell 80": "80 is spelled 'eighty'.",
  },
  {
    "what is 81 in roman numerals": "81 in Roman numerals is LXXXI.",
  },
  {
    "what is 81 in binary": "81 in binary is 1010001.",
  },
  {
    "what is 81 in hexadecimal": "81 in hexadecimal is 51.",
  },
  {
    "is 81 prime": "No, 81 is not prime. It is divisible by 3.",
  },
  {
    "is 81 even or odd": "81 is odd.",
  },
  {
    "how do you spell 81": "81 is spelled 'eighty-one'.",
  },
  {
    "what is 82 in roman numerals": "82 in Roman numerals is LXXXII.",
  },
  {
    "what is 82 in binary": "82 in binary is 1010010.",
  },
  {
    "what is 82 in hexadecimal": "82 in hexadecimal is 52.",
  },
  {
    "is 82 prime": "No, 82 is not prime. It is divisible by 2.",
  },
  {
    "is 82 even or odd": "82 is even.",
  },
  {
    "how do you spell 82": "82 is spelled 'eighty-two'.",
  },
  {
    "what is 83 in roman numerals": "83 in Roman numerals is LXXXIII.",
  },
  {
    "what is 83 in binary": "83 in binary is 1010011.",
  },
  {
    "what is 83 in hexadecimal": "83 in hexadecimal is 53.",
  },
  {
    "is 83 prime": "Yes, 83 is a prime number.",
  },
  {
    "is 83 even or odd": "83 is odd.",
  },
  {
    "how do you spell 83": "83 is spelled 'eighty-three'.",
  },
  {
    "what is 84 in roman numerals": "84 in Roman numerals is LXXXIV.",
  },
  {
    "what is 84 in binary": "84 in binary is 1010100.",
  },
  {
    "what is 84 in hexadecimal": "84 in hexadecimal is 54.",
  },
  {
    "is 84 prime": "No, 84 is not prime. It is divisible by 2.",
  },
  {
    "is 84 even or odd": "84 is even.",
  },
  {
    "how do you spell 84": "84 is spelled 'eighty-four'.",
  },
  {
    "what is 85 in roman numerals": "85 in Roman numerals is LXXXV.",
  },
  {
    "what is 85 in binary": "85 in binary is 1010101.",
  },
  {
    "what is 85 in hexadecimal": "85 in hexadecimal is 55.",
  },
  {
    "is 85 prime": "No, 85 is not prime. It is divisible by 5.",
  },
  {
    "is 85 even or odd": "85 is odd.",
  },
  {
    "how do you spell 85": "85 is spelled 'eighty-five'.",
  },
  {
    "what is 86 in roman numerals": "86 in Roman numerals is LXXXVI.",
  },
  {
    "what is 86 in binary": "86 in binary is 1010110.",
  },
  {
    "what is 86 in hexadecimal": "86 in hexadecimal is 56.",
  },
  {
    "is 86 prime": "No, 86 is not prime. It is divisible by 2.",
  },
  {
    "is 86 even or odd": "86 is even.",
  },
  {
    "how do you spell 86": "86 is spelled 'eighty-six'.",
  },
  {
    "what is 87 in roman numerals": "87 in Roman numerals is LXXXVII.",
  },
  {
    "what is 87 in binary": "87 in binary is 1010111.",
  },
  {
    "what is 87 in hexadecimal": "87 in hexadecimal is 57.",
  },
  {
    "is 87 prime": "No, 87 is not prime. It is divisible by 3.",
  },
  {
    "is 87 even or odd": "87 is odd.",
  },
  {
    "how do you spell 87": "87 is spelled 'eighty-seven'.",
  },
  {
    "what is 88 in roman numerals": "88 in Roman numerals is LXXXVIII.",
  },
  {
    "what is 88 in binary": "88 in binary is 1011000.",
  },
  {
    "what is 88 in hexadecimal": "88 in hexadecimal is 58.",
  },
  {
    "is 88 prime": "No, 88 is not prime. It is divisible by 2.",
  },
  {
    "is 88 even or odd": "88 is even.",
  },
  {
    "how do you spell 88": "88 is spelled 'eighty-eight'.",
  },
  {
    "what is 89 in roman numerals": "89 in Roman numerals is LXXXIX.",
  },
  {
    "what is 89 in binary": "89 in binary is 1011001.",
  },
  {
    "what is 89 in hexadecimal": "89 in hexadecimal is 59.",
  },
  {
    "is 89 prime": "Yes, 89 is a prime number.",
  },
  {
    "is 89 even or odd": "89 is odd.",
  },
  {
    "how do you spell 89": "89 is spelled 'eighty-nine'.",
  },
  {
    "what is 90 in roman numerals": "90 in Roman numerals is XC.",
  },
  {
    "what is 90 in binary": "90 in binary is 1011010.",
  },
  {
    "what is 90 in hexadecimal": "90 in hexadecimal is 5A.",
  },
  {
    "is 90 prime": "No, 90 is not prime. It is divisible by 2.",
  },
  {
    "is 90 even or odd": "90 is even.",
  },
  {
    "how do you spell 90": "90 is spelled 'ninety'.",
  },
  {
    "what is 91 in roman numerals": "91 in Roman numerals is XCI.",
  },
  {
    "what is 91 in binary": "91 in binary is 1011011.",
  },
  {
    "what is 91 in hexadecimal": "91 in hexadecimal is 5B.",
  },
  {
    "is 91 prime": "No, 91 is not prime. It is divisible by 7.",
  },
  {
    "is 91 even or odd": "91 is odd.",
  },
  {
    "how do you spell 91": "91 is spelled 'ninety-one'.",
  },
  {
    "what is 92 in roman numerals": "92 in Roman numerals is XCII.",
  },
  {
    "what is 92 in binary": "92 in binary is 1011100.",
  },
  {
    "what is 92 in hexadecimal": "92 in hexadecimal is 5C.",
  },
  {
    "is 92 prime": "No, 92 is not prime. It is divisible by 2.",
  },
  {
    "is 92 even or odd": "92 is even.",
  },
  {
    "how do you spell 92": "92 is spelled 'ninety-two'.",
  },
  {
    "what is 93 in roman numerals": "93 in Roman numerals is XCIII.",
  },
  {
    "what is 93 in binary": "93 in binary is 1011101.",
  },
  {
    "what is 93 in hexadecimal": "93 in hexadecimal is 5D.",
  },
  {
    "is 93 prime": "No, 93 is not prime. It is divisible by 3.",
  },
  {
    "is 93 even or odd": "93 is odd.",
  },
  {
    "how do you spell 93": "93 is spelled 'ninety-three'.",
  },
  {
    "what is 94 in roman numerals": "94 in Roman numerals is XCIV.",
  },
  {
    "what is 94 in binary": "94 in binary is 1011110.",
  },
  {
    "what is 94 in hexadecimal": "94 in hexadecimal is 5E.",
  },
  {
    "is 94 prime": "No, 94 is not prime. It is divisible by 2.",
  },
  {
    "is 94 even or odd": "94 is even.",
  },
  {
    "how do you spell 94": "94 is spelled 'ninety-four'.",
  },
  {
    "what is 95 in roman numerals": "95 in Roman numerals is XCV.",
  },
  {
    "what is 95 in binary": "95 in binary is 1011111.",
  },
  {
    "what is 95 in hexadecimal": "95 in hexadecimal is 5F.",
  },
  {
    "is 95 prime": "No, 95 is not prime. It is divisible by 5.",
  },
  {
    "is 95 even or odd": "95 is odd.",
  },
  {
    "how do you spell 95": "95 is spelled 'ninety-five'.",
  },
  {
    "what is 96 in roman numerals": "96 in Roman numerals is XCVI.",
  },
  {
    "what is 96 in binary": "96 in binary is 1100000.",
  },
  {
    "what is 96 in hexadecimal": "96 in hexadecimal is 60.",
  },
  {
    "is 96 prime": "No, 96 is not prime. It is divisible by 2.",
  },
  {
    "is 96 even or odd": "96 is even.",
  },
  {
    "how do you spell 96": "96 is spelled 'ninety-six'.",
  },
  {
    "what is 97 in roman numerals": "97 in Roman numerals is XCVII.",
  },
  {
    "what is 97 in binary": "97 in binary is 1100001.",
  },
  {
    "what is 97 in hexadecimal": "97 in hexadecimal is 61.",
  },
  {
    "is 97 prime": "Yes, 97 is a prime number.",
  },
  {
    "is 97 even or odd": "97 is odd.",
  },
  {
    "how do you spell 97": "97 is spelled 'ninety-seven'.",
  },
  {
    "what is 98 in roman numerals": "98 in Roman numerals is XCVIII.",
  },
  {
    "what is 98 in binary": "98 in binary is 1100010.",
  },
  {
    "what is 98 in hexadecimal": "98 in hexadecimal is 62.",
  },
  {
    "is 98 prime": "No, 98 is not prime. It is divisible by 2.",
  },
  {
    "is 98 even or odd": "98 is even.",
  },
  {
    "how do you spell 98": "98 is spelled 'ninety-eight'.",
  },
  {
    "what is 99 in roman numerals": "99 in Roman numerals is XCIX.",
  },
  {
    "what is 99 in binary": "99 in binary is 1100011.",
  },
  {
    "what is 99 in hexadecimal": "99 in hexadecimal is 63.",
  },
  {
    "is 99 prime": "No, 99 is not prime. It is divisible by 3.",
  },
  {
    "is 99 even or odd": "99 is odd.",
  },
  {
    "how do you spell 99": "99 is spelled 'ninety-nine'.",
  },
  {
    "what is 100 in roman numerals": "100 in Roman numerals is C.",
  },
  {
    "what is 100 in binary": "100 in binary is 1100100.",
  },
  {
    "what is 100 in hexadecimal": "100 in hexadecimal is 64.",
  },
  {
    "is 100 prime": "No, 100 is not prime. It is divisible by 2.",
  },
  {
    "is 100 even or odd": "100 is even.",
  },
  {
    "how do you spell 100": "100 is spelled 'one hundred'.",
  },
  {
    "what is binary 1 in decimal": "Binary 1 equals 1 in decimal.",
  },
  {
    "what is binary 10 in decimal": "Binary 10 equals 2 in decimal.",
  },
  {
    "what is binary 11 in decimal": "Binary 11 equals 3 in decimal.",
  },
  {
    "what is binary 100 in decimal": "Binary 100 equals 4 in decimal.",
  },
  {
    "what is binary 101 in decimal": "Binary 101 equals 5 in decimal.",
  },
  {
    "what is binary 110 in decimal": "Binary 110 equals 6 in decimal.",
  },
  {
    "what is binary 111 in decimal": "Binary 111 equals 7 in decimal.",
  },
  {
    "what is binary 1000 in decimal": "Binary 1000 equals 8 in decimal.",
  },
  {
    "what is binary 1001 in decimal": "Binary 1001 equals 9 in decimal.",
  },
  {
    "what is binary 1010 in decimal": "Binary 1010 equals 10 in decimal.",
  },
  {
    "what is binary 1011 in decimal": "Binary 1011 equals 11 in decimal.",
  },
  {
    "what is binary 1100 in decimal": "Binary 1100 equals 12 in decimal.",
  },
  {
    "what is binary 1101 in decimal": "Binary 1101 equals 13 in decimal.",
  },
  {
    "what is binary 1110 in decimal": "Binary 1110 equals 14 in decimal.",
  },
  {
    "what is binary 1111 in decimal": "Binary 1111 equals 15 in decimal.",
  },
  {
    "what is binary 10000 in decimal": "Binary 10000 equals 16 in decimal.",
  },
  {
    "what is binary 10001 in decimal": "Binary 10001 equals 17 in decimal.",
  },
  {
    "what is binary 10010 in decimal": "Binary 10010 equals 18 in decimal.",
  },
  {
    "what is binary 10011 in decimal": "Binary 10011 equals 19 in decimal.",
  },
  {
    "what is binary 10100 in decimal": "Binary 10100 equals 20 in decimal.",
  },
  {
    "what is binary 10101 in decimal": "Binary 10101 equals 21 in decimal.",
  },
  {
    "what is binary 10110 in decimal": "Binary 10110 equals 22 in decimal.",
  },
  {
    "what is binary 10111 in decimal": "Binary 10111 equals 23 in decimal.",
  },
  {
    "what is binary 11000 in decimal": "Binary 11000 equals 24 in decimal.",
  },
  {
    "what is binary 11001 in decimal": "Binary 11001 equals 25 in decimal.",
  },
  {
    "what is binary 11010 in decimal": "Binary 11010 equals 26 in decimal.",
  },
  {
    "what is binary 11011 in decimal": "Binary 11011 equals 27 in decimal.",
  },
  {
    "what is binary 11100 in decimal": "Binary 11100 equals 28 in decimal.",
  },
  {
    "what is binary 11101 in decimal": "Binary 11101 equals 29 in decimal.",
  },
  {
    "what is binary 11110 in decimal": "Binary 11110 equals 30 in decimal.",
  },
  {
    "what is binary 11111 in decimal": "Binary 11111 equals 31 in decimal.",
  },
  {
    "what is binary 100000 in decimal": "Binary 100000 equals 32 in decimal.",
  },
  {
    "what is binary 100001 in decimal": "Binary 100001 equals 33 in decimal.",
  },
  {
    "what is binary 100010 in decimal": "Binary 100010 equals 34 in decimal.",
  },
  {
    "what is binary 100011 in decimal": "Binary 100011 equals 35 in decimal.",
  },
  {
    "what is binary 100100 in decimal": "Binary 100100 equals 36 in decimal.",
  },
  {
    "what is binary 100101 in decimal": "Binary 100101 equals 37 in decimal.",
  },
  {
    "what is binary 100110 in decimal": "Binary 100110 equals 38 in decimal.",
  },
  {
    "what is binary 100111 in decimal": "Binary 100111 equals 39 in decimal.",
  },
  {
    "what is binary 101000 in decimal": "Binary 101000 equals 40 in decimal.",
  },
  {
    "what is binary 101001 in decimal": "Binary 101001 equals 41 in decimal.",
  },
  {
    "what is binary 101010 in decimal": "Binary 101010 equals 42 in decimal.",
  },
  {
    "what is binary 101011 in decimal": "Binary 101011 equals 43 in decimal.",
  },
  {
    "what is binary 101100 in decimal": "Binary 101100 equals 44 in decimal.",
  },
  {
    "what is binary 101101 in decimal": "Binary 101101 equals 45 in decimal.",
  },
  {
    "what is binary 101110 in decimal": "Binary 101110 equals 46 in decimal.",
  },
  {
    "what is binary 101111 in decimal": "Binary 101111 equals 47 in decimal.",
  },
  {
    "what is binary 110000 in decimal": "Binary 110000 equals 48 in decimal.",
  },
  {
    "what is binary 110001 in decimal": "Binary 110001 equals 49 in decimal.",
  },
  {
    "what is binary 110010 in decimal": "Binary 110010 equals 50 in decimal.",
  },
  {
    "what is binary 110011 in decimal": "Binary 110011 equals 51 in decimal.",
  },
  {
    "what is binary 110100 in decimal": "Binary 110100 equals 52 in decimal.",
  },
  {
    "what is binary 110101 in decimal": "Binary 110101 equals 53 in decimal.",
  },
  {
    "what is binary 110110 in decimal": "Binary 110110 equals 54 in decimal.",
  },
  {
    "what is binary 110111 in decimal": "Binary 110111 equals 55 in decimal.",
  },
  {
    "what is binary 111000 in decimal": "Binary 111000 equals 56 in decimal.",
  },
  {
    "what is binary 111001 in decimal": "Binary 111001 equals 57 in decimal.",
  },
  {
    "what is binary 111010 in decimal": "Binary 111010 equals 58 in decimal.",
  },
  {
    "what is binary 111011 in decimal": "Binary 111011 equals 59 in decimal.",
  },
  {
    "what is binary 111100 in decimal": "Binary 111100 equals 60 in decimal.",
  },
  {
    "what is binary 111101 in decimal": "Binary 111101 equals 61 in decimal.",
  },
  {
    "what is binary 111110 in decimal": "Binary 111110 equals 62 in decimal.",
  },
  {
    "what is binary 111111 in decimal": "Binary 111111 equals 63 in decimal.",
  },
  {
    "what is binary 1000000 in decimal": "Binary 1000000 equals 64 in decimal.",
  },
  {
    "what is 0 factorial": "0 factorial is 1.",
  },
  {
    "what is 1 factorial": "1 factorial is 1.",
  },
  {
    "what is 2 factorial": "2 factorial is 2.",
  },
  {
    "what is 3 factorial": "3 factorial is 6.",
  },
  {
    "what is 4 factorial": "4 factorial is 24.",
  },
  {
    "what is 5 factorial": "5 factorial is 120.",
  },
  {
    "what is 6 factorial": "6 factorial is 720.",
  },
  {
    "what is 7 factorial": "7 factorial is 5040.",
  },
  {
    "what is 8 factorial": "8 factorial is 40320.",
  },
  {
    "what is 9 factorial": "9 factorial is 362880.",
  },
  {
    "what is 10 factorial": "10 factorial is 3628800.",
  },
  {
    "what is 11 factorial": "11 factorial is 39916800.",
  },
  {
    "what is 12 factorial": "12 factorial is 479001600.",
  },
  {
    "what is 13 factorial": "13 factorial is 6227020800.",
  },
  {
    "what is 14 factorial": "14 factorial is 87178291200.",
  },
  {
    "what is 15 factorial": "15 factorial is 1307674368000.",
  },
  {
    "what is the 1th fibonacci number": "The 1th Fibonacci number is 0 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 2th fibonacci number": "The 2th Fibonacci number is 1 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 3th fibonacci number": "The 3th Fibonacci number is 1 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 4th fibonacci number": "The 4th Fibonacci number is 2 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 5th fibonacci number": "The 5th Fibonacci number is 3 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 6th fibonacci number": "The 6th Fibonacci number is 5 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 7th fibonacci number": "The 7th Fibonacci number is 8 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 8th fibonacci number": "The 8th Fibonacci number is 13 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 9th fibonacci number": "The 9th Fibonacci number is 21 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 10th fibonacci number": "The 10th Fibonacci number is 34 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 11th fibonacci number": "The 11th Fibonacci number is 55 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 12th fibonacci number": "The 12th Fibonacci number is 89 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 13th fibonacci number": "The 13th Fibonacci number is 144 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 14th fibonacci number": "The 14th Fibonacci number is 233 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 15th fibonacci number": "The 15th Fibonacci number is 377 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 16th fibonacci number": "The 16th Fibonacci number is 610 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 17th fibonacci number": "The 17th Fibonacci number is 987 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 18th fibonacci number": "The 18th Fibonacci number is 1597 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 19th fibonacci number": "The 19th Fibonacci number is 2584 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 20th fibonacci number": "The 20th Fibonacci number is 4181 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 21th fibonacci number": "The 21th Fibonacci number is 6765 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 22th fibonacci number": "The 22th Fibonacci number is 10946 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 23th fibonacci number": "The 23th Fibonacci number is 17711 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 24th fibonacci number": "The 24th Fibonacci number is 28657 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 25th fibonacci number": "The 25th Fibonacci number is 46368 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 26th fibonacci number": "The 26th Fibonacci number is 75025 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 27th fibonacci number": "The 27th Fibonacci number is 121393 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 28th fibonacci number": "The 28th Fibonacci number is 196418 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 29th fibonacci number": "The 29th Fibonacci number is 317811 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is the 30th fibonacci number": "The 30th Fibonacci number is 514229 (counting from 0, 1, 1, 2, ...).",
  },
  {
    "what is 2 to the power of 1": "2 to the power of 1 is 2.",
  },
  {
    "what is 2 to the power of 2": "2 to the power of 2 is 4.",
  },
  {
    "what is 2 to the power of 3": "2 to the power of 3 is 8.",
  },
  {
    "what is 2 to the power of 4": "2 to the power of 4 is 16.",
  },
  {
    "what is 2 to the power of 5": "2 to the power of 5 is 32.",
  },
  {
    "what is 2 to the power of 6": "2 to the power of 6 is 64.",
  },
  {
    "what is 2 to the power of 7": "2 to the power of 7 is 128.",
  },
  {
    "what is 2 to the power of 8": "2 to the power of 8 is 256.",
  },
  {
    "what is 2 to the power of 9": "2 to the power of 9 is 512.",
  },
  {
    "what is 2 to the power of 10": "2 to the power of 10 is 1024.",
  },
  {
    "what is 2 to the power of 11": "2 to the power of 11 is 2048.",
  },
  {
    "what is 2 to the power of 12": "2 to the power of 12 is 4096.",
  },
  {
    "what is 2 to the power of 13": "2 to the power of 13 is 8192.",
  },
  {
    "what is 2 to the power of 14": "2 to the power of 14 is 16384.",
  },
  {
    "what is 2 to the power of 15": "2 to the power of 15 is 32768.",
  },
  {
    "what is 2 to the power of 16": "2 to the power of 16 is 65536.",
  },
  {
    "what is 2 to the power of 17": "2 to the power of 17 is 131072.",
  },
  {
    "what is 2 to the power of 18": "2 to the power of 18 is 262144.",
  },
  {
    "what is 2 to the power of 19": "2 to the power of 19 is 524288.",
  },
  {
    "what is 2 to the power of 20": "2 to the power of 20 is 1048576.",
  },
  {
    "what is 2 to the power of 21": "2 to the power of 21 is 2097152.",
  },
  {
    "what is 2 to the power of 22": "2 to the power of 22 is 4194304.",
  },
  {
    "what is 2 to the power of 23": "2 to the power of 23 is 8388608.",
  },
  {
    "what is 2 to the power of 24": "2 to the power of 24 is 16777216.",
  },
  {
    "what is 2 to the power of 25": "2 to the power of 25 is 33554432.",
  },
  {
    "what is 2 to the power of 26": "2 to the power of 26 is 67108864.",
  },
  {
    "what is 2 to the power of 27": "2 to the power of 27 is 134217728.",
  },
  {
    "what is 2 to the power of 28": "2 to the power of 28 is 268435456.",
  },
  {
    "what is 2 to the power of 29": "2 to the power of 29 is 536870912.",
  },
  {
    "what is 2 to the power of 30": "2 to the power of 30 is 1073741824.",
  },
  {
    "what are the first 10 multiples of 2": "The first 10 multiples of 2 are: 2, 4, 6, 8, 10, 12, 14, 16, 18, 20.",
  },
  {
    "what are the first 10 multiples of 3": "The first 10 multiples of 3 are: 3, 6, 9, 12, 15, 18, 21, 24, 27, 30.",
  },
  {
    "what are the first 10 multiples of 4": "The first 10 multiples of 4 are: 4, 8, 12, 16, 20, 24, 28, 32, 36, 40.",
  },
  {
    "what are the first 10 multiples of 5": "The first 10 multiples of 5 are: 5, 10, 15, 20, 25, 30, 35, 40, 45, 50.",
  },
  {
    "what are the first 10 multiples of 6": "The first 10 multiples of 6 are: 6, 12, 18, 24, 30, 36, 42, 48, 54, 60.",
  },
  {
    "what are the first 10 multiples of 7": "The first 10 multiples of 7 are: 7, 14, 21, 28, 35, 42, 49, 56, 63, 70.",
  },
  {
    "what are the first 10 multiples of 8": "The first 10 multiples of 8 are: 8, 16, 24, 32, 40, 48, 56, 64, 72, 80.",
  },
  {
    "what are the first 10 multiples of 9": "The first 10 multiples of 9 are: 9, 18, 27, 36, 45, 54, 63, 72, 81, 90.",
  },
  {
    "what are the first 10 multiples of 10": "The first 10 multiples of 10 are: 10, 20, 30, 40, 50, 60, 70, 80, 90, 100.",
  },
  {
    "what are the first 10 multiples of 11": "The first 10 multiples of 11 are: 11, 22, 33, 44, 55, 66, 77, 88, 99, 110.",
  },
  {
    "what are the first 10 multiples of 12": "The first 10 multiples of 12 are: 12, 24, 36, 48, 60, 72, 84, 96, 108, 120.",
  },
  {
    "what are the first 10 multiples of 13": "The first 10 multiples of 13 are: 13, 26, 39, 52, 65, 78, 91, 104, 117, 130.",
  },
  {
    "what are the first 10 multiples of 14": "The first 10 multiples of 14 are: 14, 28, 42, 56, 70, 84, 98, 112, 126, 140.",
  },
  {
    "what are the first 10 multiples of 15": "The first 10 multiples of 15 are: 15, 30, 45, 60, 75, 90, 105, 120, 135, 150.",
  },
  {
    "what are the first 10 multiples of 16": "The first 10 multiples of 16 are: 16, 32, 48, 64, 80, 96, 112, 128, 144, 160.",
  },
  {
    "what are the first 10 multiples of 17": "The first 10 multiples of 17 are: 17, 34, 51, 68, 85, 102, 119, 136, 153, 170.",
  },
  {
    "what are the first 10 multiples of 18": "The first 10 multiples of 18 are: 18, 36, 54, 72, 90, 108, 126, 144, 162, 180.",
  },
  {
    "what are the first 10 multiples of 19": "The first 10 multiples of 19 are: 19, 38, 57, 76, 95, 114, 133, 152, 171, 190.",
  },
  {
    "what are the first 10 multiples of 20": "The first 10 multiples of 20 are: 20, 40, 60, 80, 100, 120, 140, 160, 180, 200.",
  },
  {
    "convert 1 km to miles": "1 km is about 0.62 miles.",
  },
  {
    "convert 1 miles to km": "1 miles is about 1.61 km.",
  },
  {
    "convert 1 kg to pounds": "1 kg is about 2.2 pounds.",
  },
  {
    "convert 2 km to miles": "2 km is about 1.24 miles.",
  },
  {
    "convert 2 miles to km": "2 miles is about 3.22 km.",
  },
  {
    "convert 2 kg to pounds": "2 kg is about 4.41 pounds.",
  },
  {
    "convert 3 km to miles": "3 km is about 1.86 miles.",
  },
  {
    "convert 3 miles to km": "3 miles is about 4.83 km.",
  },
  {
    "convert 3 kg to pounds": "3 kg is about 6.61 pounds.",
  },
  {
    "convert 4 km to miles": "4 km is about 2.49 miles.",
  },
  {
    "convert 4 miles to km": "4 miles is about 6.44 km.",
  },
  {
    "convert 4 kg to pounds": "4 kg is about 8.82 pounds.",
  },
  {
    "convert 5 km to miles": "5 km is about 3.11 miles.",
  },
  {
    "convert 5 miles to km": "5 miles is about 8.05 km.",
  },
  {
    "convert 5 kg to pounds": "5 kg is about 11.02 pounds.",
  },
  {
    "convert 6 km to miles": "6 km is about 3.73 miles.",
  },
  {
    "convert 6 miles to km": "6 miles is about 9.66 km.",
  },
  {
    "convert 6 kg to pounds": "6 kg is about 13.23 pounds.",
  },
  {
    "convert 7 km to miles": "7 km is about 4.35 miles.",
  },
  {
    "convert 7 miles to km": "7 miles is about 11.27 km.",
  },
  {
    "convert 7 kg to pounds": "7 kg is about 15.43 pounds.",
  },
  {
    "convert 8 km to miles": "8 km is about 4.97 miles.",
  },
  {
    "convert 8 miles to km": "8 miles is about 12.87 km.",
  },
  {
    "convert 8 kg to pounds": "8 kg is about 17.64 pounds.",
  },
  {
    "convert 9 km to miles": "9 km is about 5.59 miles.",
  },
  {
    "convert 9 miles to km": "9 miles is about 14.48 km.",
  },
  {
    "convert 9 kg to pounds": "9 kg is about 19.84 pounds.",
  },
  {
    "convert 10 km to miles": "10 km is about 6.21 miles.",
  },
  {
    "convert 10 miles to km": "10 miles is about 16.09 km.",
  },
  {
    "convert 10 kg to pounds": "10 kg is about 22.05 pounds.",
  },
  {
    "convert 11 km to miles": "11 km is about 6.84 miles.",
  },
  {
    "convert 11 miles to km": "11 miles is about 17.7 km.",
  },
  {
    "convert 11 kg to pounds": "11 kg is about 24.25 pounds.",
  },
  {
    "convert 12 km to miles": "12 km is about 7.46 miles.",
  },
  {
    "convert 12 miles to km": "12 miles is about 19.31 km.",
  },
  {
    "convert 12 kg to pounds": "12 kg is about 26.46 pounds.",
  },
  {
    "convert 13 km to miles": "13 km is about 8.08 miles.",
  },
  {
    "convert 13 miles to km": "13 miles is about 20.92 km.",
  },
  {
    "convert 13 kg to pounds": "13 kg is about 28.66 pounds.",
  },
  {
    "convert 14 km to miles": "14 km is about 8.7 miles.",
  },
  {
    "convert 14 miles to km": "14 miles is about 22.53 km.",
  },
  {
    "convert 14 kg to pounds": "14 kg is about 30.86 pounds.",
  },
  {
    "convert 15 km to miles": "15 km is about 9.32 miles.",
  },
  {
    "convert 15 miles to km": "15 miles is about 24.14 km.",
  },
  {
    "convert 15 kg to pounds": "15 kg is about 33.07 pounds.",
  },
  {
    "convert 16 km to miles": "16 km is about 9.94 miles.",
  },
  {
    "convert 16 miles to km": "16 miles is about 25.75 km.",
  },
  {
    "convert 16 kg to pounds": "16 kg is about 35.27 pounds.",
  },
  {
    "convert 17 km to miles": "17 km is about 10.56 miles.",
  },
  {
    "convert 17 miles to km": "17 miles is about 27.36 km.",
  },
  {
    "convert 17 kg to pounds": "17 kg is about 37.48 pounds.",
  },
  {
    "convert 18 km to miles": "18 km is about 11.18 miles.",
  },
  {
    "convert 18 miles to km": "18 miles is about 28.97 km.",
  },
  {
    "convert 18 kg to pounds": "18 kg is about 39.68 pounds.",
  },
  {
    "convert 19 km to miles": "19 km is about 11.81 miles.",
  },
  {
    "convert 19 miles to km": "19 miles is about 30.58 km.",
  },
  {
    "convert 19 kg to pounds": "19 kg is about 41.89 pounds.",
  },
  {
    "convert 20 km to miles": "20 km is about 12.43 miles.",
  },
  {
    "convert 20 miles to km": "20 miles is about 32.19 km.",
  },
  {
    "convert 20 kg to pounds": "20 kg is about 44.09 pounds.",
  },
  {
    "convert 21 km to miles": "21 km is about 13.05 miles.",
  },
  {
    "convert 21 miles to km": "21 miles is about 33.8 km.",
  },
  {
    "convert 21 kg to pounds": "21 kg is about 46.3 pounds.",
  },
  {
    "convert 22 km to miles": "22 km is about 13.67 miles.",
  },
  {
    "convert 22 miles to km": "22 miles is about 35.41 km.",
  },
  {
    "convert 22 kg to pounds": "22 kg is about 48.5 pounds.",
  },
  {
    "convert 23 km to miles": "23 km is about 14.29 miles.",
  },
  {
    "convert 23 miles to km": "23 miles is about 37.01 km.",
  },
  {
    "convert 23 kg to pounds": "23 kg is about 50.71 pounds.",
  },
  {
    "convert 24 km to miles": "24 km is about 14.91 miles.",
  },
  {
    "convert 24 miles to km": "24 miles is about 38.62 km.",
  },
  {
    "convert 24 kg to pounds": "24 kg is about 52.91 pounds.",
  },
  {
    "convert 25 km to miles": "25 km is about 15.53 miles.",
  },
  {
    "convert 25 miles to km": "25 miles is about 40.23 km.",
  },
  {
    "convert 25 kg to pounds": "25 kg is about 55.12 pounds.",
  },
  {
    "convert 26 km to miles": "26 km is about 16.16 miles.",
  },
  {
    "convert 26 miles to km": "26 miles is about 41.84 km.",
  },
  {
    "convert 26 kg to pounds": "26 kg is about 57.32 pounds.",
  },
  {
    "convert 27 km to miles": "27 km is about 16.78 miles.",
  },
  {
    "convert 27 miles to km": "27 miles is about 43.45 km.",
  },
  {
    "convert 27 kg to pounds": "27 kg is about 59.52 pounds.",
  },
  {
    "convert 28 km to miles": "28 km is about 17.4 miles.",
  },
  {
    "convert 28 miles to km": "28 miles is about 45.06 km.",
  },
  {
    "convert 28 kg to pounds": "28 kg is about 61.73 pounds.",
  },
  {
    "convert 29 km to miles": "29 km is about 18.02 miles.",
  },
  {
    "convert 29 miles to km": "29 miles is about 46.67 km.",
  },
  {
    "convert 29 kg to pounds": "29 kg is about 63.93 pounds.",
  },
  {
    "convert 30 km to miles": "30 km is about 18.64 miles.",
  },
  {
    "convert 30 miles to km": "30 miles is about 48.28 km.",
  },
  {
    "convert 30 kg to pounds": "30 kg is about 66.14 pounds.",
  },
  {
    "convert 31 km to miles": "31 km is about 19.26 miles.",
  },
  {
    "convert 31 miles to km": "31 miles is about 49.89 km.",
  },
  {
    "convert 31 kg to pounds": "31 kg is about 68.34 pounds.",
  },
  {
    "convert 32 km to miles": "32 km is about 19.88 miles.",
  },
  {
    "convert 32 miles to km": "32 miles is about 51.5 km.",
  },
  {
    "convert 32 kg to pounds": "32 kg is about 70.55 pounds.",
  },
  {
    "convert 33 km to miles": "33 km is about 20.51 miles.",
  },
  {
    "convert 33 miles to km": "33 miles is about 53.11 km.",
  },
  {
    "convert 33 kg to pounds": "33 kg is about 72.75 pounds.",
  },
  {
    "convert 34 km to miles": "34 km is about 21.13 miles.",
  },
  {
    "convert 34 miles to km": "34 miles is about 54.72 km.",
  },
  {
    "convert 34 kg to pounds": "34 kg is about 74.96 pounds.",
  },
  {
    "convert 35 km to miles": "35 km is about 21.75 miles.",
  },
  {
    "convert 35 miles to km": "35 miles is about 56.33 km.",
  },
  {
    "convert 35 kg to pounds": "35 kg is about 77.16 pounds.",
  },
  {
    "convert 36 km to miles": "36 km is about 22.37 miles.",
  },
  {
    "convert 36 miles to km": "36 miles is about 57.94 km.",
  },
  {
    "convert 36 kg to pounds": "36 kg is about 79.37 pounds.",
  },
  {
    "convert 37 km to miles": "37 km is about 22.99 miles.",
  },
  {
    "convert 37 miles to km": "37 miles is about 59.55 km.",
  },
  {
    "convert 37 kg to pounds": "37 kg is about 81.57 pounds.",
  },
  {
    "convert 38 km to miles": "38 km is about 23.61 miles.",
  },
  {
    "convert 38 miles to km": "38 miles is about 61.16 km.",
  },
  {
    "convert 38 kg to pounds": "38 kg is about 83.78 pounds.",
  },
  {
    "convert 39 km to miles": "39 km is about 24.23 miles.",
  },
  {
    "convert 39 miles to km": "39 miles is about 62.76 km.",
  },
  {
    "convert 39 kg to pounds": "39 kg is about 85.98 pounds.",
  },
  {
    "convert 40 km to miles": "40 km is about 24.85 miles.",
  },
  {
    "convert 40 miles to km": "40 miles is about 64.37 km.",
  },
  {
    "convert 40 kg to pounds": "40 kg is about 88.18 pounds.",
  },
  {
    "convert 41 km to miles": "41 km is about 25.48 miles.",
  },
  {
    "convert 41 miles to km": "41 miles is about 65.98 km.",
  },
  {
    "convert 41 kg to pounds": "41 kg is about 90.39 pounds.",
  },
  {
    "convert 42 km to miles": "42 km is about 26.1 miles.",
  },
  {
    "convert 42 miles to km": "42 miles is about 67.59 km.",
  },
  {
    "convert 42 kg to pounds": "42 kg is about 92.59 pounds.",
  },
  {
    "convert 43 km to miles": "43 km is about 26.72 miles.",
  },
  {
    "convert 43 miles to km": "43 miles is about 69.2 km.",
  },
  {
    "convert 43 kg to pounds": "43 kg is about 94.8 pounds.",
  },
  {
    "convert 44 km to miles": "44 km is about 27.34 miles.",
  },
  {
    "convert 44 miles to km": "44 miles is about 70.81 km.",
  },
  {
    "convert 44 kg to pounds": "44 kg is about 97 pounds.",
  },
  {
    "convert 45 km to miles": "45 km is about 27.96 miles.",
  },
  {
    "convert 45 miles to km": "45 miles is about 72.42 km.",
  },
  {
    "convert 45 kg to pounds": "45 kg is about 99.21 pounds.",
  },
  {
    "convert 46 km to miles": "46 km is about 28.58 miles.",
  },
  {
    "convert 46 miles to km": "46 miles is about 74.03 km.",
  },
  {
    "convert 46 kg to pounds": "46 kg is about 101.41 pounds.",
  },
  {
    "convert 47 km to miles": "47 km is about 29.2 miles.",
  },
  {
    "convert 47 miles to km": "47 miles is about 75.64 km.",
  },
  {
    "convert 47 kg to pounds": "47 kg is about 103.62 pounds.",
  },
  {
    "convert 48 km to miles": "48 km is about 29.83 miles.",
  },
  {
    "convert 48 miles to km": "48 miles is about 77.25 km.",
  },
  {
    "convert 48 kg to pounds": "48 kg is about 105.82 pounds.",
  },
  {
    "convert 49 km to miles": "49 km is about 30.45 miles.",
  },
  {
    "convert 49 miles to km": "49 miles is about 78.86 km.",
  },
  {
    "convert 49 kg to pounds": "49 kg is about 108.03 pounds.",
  },
  {
    "convert 50 km to miles": "50 km is about 31.07 miles.",
  },
  {
    "convert 50 miles to km": "50 miles is about 80.47 km.",
  },
  {
    "convert 50 kg to pounds": "50 kg is about 110.23 pounds.",
  },
  {
    "convert 0 celsius to fahrenheit": "0°C is 32°F.",
  },
  {
    "convert 1 celsius to fahrenheit": "1°C is 33.8°F.",
  },
  {
    "convert 2 celsius to fahrenheit": "2°C is 35.6°F.",
  },
  {
    "convert 3 celsius to fahrenheit": "3°C is 37.4°F.",
  },
  {
    "convert 4 celsius to fahrenheit": "4°C is 39.2°F.",
  },
  {
    "convert 5 celsius to fahrenheit": "5°C is 41°F.",
  },
  {
    "convert 6 celsius to fahrenheit": "6°C is 42.8°F.",
  },
  {
    "convert 7 celsius to fahrenheit": "7°C is 44.6°F.",
  },
  {
    "convert 8 celsius to fahrenheit": "8°C is 46.4°F.",
  },
  {
    "convert 9 celsius to fahrenheit": "9°C is 48.2°F.",
  },
  {
    "convert 10 celsius to fahrenheit": "10°C is 50°F.",
  },
  {
    "convert 11 celsius to fahrenheit": "11°C is 51.8°F.",
  },
  {
    "convert 12 celsius to fahrenheit": "12°C is 53.6°F.",
  },
  {
    "convert 13 celsius to fahrenheit": "13°C is 55.4°F.",
  },
  {
    "convert 14 celsius to fahrenheit": "14°C is 57.2°F.",
  },
  {
    "convert 15 celsius to fahrenheit": "15°C is 59°F.",
  },
  {
    "convert 16 celsius to fahrenheit": "16°C is 60.8°F.",
  },
  {
    "convert 17 celsius to fahrenheit": "17°C is 62.6°F.",
  },
  {
    "convert 18 celsius to fahrenheit": "18°C is 64.4°F.",
  },
  {
    "convert 19 celsius to fahrenheit": "19°C is 66.2°F.",
  },
  {
    "convert 20 celsius to fahrenheit": "20°C is 68°F.",
  },
  {
    "convert 21 celsius to fahrenheit": "21°C is 69.8°F.",
  },
  {
    "convert 22 celsius to fahrenheit": "22°C is 71.6°F.",
  },
  {
    "convert 23 celsius to fahrenheit": "23°C is 73.4°F.",
  },
  {
    "convert 24 celsius to fahrenheit": "24°C is 75.2°F.",
  },
  {
    "convert 25 celsius to fahrenheit": "25°C is 77°F.",
  },
  {
    "convert 26 celsius to fahrenheit": "26°C is 78.8°F.",
  },
  {
    "convert 27 celsius to fahrenheit": "27°C is 80.6°F.",
  },
  {
    "convert 28 celsius to fahrenheit": "28°C is 82.4°F.",
  },
  {
    "convert 29 celsius to fahrenheit": "29°C is 84.2°F.",
  },
  {
    "convert 30 celsius to fahrenheit": "30°C is 86°F.",
  },
  {
    "convert 31 celsius to fahrenheit": "31°C is 87.8°F.",
  },
  {
    "convert 32 celsius to fahrenheit": "32°C is 89.6°F.",
  },
  {
    "convert 33 celsius to fahrenheit": "33°C is 91.4°F.",
  },
  {
    "convert 34 celsius to fahrenheit": "34°C is 93.2°F.",
  },
  {
    "convert 35 celsius to fahrenheit": "35°C is 95°F.",
  },
  {
    "convert 36 celsius to fahrenheit": "36°C is 96.8°F.",
  },
  {
    "convert 37 celsius to fahrenheit": "37°C is 98.6°F.",
  },
  {
    "convert 38 celsius to fahrenheit": "38°C is 100.4°F.",
  },
  {
    "convert 39 celsius to fahrenheit": "39°C is 102.2°F.",
  },
  {
    "convert 40 celsius to fahrenheit": "40°C is 104°F.",
  },
  {
    "what is the capital of nigeria": "The capital of Nigeria is Abuja.",
  },
  {
    "capital of nigeria": "The capital of Nigeria is Abuja.",
  },
  {
    "what is the capital of ghana": "The capital of Ghana is Accra.",
  },
  {
    "capital of ghana": "The capital of Ghana is Accra.",
  },
  {
    "what is the capital of kenya": "The capital of Kenya is Nairobi.",
  },
  {
    "capital of kenya": "The capital of Kenya is Nairobi.",
  },
  {
    "what is the capital of egypt": "The capital of Egypt is Cairo.",
  },
  {
    "capital of egypt": "The capital of Egypt is Cairo.",
  },
  {
    "what is the capital of south africa": "The capital of South Africa is Pretoria (executive), with Cape Town and Bloemfontein also serving as capitals.",
  },
  {
    "capital of south africa": "The capital of South Africa is Pretoria (executive), with Cape Town and Bloemfontein also serving as capitals.",
  },
  {
    "what is the capital of ethiopia": "The capital of Ethiopia is Addis Ababa.",
  },
  {
    "capital of ethiopia": "The capital of Ethiopia is Addis Ababa.",
  },
  {
    "what is the capital of tanzania": "The capital of Tanzania is Dodoma.",
  },
  {
    "capital of tanzania": "The capital of Tanzania is Dodoma.",
  },
  {
    "what is the capital of uganda": "The capital of Uganda is Kampala.",
  },
  {
    "capital of uganda": "The capital of Uganda is Kampala.",
  },
  {
    "what is the capital of rwanda": "The capital of Rwanda is Kigali.",
  },
  {
    "capital of rwanda": "The capital of Rwanda is Kigali.",
  },
  {
    "what is the capital of senegal": "The capital of Senegal is Dakar.",
  },
  {
    "capital of senegal": "The capital of Senegal is Dakar.",
  },
  {
    "what is the capital of cameroon": "The capital of Cameroon is Yaoundé.",
  },
  {
    "capital of cameroon": "The capital of Cameroon is Yaoundé.",
  },
  {
    "what is the capital of niger": "The capital of Niger is Niamey.",
  },
  {
    "capital of niger": "The capital of Niger is Niamey.",
  },
  {
    "what is the capital of chad": "The capital of Chad is N'Djamena.",
  },
  {
    "capital of chad": "The capital of Chad is N'Djamena.",
  },
  {
    "what is the capital of mali": "The capital of Mali is Bamako.",
  },
  {
    "capital of mali": "The capital of Mali is Bamako.",
  },
  {
    "what is the capital of benin": "The capital of Benin is Porto-Novo.",
  },
  {
    "capital of benin": "The capital of Benin is Porto-Novo.",
  },
  {
    "what is the capital of togo": "The capital of Togo is Lomé.",
  },
  {
    "capital of togo": "The capital of Togo is Lomé.",
  },
  {
    "what is the capital of ivory coast": "The capital of Ivory Coast is Yamoussoukro (political), though Abidjan is the largest city.",
  },
  {
    "capital of ivory coast": "The capital of Ivory Coast is Yamoussoukro (political), though Abidjan is the largest city.",
  },
  {
    "what is the capital of liberia": "The capital of Liberia is Monrovia.",
  },
  {
    "capital of liberia": "The capital of Liberia is Monrovia.",
  },
  {
    "what is the capital of sierra leone": "The capital of Sierra Leone is Freetown.",
  },
  {
    "capital of sierra leone": "The capital of Sierra Leone is Freetown.",
  },
  {
    "what is the capital of gambia": "The capital of Gambia is Banjul.",
  },
  {
    "capital of gambia": "The capital of Gambia is Banjul.",
  },
  {
    "what is the capital of guinea": "The capital of Guinea is Conakry.",
  },
  {
    "capital of guinea": "The capital of Guinea is Conakry.",
  },
  {
    "what is the capital of burkina faso": "The capital of Burkina Faso is Ouagadougou.",
  },
  {
    "capital of burkina faso": "The capital of Burkina Faso is Ouagadougou.",
  },
  {
    "what is the capital of algeria": "The capital of Algeria is Algiers.",
  },
  {
    "capital of algeria": "The capital of Algeria is Algiers.",
  },
  {
    "what is the capital of morocco": "The capital of Morocco is Rabat.",
  },
  {
    "capital of morocco": "The capital of Morocco is Rabat.",
  },
  {
    "what is the capital of tunisia": "The capital of Tunisia is Tunis.",
  },
  {
    "capital of tunisia": "The capital of Tunisia is Tunis.",
  },
  {
    "what is the capital of libya": "The capital of Libya is Tripoli.",
  },
  {
    "capital of libya": "The capital of Libya is Tripoli.",
  },
  {
    "what is the capital of sudan": "The capital of Sudan is Khartoum.",
  },
  {
    "capital of sudan": "The capital of Sudan is Khartoum.",
  },
  {
    "what is the capital of angola": "The capital of Angola is Luanda.",
  },
  {
    "capital of angola": "The capital of Angola is Luanda.",
  },
  {
    "what is the capital of zambia": "The capital of Zambia is Lusaka.",
  },
  {
    "capital of zambia": "The capital of Zambia is Lusaka.",
  },
  {
    "what is the capital of zimbabwe": "The capital of Zimbabwe is Harare.",
  },
  {
    "capital of zimbabwe": "The capital of Zimbabwe is Harare.",
  },
  {
    "what is the capital of namibia": "The capital of Namibia is Windhoek.",
  },
  {
    "capital of namibia": "The capital of Namibia is Windhoek.",
  },
  {
    "what is the capital of botswana": "The capital of Botswana is Gaborone.",
  },
  {
    "capital of botswana": "The capital of Botswana is Gaborone.",
  },
  {
    "what is the capital of mozambique": "The capital of Mozambique is Maputo.",
  },
  {
    "capital of mozambique": "The capital of Mozambique is Maputo.",
  },
  {
    "what is the capital of madagascar": "The capital of Madagascar is Antananarivo.",
  },
  {
    "capital of madagascar": "The capital of Madagascar is Antananarivo.",
  },
  {
    "what is the capital of dr congo": "The capital of DR Congo is Kinshasa.",
  },
  {
    "capital of dr congo": "The capital of DR Congo is Kinshasa.",
  },
  {
    "what is the capital of gabon": "The capital of Gabon is Libreville.",
  },
  {
    "capital of gabon": "The capital of Gabon is Libreville.",
  },
  {
    "what is the capital of somalia": "The capital of Somalia is Mogadishu.",
  },
  {
    "capital of somalia": "The capital of Somalia is Mogadishu.",
  },
  {
    "what is the capital of france": "The capital of France is Paris.",
  },
  {
    "capital of france": "The capital of France is Paris.",
  },
  {
    "what is the capital of germany": "The capital of Germany is Berlin.",
  },
  {
    "capital of germany": "The capital of Germany is Berlin.",
  },
  {
    "what is the capital of italy": "The capital of Italy is Rome.",
  },
  {
    "capital of italy": "The capital of Italy is Rome.",
  },
  {
    "what is the capital of spain": "The capital of Spain is Madrid.",
  },
  {
    "capital of spain": "The capital of Spain is Madrid.",
  },
  {
    "what is the capital of portugal": "The capital of Portugal is Lisbon.",
  },
  {
    "capital of portugal": "The capital of Portugal is Lisbon.",
  },
  {
    "what is the capital of united kingdom": "The capital of United Kingdom is London.",
  },
  {
    "capital of united kingdom": "The capital of United Kingdom is London.",
  },
  {
    "what is the capital of ireland": "The capital of Ireland is Dublin.",
  },
  {
    "capital of ireland": "The capital of Ireland is Dublin.",
  },
  {
    "what is the capital of netherlands": "The capital of Netherlands is Amsterdam.",
  },
  {
    "capital of netherlands": "The capital of Netherlands is Amsterdam.",
  },
  {
    "what is the capital of belgium": "The capital of Belgium is Brussels.",
  },
  {
    "capital of belgium": "The capital of Belgium is Brussels.",
  },
  {
    "what is the capital of switzerland": "The capital of Switzerland is Bern.",
  },
  {
    "capital of switzerland": "The capital of Switzerland is Bern.",
  },
  {
    "what is the capital of austria": "The capital of Austria is Vienna.",
  },
  {
    "capital of austria": "The capital of Austria is Vienna.",
  },
  {
    "what is the capital of sweden": "The capital of Sweden is Stockholm.",
  },
  {
    "capital of sweden": "The capital of Sweden is Stockholm.",
  },
  {
    "what is the capital of norway": "The capital of Norway is Oslo.",
  },
  {
    "capital of norway": "The capital of Norway is Oslo.",
  },
  {
    "what is the capital of denmark": "The capital of Denmark is Copenhagen.",
  },
  {
    "capital of denmark": "The capital of Denmark is Copenhagen.",
  },
  {
    "what is the capital of finland": "The capital of Finland is Helsinki.",
  },
  {
    "capital of finland": "The capital of Finland is Helsinki.",
  },
  {
    "what is the capital of iceland": "The capital of Iceland is Reykjavik.",
  },
  {
    "capital of iceland": "The capital of Iceland is Reykjavik.",
  },
  {
    "what is the capital of poland": "The capital of Poland is Warsaw.",
  },
  {
    "capital of poland": "The capital of Poland is Warsaw.",
  },
  {
    "what is the capital of czech republic": "The capital of Czech Republic is Prague.",
  },
  {
    "capital of czech republic": "The capital of Czech Republic is Prague.",
  },
  {
    "what is the capital of hungary": "The capital of Hungary is Budapest.",
  },
  {
    "capital of hungary": "The capital of Hungary is Budapest.",
  },
  {
    "what is the capital of greece": "The capital of Greece is Athens.",
  },
  {
    "capital of greece": "The capital of Greece is Athens.",
  },
  {
    "what is the capital of romania": "The capital of Romania is Bucharest.",
  },
  {
    "capital of romania": "The capital of Romania is Bucharest.",
  },
  {
    "what is the capital of bulgaria": "The capital of Bulgaria is Sofia.",
  },
  {
    "capital of bulgaria": "The capital of Bulgaria is Sofia.",
  },
  {
    "what is the capital of ukraine": "The capital of Ukraine is Kyiv.",
  },
  {
    "capital of ukraine": "The capital of Ukraine is Kyiv.",
  },
  {
    "what is the capital of russia": "The capital of Russia is Moscow.",
  },
  {
    "capital of russia": "The capital of Russia is Moscow.",
  },
  {
    "what is the capital of serbia": "The capital of Serbia is Belgrade.",
  },
  {
    "capital of serbia": "The capital of Serbia is Belgrade.",
  },
  {
    "what is the capital of croatia": "The capital of Croatia is Zagreb.",
  },
  {
    "capital of croatia": "The capital of Croatia is Zagreb.",
  },
  {
    "what is the capital of turkey": "The capital of Turkey is Ankara.",
  },
  {
    "capital of turkey": "The capital of Turkey is Ankara.",
  },
  {
    "what is the capital of china": "The capital of China is Beijing.",
  },
  {
    "capital of china": "The capital of China is Beijing.",
  },
  {
    "what is the capital of japan": "The capital of Japan is Tokyo.",
  },
  {
    "capital of japan": "The capital of Japan is Tokyo.",
  },
  {
    "what is the capital of south korea": "The capital of South Korea is Seoul.",
  },
  {
    "capital of south korea": "The capital of South Korea is Seoul.",
  },
  {
    "what is the capital of india": "The capital of India is New Delhi.",
  },
  {
    "capital of india": "The capital of India is New Delhi.",
  },
  {
    "what is the capital of pakistan": "The capital of Pakistan is Islamabad.",
  },
  {
    "capital of pakistan": "The capital of Pakistan is Islamabad.",
  },
  {
    "what is the capital of bangladesh": "The capital of Bangladesh is Dhaka.",
  },
  {
    "capital of bangladesh": "The capital of Bangladesh is Dhaka.",
  },
  {
    "what is the capital of sri lanka": "The capital of Sri Lanka is Sri Jayawardenepura Kotte (with Colombo as the commercial capital).",
  },
  {
    "capital of sri lanka": "The capital of Sri Lanka is Sri Jayawardenepura Kotte (with Colombo as the commercial capital).",
  },
  {
    "what is the capital of nepal": "The capital of Nepal is Kathmandu.",
  },
  {
    "capital of nepal": "The capital of Nepal is Kathmandu.",
  },
  {
    "what is the capital of thailand": "The capital of Thailand is Bangkok.",
  },
  {
    "capital of thailand": "The capital of Thailand is Bangkok.",
  },
  {
    "what is the capital of vietnam": "The capital of Vietnam is Hanoi.",
  },
  {
    "capital of vietnam": "The capital of Vietnam is Hanoi.",
  },
  {
    "what is the capital of indonesia": "The capital of Indonesia is Jakarta.",
  },
  {
    "capital of indonesia": "The capital of Indonesia is Jakarta.",
  },
  {
    "what is the capital of malaysia": "The capital of Malaysia is Kuala Lumpur.",
  },
  {
    "capital of malaysia": "The capital of Malaysia is Kuala Lumpur.",
  },
  {
    "what is the capital of philippines": "The capital of Philippines is Manila.",
  },
  {
    "capital of philippines": "The capital of Philippines is Manila.",
  },
  {
    "what is the capital of singapore": "The capital of Singapore is Singapore.",
  },
  {
    "capital of singapore": "The capital of Singapore is Singapore.",
  },
  {
    "what is the capital of saudi arabia": "The capital of Saudi Arabia is Riyadh.",
  },
  {
    "capital of saudi arabia": "The capital of Saudi Arabia is Riyadh.",
  },
  {
    "what is the capital of united arab emirates": "The capital of United Arab Emirates is Abu Dhabi.",
  },
  {
    "capital of united arab emirates": "The capital of United Arab Emirates is Abu Dhabi.",
  },
  {
    "what is the capital of qatar": "The capital of Qatar is Doha.",
  },
  {
    "capital of qatar": "The capital of Qatar is Doha.",
  },
  {
    "what is the capital of iran": "The capital of Iran is Tehran.",
  },
  {
    "capital of iran": "The capital of Iran is Tehran.",
  },
  {
    "what is the capital of iraq": "The capital of Iraq is Baghdad.",
  },
  {
    "capital of iraq": "The capital of Iraq is Baghdad.",
  },
  {
    "what is the capital of israel": "The capital of Israel is Jerusalem.",
  },
  {
    "capital of israel": "The capital of Israel is Jerusalem.",
  },
  {
    "what is the capital of jordan": "The capital of Jordan is Amman.",
  },
  {
    "capital of jordan": "The capital of Jordan is Amman.",
  },
  {
    "what is the capital of lebanon": "The capital of Lebanon is Beirut.",
  },
  {
    "capital of lebanon": "The capital of Lebanon is Beirut.",
  },
  {
    "what is the capital of afghanistan": "The capital of Afghanistan is Kabul.",
  },
  {
    "capital of afghanistan": "The capital of Afghanistan is Kabul.",
  },
  {
    "what is the capital of kazakhstan": "The capital of Kazakhstan is Astana.",
  },
  {
    "capital of kazakhstan": "The capital of Kazakhstan is Astana.",
  },
  {
    "what is the capital of mongolia": "The capital of Mongolia is Ulaanbaatar.",
  },
  {
    "capital of mongolia": "The capital of Mongolia is Ulaanbaatar.",
  },
  {
    "what is the capital of united states": "The capital of United States is Washington, D.C..",
  },
  {
    "capital of united states": "The capital of United States is Washington, D.C..",
  },
  {
    "what is the capital of canada": "The capital of Canada is Ottawa.",
  },
  {
    "capital of canada": "The capital of Canada is Ottawa.",
  },
  {
    "what is the capital of mexico": "The capital of Mexico is Mexico City.",
  },
  {
    "capital of mexico": "The capital of Mexico is Mexico City.",
  },
  {
    "what is the capital of brazil": "The capital of Brazil is Brasília.",
  },
  {
    "capital of brazil": "The capital of Brazil is Brasília.",
  },
  {
    "what is the capital of argentina": "The capital of Argentina is Buenos Aires.",
  },
  {
    "capital of argentina": "The capital of Argentina is Buenos Aires.",
  },
  {
    "what is the capital of chile": "The capital of Chile is Santiago.",
  },
  {
    "capital of chile": "The capital of Chile is Santiago.",
  },
  {
    "what is the capital of peru": "The capital of Peru is Lima.",
  },
  {
    "capital of peru": "The capital of Peru is Lima.",
  },
  {
    "what is the capital of colombia": "The capital of Colombia is Bogotá.",
  },
  {
    "capital of colombia": "The capital of Colombia is Bogotá.",
  },
  {
    "what is the capital of venezuela": "The capital of Venezuela is Caracas.",
  },
  {
    "capital of venezuela": "The capital of Venezuela is Caracas.",
  },
  {
    "what is the capital of ecuador": "The capital of Ecuador is Quito.",
  },
  {
    "capital of ecuador": "The capital of Ecuador is Quito.",
  },
  {
    "what is the capital of bolivia": "The capital of Bolivia is Sucre (constitutional), with La Paz as the seat of government.",
  },
  {
    "capital of bolivia": "The capital of Bolivia is Sucre (constitutional), with La Paz as the seat of government.",
  },
  {
    "what is the capital of uruguay": "The capital of Uruguay is Montevideo.",
  },
  {
    "capital of uruguay": "The capital of Uruguay is Montevideo.",
  },
  {
    "what is the capital of paraguay": "The capital of Paraguay is Asunción.",
  },
  {
    "capital of paraguay": "The capital of Paraguay is Asunción.",
  },
  {
    "what is the capital of cuba": "The capital of Cuba is Havana.",
  },
  {
    "capital of cuba": "The capital of Cuba is Havana.",
  },
  {
    "what is the capital of jamaica": "The capital of Jamaica is Kingston.",
  },
  {
    "capital of jamaica": "The capital of Jamaica is Kingston.",
  },
  {
    "what is the capital of haiti": "The capital of Haiti is Port-au-Prince.",
  },
  {
    "capital of haiti": "The capital of Haiti is Port-au-Prince.",
  },
  {
    "what is the capital of dominican republic": "The capital of Dominican Republic is Santo Domingo.",
  },
  {
    "capital of dominican republic": "The capital of Dominican Republic is Santo Domingo.",
  },
  {
    "what is the capital of australia": "The capital of Australia is Canberra.",
  },
  {
    "capital of australia": "The capital of Australia is Canberra.",
  },
  {
    "what is the capital of new zealand": "The capital of New Zealand is Wellington.",
  },
  {
    "capital of new zealand": "The capital of New Zealand is Wellington.",
  },
  {
    "what is the capital of fiji": "The capital of Fiji is Suva.",
  },
  {
    "capital of fiji": "The capital of Fiji is Suva.",
  },
  {
    "what is the capital of abia state": "The capital of Abia State is Umuahia.",
  },
  {
    "capital of abia state": "The capital of Abia State is Umuahia.",
  },
  {
    "what is the capital of adamawa state": "The capital of Adamawa State is Yola.",
  },
  {
    "capital of adamawa state": "The capital of Adamawa State is Yola.",
  },
  {
    "what is the capital of akwa ibom state": "The capital of Akwa Ibom State is Uyo.",
  },
  {
    "capital of akwa ibom state": "The capital of Akwa Ibom State is Uyo.",
  },
  {
    "what is the capital of anambra state": "The capital of Anambra State is Awka.",
  },
  {
    "capital of anambra state": "The capital of Anambra State is Awka.",
  },
  {
    "what is the capital of bauchi state": "The capital of Bauchi State is Bauchi.",
  },
  {
    "capital of bauchi state": "The capital of Bauchi State is Bauchi.",
  },
  {
    "what is the capital of bayelsa state": "The capital of Bayelsa State is Yenagoa.",
  },
  {
    "capital of bayelsa state": "The capital of Bayelsa State is Yenagoa.",
  },
  {
    "what is the capital of benue state": "The capital of Benue State is Makurdi.",
  },
  {
    "capital of benue state": "The capital of Benue State is Makurdi.",
  },
  {
    "what is the capital of borno state": "The capital of Borno State is Maiduguri.",
  },
  {
    "capital of borno state": "The capital of Borno State is Maiduguri.",
  },
  {
    "what is the capital of cross river state": "The capital of Cross River State is Calabar.",
  },
  {
    "capital of cross river state": "The capital of Cross River State is Calabar.",
  },
  {
    "what is the capital of delta state": "The capital of Delta State is Asaba.",
  },
  {
    "capital of delta state": "The capital of Delta State is Asaba.",
  },
  {
    "what is the capital of ebonyi state": "The capital of Ebonyi State is Abakaliki.",
  },
  {
    "capital of ebonyi state": "The capital of Ebonyi State is Abakaliki.",
  },
  {
    "what is the capital of edo state": "The capital of Edo State is Benin City.",
  },
  {
    "capital of edo state": "The capital of Edo State is Benin City.",
  },
  {
    "what is the capital of ekiti state": "The capital of Ekiti State is Ado-Ekiti.",
  },
  {
    "capital of ekiti state": "The capital of Ekiti State is Ado-Ekiti.",
  },
  {
    "what is the capital of enugu state": "The capital of Enugu State is Enugu.",
  },
  {
    "capital of enugu state": "The capital of Enugu State is Enugu.",
  },
  {
    "what is the capital of gombe state": "The capital of Gombe State is Gombe.",
  },
  {
    "capital of gombe state": "The capital of Gombe State is Gombe.",
  },
  {
    "what is the capital of imo state": "The capital of Imo State is Owerri.",
  },
  {
    "capital of imo state": "The capital of Imo State is Owerri.",
  },
  {
    "what is the capital of jigawa state": "The capital of Jigawa State is Dutse.",
  },
  {
    "capital of jigawa state": "The capital of Jigawa State is Dutse.",
  },
  {
    "what is the capital of kaduna state": "The capital of Kaduna State is Kaduna.",
  },
  {
    "capital of kaduna state": "The capital of Kaduna State is Kaduna.",
  },
  {
    "what is the capital of kano state": "The capital of Kano State is Kano.",
  },
  {
    "capital of kano state": "The capital of Kano State is Kano.",
  },
  {
    "what is the capital of katsina state": "The capital of Katsina State is Katsina.",
  },
  {
    "capital of katsina state": "The capital of Katsina State is Katsina.",
  },
  {
    "what is the capital of kebbi state": "The capital of Kebbi State is Birnin Kebbi.",
  },
  {
    "capital of kebbi state": "The capital of Kebbi State is Birnin Kebbi.",
  },
  {
    "what is the capital of kogi state": "The capital of Kogi State is Lokoja.",
  },
  {
    "capital of kogi state": "The capital of Kogi State is Lokoja.",
  },
  {
    "what is the capital of kwara state": "The capital of Kwara State is Ilorin.",
  },
  {
    "capital of kwara state": "The capital of Kwara State is Ilorin.",
  },
  {
    "what is the capital of lagos state": "The capital of Lagos State is Ikeja.",
  },
  {
    "capital of lagos state": "The capital of Lagos State is Ikeja.",
  },
  {
    "what is the capital of nasarawa state": "The capital of Nasarawa State is Lafia.",
  },
  {
    "capital of nasarawa state": "The capital of Nasarawa State is Lafia.",
  },
  {
    "what is the capital of niger state": "The capital of Niger State is Minna.",
  },
  {
    "capital of niger state": "The capital of Niger State is Minna.",
  },
  {
    "what is the capital of ogun state": "The capital of Ogun State is Abeokuta.",
  },
  {
    "capital of ogun state": "The capital of Ogun State is Abeokuta.",
  },
  {
    "what is the capital of ondo state": "The capital of Ondo State is Akure.",
  },
  {
    "capital of ondo state": "The capital of Ondo State is Akure.",
  },
  {
    "what is the capital of osun state": "The capital of Osun State is Osogbo.",
  },
  {
    "capital of osun state": "The capital of Osun State is Osogbo.",
  },
  {
    "what is the capital of oyo state": "The capital of Oyo State is Ibadan.",
  },
  {
    "capital of oyo state": "The capital of Oyo State is Ibadan.",
  },
  {
    "what is the capital of plateau state": "The capital of Plateau State is Jos.",
  },
  {
    "capital of plateau state": "The capital of Plateau State is Jos.",
  },
  {
    "what is the capital of rivers state": "The capital of Rivers State is Port Harcourt.",
  },
  {
    "capital of rivers state": "The capital of Rivers State is Port Harcourt.",
  },
  {
    "what is the capital of sokoto state": "The capital of Sokoto State is Sokoto.",
  },
  {
    "capital of sokoto state": "The capital of Sokoto State is Sokoto.",
  },
  {
    "what is the capital of taraba state": "The capital of Taraba State is Jalingo.",
  },
  {
    "capital of taraba state": "The capital of Taraba State is Jalingo.",
  },
  {
    "what is the capital of yobe state": "The capital of Yobe State is Damaturu.",
  },
  {
    "capital of yobe state": "The capital of Yobe State is Damaturu.",
  },
  {
    "what is the capital of zamfara state": "The capital of Zamfara State is Gusau.",
  },
  {
    "capital of zamfara state": "The capital of Zamfara State is Gusau.",
  },
  {
    "what is the capital of fct": "The Federal Capital Territory's main city is Abuja, which is also Nigeria's capital.",
  },
  {
    "capital of fct": "The Federal Capital Territory's main city is Abuja, which is also Nigeria's capital.",
  },
  {
    "tell me about mercury": "Mercury is the smallest planet and the closest to the Sun. A year there lasts just 88 Earth days.",
  },
  {
    "tell me a fact about mercury": "Mercury is the smallest planet and the closest to the Sun. A year there lasts just 88 Earth days.",
  },
  {
    "tell me about venus": "Venus is the hottest planet, with surface temperatures around 465°C, thanks to its thick carbon dioxide atmosphere.",
  },
  {
    "tell me a fact about venus": "Venus is the hottest planet, with surface temperatures around 465°C, thanks to its thick carbon dioxide atmosphere.",
  },
  {
    "tell me about earth": "Earth is the only known planet with life. About 71% of its surface is covered by water.",
  },
  {
    "tell me a fact about earth": "Earth is the only known planet with life. About 71% of its surface is covered by water.",
  },
  {
    "tell me about mars": "Mars looks red because of iron oxide on its surface. It is home to Olympus Mons, the tallest volcano in the solar system.",
  },
  {
    "tell me a fact about mars": "Mars looks red because of iron oxide on its surface. It is home to Olympus Mons, the tallest volcano in the solar system.",
  },
  {
    "tell me about jupiter": "Jupiter is the largest planet, so big that all the other planets could fit inside it. Its Great Red Spot is a giant storm.",
  },
  {
    "tell me a fact about jupiter": "Jupiter is the largest planet, so big that all the other planets could fit inside it. Its Great Red Spot is a giant storm.",
  },
  {
    "tell me about saturn": "Saturn is famous for its rings of ice and rock. It is so light for its size that it would float in water if you had a big enough bathtub.",
  },
  {
    "tell me a fact about saturn": "Saturn is famous for its rings of ice and rock. It is so light for its size that it would float in water if you had a big enough bathtub.",
  },
  {
    "tell me about uranus": "Uranus is an ice giant that rotates on its side, so its poles take turns facing the Sun.",
  },
  {
    "tell me a fact about uranus": "Uranus is an ice giant that rotates on its side, so its poles take turns facing the Sun.",
  },
  {
    "tell me about neptune": "Neptune is the farthest planet from the Sun and has the fastest winds in the solar system. One year there lasts about 165 Earth years.",
  },
  {
    "tell me a fact about neptune": "Neptune is the farthest planet from the Sun and has the fastest winds in the solar system. One year there lasts about 165 Earth years.",
  },
  {
    "tell me about the sun": "The Sun holds about 99.8% of the mass of the solar system and is about 150 million km from Earth.",
  },
  {
    "tell me a fact about the sun": "The Sun holds about 99.8% of the mass of the solar system and is about 150 million km from Earth.",
  },
  {
    "tell me about the moon": "The Moon is about 384,400 km from Earth and is tidally locked, so we always see the same side.",
  },
  {
    "tell me a fact about the moon": "The Moon is about 384,400 km from Earth and is tidally locked, so we always see the same side.",
  },
  {
    "tell me about pluto": "Pluto was reclassified as a dwarf planet in 2006. It's smaller than Earth's Moon.",
  },
  {
    "tell me a fact about pluto": "Pluto was reclassified as a dwarf planet in 2006. It's smaller than Earth's Moon.",
  },
  {
    "tell me a fact about octopus": "Octopuses have three hearts and blue blood.",
  },
  {
    "fun fact about octopus": "Octopuses have three hearts and blue blood.",
  },
  {
    "fun fact about octopuss": "Octopuses have three hearts and blue blood.",
  },
  {
    "tell me a fact about elephant": "Elephants are the largest living land animals, and they can recognize themselves in a mirror.",
  },
  {
    "fun fact about elephant": "Elephants are the largest living land animals, and they can recognize themselves in a mirror.",
  },
  {
    "fun fact about elephants": "Elephants are the largest living land animals, and they can recognize themselves in a mirror.",
  },
  {
    "tell me a fact about giraffe": "Giraffes are the tallest land animals, reaching about 5.5 meters, and their tongues can be about 45 cm long.",
  },
  {
    "fun fact about giraffe": "Giraffes are the tallest land animals, reaching about 5.5 meters, and their tongues can be about 45 cm long.",
  },
  {
    "fun fact about giraffes": "Giraffes are the tallest land animals, reaching about 5.5 meters, and their tongues can be about 45 cm long.",
  },
  {
    "tell me a fact about dolphin": "Dolphins sleep with half their brain at a time and call each other using signature whistles.",
  },
  {
    "fun fact about dolphin": "Dolphins sleep with half their brain at a time and call each other using signature whistles.",
  },
  {
    "fun fact about dolphins": "Dolphins sleep with half their brain at a time and call each other using signature whistles.",
  },
  {
    "tell me a fact about penguin": "Penguins live almost entirely in the Southern Hemisphere, and emperor penguins can dive deeper than 500 meters.",
  },
  {
    "fun fact about penguin": "Penguins live almost entirely in the Southern Hemisphere, and emperor penguins can dive deeper than 500 meters.",
  },
  {
    "fun fact about penguins": "Penguins live almost entirely in the Southern Hemisphere, and emperor penguins can dive deeper than 500 meters.",
  },
  {
    "tell me a fact about owl": "Owls can rotate their heads about 270 degrees.",
  },
  {
    "fun fact about owl": "Owls can rotate their heads about 270 degrees.",
  },
  {
    "fun fact about owls": "Owls can rotate their heads about 270 degrees.",
  },
  {
    "tell me a fact about bee": "A worker honeybee makes only about one twelfth of a teaspoon of honey in her whole lifetime.",
  },
  {
    "fun fact about bee": "A worker honeybee makes only about one twelfth of a teaspoon of honey in her whole lifetime.",
  },
  {
    "fun fact about bees": "A worker honeybee makes only about one twelfth of a teaspoon of honey in her whole lifetime.",
  },
  {
    "tell me a fact about ant": "Ants can carry objects many times their own body weight.",
  },
  {
    "fun fact about ant": "Ants can carry objects many times their own body weight.",
  },
  {
    "fun fact about ants": "Ants can carry objects many times their own body weight.",
  },
  {
    "tell me a fact about shark": "Sharks have existed for over 400 million years, which is older than trees.",
  },
  {
    "fun fact about shark": "Sharks have existed for over 400 million years, which is older than trees.",
  },
  {
    "fun fact about sharks": "Sharks have existed for over 400 million years, which is older than trees.",
  },
  {
    "tell me a fact about whale": "The blue whale is the largest animal known to have ever lived, growing up to around 30 meters long.",
  },
  {
    "fun fact about whale": "The blue whale is the largest animal known to have ever lived, growing up to around 30 meters long.",
  },
  {
    "fun fact about whales": "The blue whale is the largest animal known to have ever lived, growing up to around 30 meters long.",
  },
  {
    "tell me a fact about crocodile": "Crocodiles cannot stick out their tongues.",
  },
  {
    "fun fact about crocodile": "Crocodiles cannot stick out their tongues.",
  },
  {
    "fun fact about crocodiles": "Crocodiles cannot stick out their tongues.",
  },
  {
    "tell me a fact about kangaroo": "A baby kangaroo, called a joey, is about the size of a jellybean when born.",
  },
  {
    "fun fact about kangaroo": "A baby kangaroo, called a joey, is about the size of a jellybean when born.",
  },
  {
    "fun fact about kangaroos": "A baby kangaroo, called a joey, is about the size of a jellybean when born.",
  },
  {
    "tell me a fact about koala": "Koalas can sleep up to 20 hours a day and have fingerprints very similar to humans'.",
  },
  {
    "fun fact about koala": "Koalas can sleep up to 20 hours a day and have fingerprints very similar to humans'.",
  },
  {
    "fun fact about koalas": "Koalas can sleep up to 20 hours a day and have fingerprints very similar to humans'.",
  },
  {
    "tell me a fact about panda": "Giant pandas spend around 12 hours a day eating bamboo.",
  },
  {
    "fun fact about panda": "Giant pandas spend around 12 hours a day eating bamboo.",
  },
  {
    "fun fact about pandas": "Giant pandas spend around 12 hours a day eating bamboo.",
  },
  {
    "tell me a fact about cheetah": "The cheetah is the fastest land animal, reaching about 100 km/h in short bursts.",
  },
  {
    "fun fact about cheetah": "The cheetah is the fastest land animal, reaching about 100 km/h in short bursts.",
  },
  {
    "fun fact about cheetahs": "The cheetah is the fastest land animal, reaching about 100 km/h in short bursts.",
  },
  {
    "tell me a fact about lion": "Lions sleep up to 20 hours a day, and a group of lions is called a pride.",
  },
  {
    "fun fact about lion": "Lions sleep up to 20 hours a day, and a group of lions is called a pride.",
  },
  {
    "fun fact about lions": "Lions sleep up to 20 hours a day, and a group of lions is called a pride.",
  },
  {
    "tell me a fact about tiger": "Every tiger has a unique stripe pattern, much like a fingerprint.",
  },
  {
    "fun fact about tiger": "Every tiger has a unique stripe pattern, much like a fingerprint.",
  },
  {
    "fun fact about tigers": "Every tiger has a unique stripe pattern, much like a fingerprint.",
  },
  {
    "tell me a fact about wolf": "Wolves live in packs and use howls to communicate across long distances.",
  },
  {
    "fun fact about wolf": "Wolves live in packs and use howls to communicate across long distances.",
  },
  {
    "fun fact about wolfs": "Wolves live in packs and use howls to communicate across long distances.",
  },
  {
    "tell me a fact about bat": "Bats are the only mammals capable of true, sustained flight.",
  },
  {
    "fun fact about bat": "Bats are the only mammals capable of true, sustained flight.",
  },
  {
    "fun fact about bats": "Bats are the only mammals capable of true, sustained flight.",
  },
  {
    "tell me a fact about camel": "A camel's hump stores fat, not water.",
  },
  {
    "fun fact about camel": "A camel's hump stores fat, not water.",
  },
  {
    "fun fact about camels": "A camel's hump stores fat, not water.",
  },
  {
    "tell me a fact about chameleon": "Chameleons can move their eyes independently of each other.",
  },
  {
    "fun fact about chameleon": "Chameleons can move their eyes independently of each other.",
  },
  {
    "fun fact about chameleons": "Chameleons can move their eyes independently of each other.",
  },
  {
    "tell me a fact about cat": "Cats sleep 12 to 16 hours a day, and their purring may help them calm down and heal.",
  },
  {
    "fun fact about cat": "Cats sleep 12 to 16 hours a day, and their purring may help them calm down and heal.",
  },
  {
    "fun fact about cats": "Cats sleep 12 to 16 hours a day, and their purring may help them calm down and heal.",
  },
  {
    "tell me a fact about dog": "A dog's sense of smell is many times more sensitive than a human's.",
  },
  {
    "fun fact about dog": "A dog's sense of smell is many times more sensitive than a human's.",
  },
  {
    "fun fact about dogs": "A dog's sense of smell is many times more sensitive than a human's.",
  },
  {
    "tell me a fact about horse": "Horses can sleep standing up thanks to a locking mechanism in their legs.",
  },
  {
    "fun fact about horse": "Horses can sleep standing up thanks to a locking mechanism in their legs.",
  },
  {
    "fun fact about horses": "Horses can sleep standing up thanks to a locking mechanism in their legs.",
  },
  {
    "tell me a fact about cow": "Cows have a stomach with four compartments and can form close friendships.",
  },
  {
    "fun fact about cow": "Cows have a stomach with four compartments and can form close friendships.",
  },
  {
    "fun fact about cows": "Cows have a stomach with four compartments and can form close friendships.",
  },
  {
    "tell me a fact about pig": "Pigs are considered one of the smartest domestic animals and can learn tricks.",
  },
  {
    "fun fact about pig": "Pigs are considered one of the smartest domestic animals and can learn tricks.",
  },
  {
    "fun fact about pigs": "Pigs are considered one of the smartest domestic animals and can learn tricks.",
  },
  {
    "tell me a fact about chicken": "There are more chickens on Earth than humans.",
  },
  {
    "fun fact about chicken": "There are more chickens on Earth than humans.",
  },
  {
    "fun fact about chickens": "There are more chickens on Earth than humans.",
  },
  {
    "tell me a fact about snail": "Some snails can sleep for years in dry conditions.",
  },
  {
    "fun fact about snail": "Some snails can sleep for years in dry conditions.",
  },
  {
    "fun fact about snails": "Some snails can sleep for years in dry conditions.",
  },
  {
    "tell me a fact about butterfly": "Butterflies taste with their feet.",
  },
  {
    "fun fact about butterfly": "Butterflies taste with their feet.",
  },
  {
    "fun fact about butterflys": "Butterflies taste with their feet.",
  },
  {
    "tell me a fact about hummingbird": "Hummingbirds are the only birds that can fly backward.",
  },
  {
    "fun fact about hummingbird": "Hummingbirds are the only birds that can fly backward.",
  },
  {
    "fun fact about hummingbirds": "Hummingbirds are the only birds that can fly backward.",
  },
  {
    "tell me a fact about eagle": "Eagles have eyesight many times sharper than humans'.",
  },
  {
    "fun fact about eagle": "Eagles have eyesight many times sharper than humans'.",
  },
  {
    "fun fact about eagles": "Eagles have eyesight many times sharper than humans'.",
  },
  {
    "tell me a fact about parrot": "Some parrots can mimic human speech remarkably well.",
  },
  {
    "fun fact about parrot": "Some parrots can mimic human speech remarkably well.",
  },
  {
    "fun fact about parrots": "Some parrots can mimic human speech remarkably well.",
  },
  {
    "tell me a fact about turtle": "A turtle's shell is part of its skeleton, and some species live over 100 years.",
  },
  {
    "fun fact about turtle": "A turtle's shell is part of its skeleton, and some species live over 100 years.",
  },
  {
    "fun fact about turtles": "A turtle's shell is part of its skeleton, and some species live over 100 years.",
  },
  {
    "tell me a fact about frog": "Frogs can absorb water through their skin.",
  },
  {
    "fun fact about frog": "Frogs can absorb water through their skin.",
  },
  {
    "fun fact about frogs": "Frogs can absorb water through their skin.",
  },
  {
    "tell me a fact about snake": "Snakes smell by flicking their tongues, and they don't have eyelids.",
  },
  {
    "fun fact about snake": "Snakes smell by flicking their tongues, and they don't have eyelids.",
  },
  {
    "fun fact about snakes": "Snakes smell by flicking their tongues, and they don't have eyelids.",
  },
  {
    "tell me a fact about gorilla": "Gorillas share about 98% of their DNA with humans.",
  },
  {
    "fun fact about gorilla": "Gorillas share about 98% of their DNA with humans.",
  },
  {
    "fun fact about gorillas": "Gorillas share about 98% of their DNA with humans.",
  },
  {
    "tell me a fact about chimpanzee": "Chimpanzees use tools, such as sticks to fish termites out of mounds.",
  },
  {
    "fun fact about chimpanzee": "Chimpanzees use tools, such as sticks to fish termites out of mounds.",
  },
  {
    "fun fact about chimpanzees": "Chimpanzees use tools, such as sticks to fish termites out of mounds.",
  },
  {
    "tell me a fact about polar bear": "A polar bear's skin is black, and its fur is actually transparent, not white.",
  },
  {
    "fun fact about polar bear": "A polar bear's skin is black, and its fur is actually transparent, not white.",
  },
  {
    "fun fact about polar bears": "A polar bear's skin is black, and its fur is actually transparent, not white.",
  },
  {
    "tell me a fact about sloth": "Sloths move so slowly that algae can grow on their fur.",
  },
  {
    "fun fact about sloth": "Sloths move so slowly that algae can grow on their fur.",
  },
  {
    "fun fact about sloths": "Sloths move so slowly that algae can grow on their fur.",
  },
  {
    "tell me a fact about seahorse": "In seahorses, the male carries the babies until they're born.",
  },
  {
    "fun fact about seahorse": "In seahorses, the male carries the babies until they're born.",
  },
  {
    "fun fact about seahorses": "In seahorses, the male carries the babies until they're born.",
  },
  {
    "tell me a fact about jellyfish": "Jellyfish have no brain, no heart, and are about 95% water.",
  },
  {
    "fun fact about jellyfish": "Jellyfish have no brain, no heart, and are about 95% water.",
  },
  {
    "fun fact about jellyfishs": "Jellyfish have no brain, no heart, and are about 95% water.",
  },
  {
    "tell me a fact about starfish": "Starfish can regrow lost arms and have no brain.",
  },
  {
    "fun fact about starfish": "Starfish can regrow lost arms and have no brain.",
  },
  {
    "fun fact about starfishs": "Starfish can regrow lost arms and have no brain.",
  },
  {
    "tell me a fact about flamingo": "Flamingos are pink because of the pigments in the algae and shrimp they eat.",
  },
  {
    "fun fact about flamingo": "Flamingos are pink because of the pigments in the algae and shrimp they eat.",
  },
  {
    "fun fact about flamingos": "Flamingos are pink because of the pigments in the algae and shrimp they eat.",
  },
  {
    "tell me a fact about ostrich": "Ostriches are the largest birds and the fastest runners among birds, reaching about 70 km/h.",
  },
  {
    "fun fact about ostrich": "Ostriches are the largest birds and the fastest runners among birds, reaching about 70 km/h.",
  },
  {
    "fun fact about ostrichs": "Ostriches are the largest birds and the fastest runners among birds, reaching about 70 km/h.",
  },
  {
    "tell me a fact about platypus": "The platypus is a mammal that lays eggs.",
  },
  {
    "fun fact about platypus": "The platypus is a mammal that lays eggs.",
  },
  {
    "fun fact about platypuss": "The platypus is a mammal that lays eggs.",
  },
  {
    "tell me a fact about hippo": "Hippos can't really swim. They walk along the bottom of rivers.",
  },
  {
    "fun fact about hippo": "Hippos can't really swim. They walk along the bottom of rivers.",
  },
  {
    "fun fact about hippos": "Hippos can't really swim. They walk along the bottom of rivers.",
  },
  {
    "tell me a fact about rhino": "A rhino's horn is made of keratin, the same material as your fingernails.",
  },
  {
    "fun fact about rhino": "A rhino's horn is made of keratin, the same material as your fingernails.",
  },
  {
    "fun fact about rhinos": "A rhino's horn is made of keratin, the same material as your fingernails.",
  },
  {
    "tell me a fact about zebra": "Every zebra has a unique stripe pattern.",
  },
  {
    "fun fact about zebra": "Every zebra has a unique stripe pattern.",
  },
  {
    "fun fact about zebras": "Every zebra has a unique stripe pattern.",
  },
  {
    "tell me a fact about squirrel": "Squirrels forget where they bury many of their nuts, which helps forests grow.",
  },
  {
    "fun fact about squirrel": "Squirrels forget where they bury many of their nuts, which helps forests grow.",
  },
  {
    "fun fact about squirrels": "Squirrels forget where they bury many of their nuts, which helps forests grow.",
  },
  {
    "tell me a fact about crow": "Crows can recognize human faces and use tools.",
  },
  {
    "fun fact about crow": "Crows can recognize human faces and use tools.",
  },
  {
    "fun fact about crows": "Crows can recognize human faces and use tools.",
  },
  {
    "what is the symbol for hydrogen": "The chemical symbol for Hydrogen is H.",
  },
  {
    "what is the atomic number of hydrogen": "Hydrogen has atomic number 1.",
  },
  {
    "which element has the symbol h": "H is the symbol for Hydrogen, atomic number 1.",
  },
  {
    "what is the symbol for helium": "The chemical symbol for Helium is He.",
  },
  {
    "what is the atomic number of helium": "Helium has atomic number 2.",
  },
  {
    "which element has the symbol he": "He is the symbol for Helium, atomic number 2.",
  },
  {
    "what is the symbol for lithium": "The chemical symbol for Lithium is Li.",
  },
  {
    "what is the atomic number of lithium": "Lithium has atomic number 3.",
  },
  {
    "which element has the symbol li": "Li is the symbol for Lithium, atomic number 3.",
  },
  {
    "what is the symbol for beryllium": "The chemical symbol for Beryllium is Be.",
  },
  {
    "what is the atomic number of beryllium": "Beryllium has atomic number 4.",
  },
  {
    "which element has the symbol be": "Be is the symbol for Beryllium, atomic number 4.",
  },
  {
    "what is the symbol for boron": "The chemical symbol for Boron is B.",
  },
  {
    "what is the atomic number of boron": "Boron has atomic number 5.",
  },
  {
    "which element has the symbol b": "B is the symbol for Boron, atomic number 5.",
  },
  {
    "what is the symbol for carbon": "The chemical symbol for Carbon is C.",
  },
  {
    "what is the atomic number of carbon": "Carbon has atomic number 6.",
  },
  {
    "which element has the symbol c": "C is the symbol for Carbon, atomic number 6.",
  },
  {
    "what is the symbol for nitrogen": "The chemical symbol for Nitrogen is N.",
  },
  {
    "what is the atomic number of nitrogen": "Nitrogen has atomic number 7.",
  },
  {
    "which element has the symbol n": "N is the symbol for Nitrogen, atomic number 7.",
  },
  {
    "what is the symbol for oxygen": "The chemical symbol for Oxygen is O.",
  },
  {
    "what is the atomic number of oxygen": "Oxygen has atomic number 8.",
  },
  {
    "which element has the symbol o": "O is the symbol for Oxygen, atomic number 8.",
  },
  {
    "what is the symbol for fluorine": "The chemical symbol for Fluorine is F.",
  },
  {
    "what is the atomic number of fluorine": "Fluorine has atomic number 9.",
  },
  {
    "which element has the symbol f": "F is the symbol for Fluorine, atomic number 9.",
  },
  {
    "what is the symbol for neon": "The chemical symbol for Neon is Ne.",
  },
  {
    "what is the atomic number of neon": "Neon has atomic number 10.",
  },
  {
    "which element has the symbol ne": "Ne is the symbol for Neon, atomic number 10.",
  },
  {
    "what is the symbol for sodium": "The chemical symbol for Sodium is Na.",
  },
  {
    "what is the atomic number of sodium": "Sodium has atomic number 11.",
  },
  {
    "which element has the symbol na": "Na is the symbol for Sodium, atomic number 11.",
  },
  {
    "what is the symbol for magnesium": "The chemical symbol for Magnesium is Mg.",
  },
  {
    "what is the atomic number of magnesium": "Magnesium has atomic number 12.",
  },
  {
    "which element has the symbol mg": "Mg is the symbol for Magnesium, atomic number 12.",
  },
  {
    "what is the symbol for aluminium": "The chemical symbol for Aluminium is Al.",
  },
  {
    "what is the atomic number of aluminium": "Aluminium has atomic number 13.",
  },
  {
    "which element has the symbol al": "Al is the symbol for Aluminium, atomic number 13.",
  },
  {
    "what is the symbol for silicon": "The chemical symbol for Silicon is Si.",
  },
  {
    "what is the atomic number of silicon": "Silicon has atomic number 14.",
  },
  {
    "which element has the symbol si": "Si is the symbol for Silicon, atomic number 14.",
  },
  {
    "what is the symbol for phosphorus": "The chemical symbol for Phosphorus is P.",
  },
  {
    "what is the atomic number of phosphorus": "Phosphorus has atomic number 15.",
  },
  {
    "which element has the symbol p": "P is the symbol for Phosphorus, atomic number 15.",
  },
  {
    "what is the symbol for sulfur": "The chemical symbol for Sulfur is S.",
  },
  {
    "what is the atomic number of sulfur": "Sulfur has atomic number 16.",
  },
  {
    "which element has the symbol s": "S is the symbol for Sulfur, atomic number 16.",
  },
  {
    "what is the symbol for chlorine": "The chemical symbol for Chlorine is Cl.",
  },
  {
    "what is the atomic number of chlorine": "Chlorine has atomic number 17.",
  },
  {
    "which element has the symbol cl": "Cl is the symbol for Chlorine, atomic number 17.",
  },
  {
    "what is the symbol for argon": "The chemical symbol for Argon is Ar.",
  },
  {
    "what is the atomic number of argon": "Argon has atomic number 18.",
  },
  {
    "which element has the symbol ar": "Ar is the symbol for Argon, atomic number 18.",
  },
  {
    "what is the symbol for potassium": "The chemical symbol for Potassium is K.",
  },
  {
    "what is the atomic number of potassium": "Potassium has atomic number 19.",
  },
  {
    "which element has the symbol k": "K is the symbol for Potassium, atomic number 19.",
  },
  {
    "what is the symbol for calcium": "The chemical symbol for Calcium is Ca.",
  },
  {
    "what is the atomic number of calcium": "Calcium has atomic number 20.",
  },
  {
    "which element has the symbol ca": "Ca is the symbol for Calcium, atomic number 20.",
  },
  {
    "what is the symbol for scandium": "The chemical symbol for Scandium is Sc.",
  },
  {
    "what is the atomic number of scandium": "Scandium has atomic number 21.",
  },
  {
    "which element has the symbol sc": "Sc is the symbol for Scandium, atomic number 21.",
  },
  {
    "what is the symbol for titanium": "The chemical symbol for Titanium is Ti.",
  },
  {
    "what is the atomic number of titanium": "Titanium has atomic number 22.",
  },
  {
    "which element has the symbol ti": "Ti is the symbol for Titanium, atomic number 22.",
  },
  {
    "what is the symbol for vanadium": "The chemical symbol for Vanadium is V.",
  },
  {
    "what is the atomic number of vanadium": "Vanadium has atomic number 23.",
  },
  {
    "which element has the symbol v": "V is the symbol for Vanadium, atomic number 23.",
  },
  {
    "what is the symbol for chromium": "The chemical symbol for Chromium is Cr.",
  },
  {
    "what is the atomic number of chromium": "Chromium has atomic number 24.",
  },
  {
    "which element has the symbol cr": "Cr is the symbol for Chromium, atomic number 24.",
  },
  {
    "what is the symbol for manganese": "The chemical symbol for Manganese is Mn.",
  },
  {
    "what is the atomic number of manganese": "Manganese has atomic number 25.",
  },
  {
    "which element has the symbol mn": "Mn is the symbol for Manganese, atomic number 25.",
  },
  {
    "what is the symbol for iron": "The chemical symbol for Iron is Fe.",
  },
  {
    "what is the atomic number of iron": "Iron has atomic number 26.",
  },
  {
    "which element has the symbol fe": "Fe is the symbol for Iron, atomic number 26.",
  },
  {
    "what is the symbol for cobalt": "The chemical symbol for Cobalt is Co.",
  },
  {
    "what is the atomic number of cobalt": "Cobalt has atomic number 27.",
  },
  {
    "which element has the symbol co": "Co is the symbol for Cobalt, atomic number 27.",
  },
  {
    "what is the symbol for nickel": "The chemical symbol for Nickel is Ni.",
  },
  {
    "what is the atomic number of nickel": "Nickel has atomic number 28.",
  },
  {
    "which element has the symbol ni": "Ni is the symbol for Nickel, atomic number 28.",
  },
  {
    "what is the symbol for copper": "The chemical symbol for Copper is Cu.",
  },
  {
    "what is the atomic number of copper": "Copper has atomic number 29.",
  },
  {
    "which element has the symbol cu": "Cu is the symbol for Copper, atomic number 29.",
  },
  {
    "what is the symbol for zinc": "The chemical symbol for Zinc is Zn.",
  },
  {
    "what is the atomic number of zinc": "Zinc has atomic number 30.",
  },
  {
    "which element has the symbol zn": "Zn is the symbol for Zinc, atomic number 30.",
  },
  {
    "what is the symbol for gallium": "The chemical symbol for Gallium is Ga.",
  },
  {
    "what is the atomic number of gallium": "Gallium has atomic number 31.",
  },
  {
    "which element has the symbol ga": "Ga is the symbol for Gallium, atomic number 31.",
  },
  {
    "what is the symbol for germanium": "The chemical symbol for Germanium is Ge.",
  },
  {
    "what is the atomic number of germanium": "Germanium has atomic number 32.",
  },
  {
    "which element has the symbol ge": "Ge is the symbol for Germanium, atomic number 32.",
  },
  {
    "what is the symbol for arsenic": "The chemical symbol for Arsenic is As.",
  },
  {
    "what is the atomic number of arsenic": "Arsenic has atomic number 33.",
  },
  {
    "which element has the symbol as": "As is the symbol for Arsenic, atomic number 33.",
  },
  {
    "what is the symbol for selenium": "The chemical symbol for Selenium is Se.",
  },
  {
    "what is the atomic number of selenium": "Selenium has atomic number 34.",
  },
  {
    "which element has the symbol se": "Se is the symbol for Selenium, atomic number 34.",
  },
  {
    "what is the symbol for bromine": "The chemical symbol for Bromine is Br.",
  },
  {
    "what is the atomic number of bromine": "Bromine has atomic number 35.",
  },
  {
    "which element has the symbol br": "Br is the symbol for Bromine, atomic number 35.",
  },
  {
    "what is the symbol for krypton": "The chemical symbol for Krypton is Kr.",
  },
  {
    "what is the atomic number of krypton": "Krypton has atomic number 36.",
  },
  {
    "which element has the symbol kr": "Kr is the symbol for Krypton, atomic number 36.",
  },
  {
    "what is the symbol for rubidium": "The chemical symbol for Rubidium is Rb.",
  },
  {
    "what is the atomic number of rubidium": "Rubidium has atomic number 37.",
  },
  {
    "which element has the symbol rb": "Rb is the symbol for Rubidium, atomic number 37.",
  },
  {
    "what is the symbol for strontium": "The chemical symbol for Strontium is Sr.",
  },
  {
    "what is the atomic number of strontium": "Strontium has atomic number 38.",
  },
  {
    "which element has the symbol sr": "Sr is the symbol for Strontium, atomic number 38.",
  },
  {
    "what is the symbol for yttrium": "The chemical symbol for Yttrium is Y.",
  },
  {
    "what is the atomic number of yttrium": "Yttrium has atomic number 39.",
  },
  {
    "which element has the symbol y": "Y is the symbol for Yttrium, atomic number 39.",
  },
  {
    "what is the symbol for zirconium": "The chemical symbol for Zirconium is Zr.",
  },
  {
    "what is the atomic number of zirconium": "Zirconium has atomic number 40.",
  },
  {
    "which element has the symbol zr": "Zr is the symbol for Zirconium, atomic number 40.",
  },
  {
    "what is the symbol for niobium": "The chemical symbol for Niobium is Nb.",
  },
  {
    "what is the atomic number of niobium": "Niobium has atomic number 41.",
  },
  {
    "which element has the symbol nb": "Nb is the symbol for Niobium, atomic number 41.",
  },
  {
    "what is the symbol for molybdenum": "The chemical symbol for Molybdenum is Mo.",
  },
  {
    "what is the atomic number of molybdenum": "Molybdenum has atomic number 42.",
  },
  {
    "which element has the symbol mo": "Mo is the symbol for Molybdenum, atomic number 42.",
  },
  {
    "what is the symbol for technetium": "The chemical symbol for Technetium is Tc.",
  },
  {
    "what is the atomic number of technetium": "Technetium has atomic number 43.",
  },
  {
    "which element has the symbol tc": "Tc is the symbol for Technetium, atomic number 43.",
  },
  {
    "what is the symbol for ruthenium": "The chemical symbol for Ruthenium is Ru.",
  },
  {
    "what is the atomic number of ruthenium": "Ruthenium has atomic number 44.",
  },
  {
    "which element has the symbol ru": "Ru is the symbol for Ruthenium, atomic number 44.",
  },
  {
    "what is the symbol for rhodium": "The chemical symbol for Rhodium is Rh.",
  },
  {
    "what is the atomic number of rhodium": "Rhodium has atomic number 45.",
  },
  {
    "which element has the symbol rh": "Rh is the symbol for Rhodium, atomic number 45.",
  },
  {
    "what is the symbol for palladium": "The chemical symbol for Palladium is Pd.",
  },
  {
    "what is the atomic number of palladium": "Palladium has atomic number 46.",
  },
  {
    "which element has the symbol pd": "Pd is the symbol for Palladium, atomic number 46.",
  },
  {
    "what is the symbol for silver": "The chemical symbol for Silver is Ag.",
  },
  {
    "what is the atomic number of silver": "Silver has atomic number 47.",
  },
  {
    "which element has the symbol ag": "Ag is the symbol for Silver, atomic number 47.",
  },
  {
    "what is the symbol for cadmium": "The chemical symbol for Cadmium is Cd.",
  },
  {
    "what is the atomic number of cadmium": "Cadmium has atomic number 48.",
  },
  {
    "which element has the symbol cd": "Cd is the symbol for Cadmium, atomic number 48.",
  },
  {
    "what is the symbol for indium": "The chemical symbol for Indium is In.",
  },
  {
    "what is the atomic number of indium": "Indium has atomic number 49.",
  },
  {
    "which element has the symbol in": "In is the symbol for Indium, atomic number 49.",
  },
  {
    "what is the symbol for tin": "The chemical symbol for Tin is Sn.",
  },
  {
    "what is the atomic number of tin": "Tin has atomic number 50.",
  },
  {
    "which element has the symbol sn": "Sn is the symbol for Tin, atomic number 50.",
  },
  {
    "what is the symbol for antimony": "The chemical symbol for Antimony is Sb.",
  },
  {
    "what is the atomic number of antimony": "Antimony has atomic number 51.",
  },
  {
    "which element has the symbol sb": "Sb is the symbol for Antimony, atomic number 51.",
  },
  {
    "what is the symbol for tellurium": "The chemical symbol for Tellurium is Te.",
  },
  {
    "what is the atomic number of tellurium": "Tellurium has atomic number 52.",
  },
  {
    "which element has the symbol te": "Te is the symbol for Tellurium, atomic number 52.",
  },
  {
    "what is the symbol for iodine": "The chemical symbol for Iodine is I.",
  },
  {
    "what is the atomic number of iodine": "Iodine has atomic number 53.",
  },
  {
    "which element has the symbol i": "I is the symbol for Iodine, atomic number 53.",
  },
  {
    "what is the symbol for xenon": "The chemical symbol for Xenon is Xe.",
  },
  {
    "what is the atomic number of xenon": "Xenon has atomic number 54.",
  },
  {
    "which element has the symbol xe": "Xe is the symbol for Xenon, atomic number 54.",
  },
  {
    "what is the symbol for tungsten": "The chemical symbol for Tungsten is W.",
  },
  {
    "what is the atomic number of tungsten": "Tungsten has atomic number 74.",
  },
  {
    "which element has the symbol w": "W is the symbol for Tungsten, atomic number 74.",
  },
  {
    "what is the symbol for platinum": "The chemical symbol for Platinum is Pt.",
  },
  {
    "what is the atomic number of platinum": "Platinum has atomic number 78.",
  },
  {
    "which element has the symbol pt": "Pt is the symbol for Platinum, atomic number 78.",
  },
  {
    "what is the symbol for gold": "The chemical symbol for Gold is Au.",
  },
  {
    "what is the atomic number of gold": "Gold has atomic number 79.",
  },
  {
    "which element has the symbol au": "Au is the symbol for Gold, atomic number 79.",
  },
  {
    "what is the symbol for mercury": "The chemical symbol for Mercury is Hg.",
  },
  {
    "what is the atomic number of mercury": "Mercury has atomic number 80.",
  },
  {
    "which element has the symbol hg": "Hg is the symbol for Mercury, atomic number 80.",
  },
  {
    "what is the symbol for lead": "The chemical symbol for Lead is Pb.",
  },
  {
    "what is the atomic number of lead": "Lead has atomic number 82.",
  },
  {
    "which element has the symbol pb": "Pb is the symbol for Lead, atomic number 82.",
  },
  {
    "what is the symbol for uranium": "The chemical symbol for Uranium is U.",
  },
  {
    "what is the atomic number of uranium": "Uranium has atomic number 92.",
  },
  {
    "which element has the symbol u": "U is the symbol for Uranium, atomic number 92.",
  },
  {
    "what is the symbol for aluminum": "The chemical symbol for Aluminium (Aluminum) is Al.",
  },
  {
    "what is the symbol for sulphur": "The chemical symbol for Sulfur (Sulphur) is S.",
  },
  {
    "what is html": "HTML (HyperText Markup Language) is the standard language used to structure the content of web pages.",
  },
  {
    "explain html": "HTML (HyperText Markup Language) is the standard language used to structure the content of web pages.",
  },
  {
    "define html": "HTML (HyperText Markup Language) is the standard language used to structure the content of web pages.",
  },
  {
    "what is css": "CSS (Cascading Style Sheets) controls how HTML elements look: colors, fonts, spacing, and layout.",
  },
  {
    "explain css": "CSS (Cascading Style Sheets) controls how HTML elements look: colors, fonts, spacing, and layout.",
  },
  {
    "define css": "CSS (Cascading Style Sheets) controls how HTML elements look: colors, fonts, spacing, and layout.",
  },
  {
    "what is react": "React is a JavaScript library for building user interfaces out of reusable components.",
  },
  {
    "explain react": "React is a JavaScript library for building user interfaces out of reusable components.",
  },
  {
    "define react": "React is a JavaScript library for building user interfaces out of reusable components.",
  },
  {
    "what is node js": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "explain node js": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "define node js": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "what is nodejs": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "explain nodejs": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "define nodejs": "Node.js lets you run JavaScript outside the browser, such as on servers.",
  },
  {
    "what is python": "Python is a beginner-friendly programming language used for web apps, automation, data science, and AI.",
  },
  {
    "explain python": "Python is a beginner-friendly programming language used for web apps, automation, data science, and AI.",
  },
  {
    "define python": "Python is a beginner-friendly programming language used for web apps, automation, data science, and AI.",
  },
  {
    "what is java": "Java is a popular, object-oriented language used for Android apps and large enterprise systems.",
  },
  {
    "explain java": "Java is a popular, object-oriented language used for Android apps and large enterprise systems.",
  },
  {
    "define java": "Java is a popular, object-oriented language used for Android apps and large enterprise systems.",
  },
  {
    "what is c plus plus": "C++ is a powerful, fast language used for games, operating systems, and performance-critical software.",
  },
  {
    "explain c plus plus": "C++ is a powerful, fast language used for games, operating systems, and performance-critical software.",
  },
  {
    "define c plus plus": "C++ is a powerful, fast language used for games, operating systems, and performance-critical software.",
  },
  {
    "what is c sharp": "C# is a language from Microsoft used for Windows apps, games with Unity, and web services.",
  },
  {
    "explain c sharp": "C# is a language from Microsoft used for Windows apps, games with Unity, and web services.",
  },
  {
    "define c sharp": "C# is a language from Microsoft used for Windows apps, games with Unity, and web services.",
  },
  {
    "what is php": "PHP is a server-side scripting language widely used to build websites, including WordPress.",
  },
  {
    "explain php": "PHP is a server-side scripting language widely used to build websites, including WordPress.",
  },
  {
    "define php": "PHP is a server-side scripting language widely used to build websites, including WordPress.",
  },
  {
    "what is sql": "SQL (Structured Query Language) is used to store, query, and manage data in relational databases.",
  },
  {
    "explain sql": "SQL (Structured Query Language) is used to store, query, and manage data in relational databases.",
  },
  {
    "define sql": "SQL (Structured Query Language) is used to store, query, and manage data in relational databases.",
  },
  {
    "what is git": "Git is a version control system that tracks changes in your code and lets you collaborate safely.",
  },
  {
    "explain git": "Git is a version control system that tracks changes in your code and lets you collaborate safely.",
  },
  {
    "define git": "Git is a version control system that tracks changes in your code and lets you collaborate safely.",
  },
  {
    "what is github": "GitHub is an online platform for hosting Git repositories and collaborating on code.",
  },
  {
    "explain github": "GitHub is an online platform for hosting Git repositories and collaborating on code.",
  },
  {
    "define github": "GitHub is an online platform for hosting Git repositories and collaborating on code.",
  },
  {
    "what is an api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "explain an api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "define an api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "what is api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "explain api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "define api": "An API (Application Programming Interface) lets different software programs talk to each other.",
  },
  {
    "what is json": "JSON (JavaScript Object Notation) is a lightweight text format for storing and exchanging data.",
  },
  {
    "explain json": "JSON (JavaScript Object Notation) is a lightweight text format for storing and exchanging data.",
  },
  {
    "define json": "JSON (JavaScript Object Notation) is a lightweight text format for storing and exchanging data.",
  },
  {
    "what is http": "HTTP (HyperText Transfer Protocol) is the set of rules browsers and servers use to exchange web content.",
  },
  {
    "explain http": "HTTP (HyperText Transfer Protocol) is the set of rules browsers and servers use to exchange web content.",
  },
  {
    "define http": "HTTP (HyperText Transfer Protocol) is the set of rules browsers and servers use to exchange web content.",
  },
  {
    "what is https": "HTTPS is HTTP with encryption, so data between your browser and a website stays private.",
  },
  {
    "explain https": "HTTPS is HTTP with encryption, so data between your browser and a website stays private.",
  },
  {
    "define https": "HTTPS is HTTP with encryption, so data between your browser and a website stays private.",
  },
  {
    "what is dns": "DNS (Domain Name System) translates names like example.com into IP addresses.",
  },
  {
    "explain dns": "DNS (Domain Name System) translates names like example.com into IP addresses.",
  },
  {
    "define dns": "DNS (Domain Name System) translates names like example.com into IP addresses.",
  },
  {
    "what is an ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "explain an ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "define an ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "what is ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "explain ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "define ip address": "An IP address is a unique number that identifies a device on a network.",
  },
  {
    "what is a url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "explain a url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "define a url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "what is url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "explain url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "define url": "A URL (Uniform Resource Locator) is the address of a resource on the web.",
  },
  {
    "what is a variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "explain a variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "define a variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "what is variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "explain variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "define variable": "A variable is a named container that stores a value in your program.",
  },
  {
    "what is a constant": "A constant is a named value that cannot be changed after it is set.",
  },
  {
    "explain a constant": "A constant is a named value that cannot be changed after it is set.",
  },
  {
    "define a constant": "A constant is a named value that cannot be changed after it is set.",
  },
  {
    "what is a function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "explain a function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "define a function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "what is function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "explain function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "define function": "A function is a reusable block of code that performs a specific task.",
  },
  {
    "what is an array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "explain an array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "define an array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "what is array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "explain array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "define array": "An array is an ordered list of values, such as [1, 2, 3].",
  },
  {
    "what is an object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "explain an object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "define an object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "what is object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "explain object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "define object": "An object stores related data as key-value pairs, such as { name: 'Ada', age: 30 }.",
  },
  {
    "what is a string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "explain a string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "define a string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "what is string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "explain string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "define string": "A string is text, like 'Hello', stored in a program.",
  },
  {
    "what is a boolean": "A boolean is a value that is either true or false.",
  },
  {
    "explain a boolean": "A boolean is a value that is either true or false.",
  },
  {
    "define a boolean": "A boolean is a value that is either true or false.",
  },
  {
    "what is boolean": "A boolean is a value that is either true or false.",
  },
  {
    "explain boolean": "A boolean is a value that is either true or false.",
  },
  {
    "define boolean": "A boolean is a value that is either true or false.",
  },
  {
    "what is an integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "explain an integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "define an integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "what is integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "explain integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "define integer": "An integer is a whole number with no decimal part, like 7 or -3.",
  },
  {
    "what is a loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "explain a loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "define a loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "what is loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "explain loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "define loop": "A loop repeats a block of code until a condition is met.",
  },
  {
    "what is a for loop": "A for loop repeats code a set number of times, using a counter.",
  },
  {
    "explain a for loop": "A for loop repeats code a set number of times, using a counter.",
  },
  {
    "define a for loop": "A for loop repeats code a set number of times, using a counter.",
  },
  {
    "what is a while loop": "A while loop repeats code as long as a condition stays true.",
  },
  {
    "explain a while loop": "A while loop repeats code as long as a condition stays true.",
  },
  {
    "define a while loop": "A while loop repeats code as long as a condition stays true.",
  },
  {
    "what is an if statement": "An if statement runs code only when a condition is true.",
  },
  {
    "explain an if statement": "An if statement runs code only when a condition is true.",
  },
  {
    "define an if statement": "An if statement runs code only when a condition is true.",
  },
  {
    "what is recursion": "Recursion is when a function calls itself to solve smaller versions of a problem.",
  },
  {
    "explain recursion": "Recursion is when a function calls itself to solve smaller versions of a problem.",
  },
  {
    "define recursion": "Recursion is when a function calls itself to solve smaller versions of a problem.",
  },
  {
    "what is a class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "explain a class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "define a class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "what is class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "explain class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "define class": "A class is a blueprint for creating objects with shared properties and methods.",
  },
  {
    "what is inheritance": "Inheritance lets one class reuse and extend the features of another class.",
  },
  {
    "explain inheritance": "Inheritance lets one class reuse and extend the features of another class.",
  },
  {
    "define inheritance": "Inheritance lets one class reuse and extend the features of another class.",
  },
  {
    "what is an algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "explain an algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "define an algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "what is algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "explain algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "define algorithm": "An algorithm is a step-by-step set of instructions to solve a problem.",
  },
  {
    "what is a data structure": "A data structure is a way of organizing data, like arrays, lists, stacks, queues, or trees.",
  },
  {
    "explain a data structure": "A data structure is a way of organizing data, like arrays, lists, stacks, queues, or trees.",
  },
  {
    "define a data structure": "A data structure is a way of organizing data, like arrays, lists, stacks, queues, or trees.",
  },
  {
    "what is a database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "explain a database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "define a database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "what is database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "explain database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "define database": "A database is an organized collection of data that can be stored, searched, and updated.",
  },
  {
    "what is a framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "explain a framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "define a framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "what is framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "explain framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "define framework": "A framework is a ready-made structure of code that helps you build apps faster.",
  },
  {
    "what is a library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "explain a library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "define a library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "what is library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "explain library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "define library": "A library is a collection of reusable code you can add to your project.",
  },
  {
    "what is npm": "npm (Node Package Manager) installs and manages JavaScript packages.",
  },
  {
    "explain npm": "npm (Node Package Manager) installs and manages JavaScript packages.",
  },
  {
    "define npm": "npm (Node Package Manager) installs and manages JavaScript packages.",
  },
  {
    "what is a terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "explain a terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "define a terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "what is terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "explain terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "define terminal": "A terminal is a text-based window where you type commands to control your computer.",
  },
  {
    "what is the command line": "The command line is a text interface for running commands instead of clicking.",
  },
  {
    "explain the command line": "The command line is a text interface for running commands instead of clicking.",
  },
  {
    "define the command line": "The command line is a text interface for running commands instead of clicking.",
  },
  {
    "what is powershell": "PowerShell is a Microsoft command-line shell and scripting language for automating tasks on Windows and other systems.",
  },
  {
    "explain powershell": "PowerShell is a Microsoft command-line shell and scripting language for automating tasks on Windows and other systems.",
  },
  {
    "define powershell": "PowerShell is a Microsoft command-line shell and scripting language for automating tasks on Windows and other systems.",
  },
  {
    "what is bash": "Bash is a popular command-line shell on Linux and macOS used for running commands and scripts.",
  },
  {
    "explain bash": "Bash is a popular command-line shell on Linux and macOS used for running commands and scripts.",
  },
  {
    "define bash": "Bash is a popular command-line shell on Linux and macOS used for running commands and scripts.",
  },
  {
    "what is linux": "Linux is a free, open-source operating system kernel used in servers, phones, and desktops.",
  },
  {
    "explain linux": "Linux is a free, open-source operating system kernel used in servers, phones, and desktops.",
  },
  {
    "define linux": "Linux is a free, open-source operating system kernel used in servers, phones, and desktops.",
  },
  {
    "what is windows": "Windows is Microsoft's operating system for personal computers.",
  },
  {
    "explain windows": "Windows is Microsoft's operating system for personal computers.",
  },
  {
    "define windows": "Windows is Microsoft's operating system for personal computers.",
  },
  {
    "what is an operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "explain an operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "define an operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "what is operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "explain operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "define operating system": "An operating system manages a computer's hardware and software, like Windows, macOS, Linux, or Android.",
  },
  {
    "what is a kernel": "The kernel is the core of an operating system that manages hardware, memory, and processes.",
  },
  {
    "explain a kernel": "The kernel is the core of an operating system that manages hardware, memory, and processes.",
  },
  {
    "define a kernel": "The kernel is the core of an operating system that manages hardware, memory, and processes.",
  },
  {
    "what is a compiler": "A compiler translates source code into machine code before the program runs.",
  },
  {
    "explain a compiler": "A compiler translates source code into machine code before the program runs.",
  },
  {
    "define a compiler": "A compiler translates source code into machine code before the program runs.",
  },
  {
    "what is an interpreter": "An interpreter reads and runs code line by line without compiling it first.",
  },
  {
    "explain an interpreter": "An interpreter reads and runs code line by line without compiling it first.",
  },
  {
    "define an interpreter": "An interpreter reads and runs code line by line without compiling it first.",
  },
  {
    "what is debugging": "Debugging is the process of finding and fixing errors in your code.",
  },
  {
    "explain debugging": "Debugging is the process of finding and fixing errors in your code.",
  },
  {
    "define debugging": "Debugging is the process of finding and fixing errors in your code.",
  },
  {
    "what is frontend": "Frontend is the part of a website or app that users see and interact with.",
  },
  {
    "explain frontend": "Frontend is the part of a website or app that users see and interact with.",
  },
  {
    "define frontend": "Frontend is the part of a website or app that users see and interact with.",
  },
  {
    "what is front end": "Front end is the part of a website or app that users see and interact with.",
  },
  {
    "explain front end": "Front end is the part of a website or app that users see and interact with.",
  },
  {
    "define front end": "Front end is the part of a website or app that users see and interact with.",
  },
  {
    "what is backend": "Backend is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "explain backend": "Backend is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "define backend": "Backend is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "what is back end": "Back end is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "explain back end": "Back end is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "define back end": "Back end is the server-side part of an app that handles data, logic, and databases.",
  },
  {
    "what is full stack": "A full-stack developer works on both the frontend and backend of an app.",
  },
  {
    "explain full stack": "A full-stack developer works on both the frontend and backend of an app.",
  },
  {
    "define full stack": "A full-stack developer works on both the frontend and backend of an app.",
  },
  {
    "what is devops": "DevOps combines development and operations practices to build, test, and release software faster and more reliably.",
  },
  {
    "explain devops": "DevOps combines development and operations practices to build, test, and release software faster and more reliably.",
  },
  {
    "define devops": "DevOps combines development and operations practices to build, test, and release software faster and more reliably.",
  },
  {
    "what is docker": "Docker packages apps and their dependencies into containers so they run the same everywhere.",
  },
  {
    "explain docker": "Docker packages apps and their dependencies into containers so they run the same everywhere.",
  },
  {
    "define docker": "Docker packages apps and their dependencies into containers so they run the same everywhere.",
  },
  {
    "what is cloud computing": "Cloud computing means using servers and services over the internet instead of your own hardware.",
  },
  {
    "explain cloud computing": "Cloud computing means using servers and services over the internet instead of your own hardware.",
  },
  {
    "define cloud computing": "Cloud computing means using servers and services over the internet instead of your own hardware.",
  },
  {
    "what is a server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "explain a server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "define a server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "what is server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "explain server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "define server": "A server is a computer or program that provides data or services to other computers.",
  },
  {
    "what is a client": "A client is a device or program that requests services from a server.",
  },
  {
    "explain a client": "A client is a device or program that requests services from a server.",
  },
  {
    "define a client": "A client is a device or program that requests services from a server.",
  },
  {
    "what is a browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "explain a browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "define a browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "what is browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "explain browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "define browser": "A browser is software like Chrome, Firefox, or Safari that loads and displays web pages.",
  },
  {
    "what is a cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "explain a cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "define a cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "what is cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "explain cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "define cookie": "A cookie is a small piece of data a website stores in your browser to remember you.",
  },
  {
    "what is a cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "explain a cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "define a cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "what is cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "explain cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "define cache": "A cache stores copies of data so it can be accessed faster next time.",
  },
  {
    "what is localstorage": "localStorage is a browser feature that lets you store small amounts of data that persist after the page is closed.",
  },
  {
    "explain localstorage": "localStorage is a browser feature that lets you store small amounts of data that persist after the page is closed.",
  },
  {
    "define localstorage": "localStorage is a browser feature that lets you store small amounts of data that persist after the page is closed.",
  },
  {
    "what is the dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "explain the dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "define the dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "what is dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "explain dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "define dom": "The DOM (Document Object Model) is the browser's tree-like representation of a web page that JavaScript can change.",
  },
  {
    "what is an event listener": "An event listener waits for something like a click or key press, then runs a function.",
  },
  {
    "explain an event listener": "An event listener waits for something like a click or key press, then runs a function.",
  },
  {
    "define an event listener": "An event listener waits for something like a click or key press, then runs a function.",
  },
  {
    "what is a callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "explain a callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "define a callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "what is callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "explain callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "define callback": "A callback is a function passed into another function to be run later.",
  },
  {
    "what is a promise": "A promise represents a value that will be available in the future, such as data from a network request.",
  },
  {
    "explain a promise": "A promise represents a value that will be available in the future, such as data from a network request.",
  },
  {
    "define a promise": "A promise represents a value that will be available in the future, such as data from a network request.",
  },
  {
    "what is async await": "async/await is a cleaner way to write code that waits for promises to finish.",
  },
  {
    "explain async await": "async/await is a cleaner way to write code that waits for promises to finish.",
  },
  {
    "define async await": "async/await is a cleaner way to write code that waits for promises to finish.",
  },
  {
    "what is a closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "explain a closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "define a closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "what is closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "explain closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "define closure": "A closure is a function that remembers the variables from the place where it was created.",
  },
  {
    "what is hoisting": "Hoisting is JavaScript's behavior of moving declarations to the top of their scope before the code runs.",
  },
  {
    "explain hoisting": "Hoisting is JavaScript's behavior of moving declarations to the top of their scope before the code runs.",
  },
  {
    "define hoisting": "Hoisting is JavaScript's behavior of moving declarations to the top of their scope before the code runs.",
  },
  {
    "what is an arrow function": "An arrow function is a shorter way to write a function in JavaScript, like (a, b) => a + b.",
  },
  {
    "explain an arrow function": "An arrow function is a shorter way to write a function in JavaScript, like (a, b) => a + b.",
  },
  {
    "define an arrow function": "An arrow function is a shorter way to write a function in JavaScript, like (a, b) => a + b.",
  },
  {
    "what is typescript": "TypeScript is JavaScript with types, which helps catch errors before your code runs.",
  },
  {
    "explain typescript": "TypeScript is JavaScript with types, which helps catch errors before your code runs.",
  },
  {
    "define typescript": "TypeScript is JavaScript with types, which helps catch errors before your code runs.",
  },
  {
    "what is vite": "Vite is a fast build tool and dev server for modern web projects.",
  },
  {
    "explain vite": "Vite is a fast build tool and dev server for modern web projects.",
  },
  {
    "define vite": "Vite is a fast build tool and dev server for modern web projects.",
  },
  {
    "what is webpack": "Webpack is a tool that bundles JavaScript files and assets for the browser.",
  },
  {
    "explain webpack": "Webpack is a tool that bundles JavaScript files and assets for the browser.",
  },
  {
    "define webpack": "Webpack is a tool that bundles JavaScript files and assets for the browser.",
  },
  {
    "what is a component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "explain a component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "define a component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "what is component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "explain component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "define component": "A component is a reusable piece of UI, like a button or a chat bubble.",
  },
  {
    "what is props": "Props are inputs passed from a parent component to a child component in React.",
  },
  {
    "explain props": "Props are inputs passed from a parent component to a child component in React.",
  },
  {
    "define props": "Props are inputs passed from a parent component to a child component in React.",
  },
  {
    "what is state": "State is data in a component that can change over time and cause the UI to update.",
  },
  {
    "explain state": "State is data in a component that can change over time and cause the UI to update.",
  },
  {
    "define state": "State is data in a component that can change over time and cause the UI to update.",
  },
  {
    "what is usestate": "useState is a React hook that lets a component store and update a piece of state.",
  },
  {
    "explain usestate": "useState is a React hook that lets a component store and update a piece of state.",
  },
  {
    "define usestate": "useState is a React hook that lets a component store and update a piece of state.",
  },
  {
    "what is useeffect": "useEffect is a React hook for running side effects, like fetching data, after a component renders.",
  },
  {
    "explain useeffect": "useEffect is a React hook for running side effects, like fetching data, after a component renders.",
  },
  {
    "define useeffect": "useEffect is a React hook for running side effects, like fetching data, after a component renders.",
  },
  {
    "what is a hook": "A hook is a special React function, like useState or useEffect, that lets components use features such as state.",
  },
  {
    "explain a hook": "A hook is a special React function, like useState or useEffect, that lets components use features such as state.",
  },
  {
    "define a hook": "A hook is a special React function, like useState or useEffect, that lets components use features such as state.",
  },
  {
    "what is jsx": "JSX is a syntax extension that lets you write HTML-like code inside JavaScript.",
  },
  {
    "explain jsx": "JSX is a syntax extension that lets you write HTML-like code inside JavaScript.",
  },
  {
    "define jsx": "JSX is a syntax extension that lets you write HTML-like code inside JavaScript.",
  },
  {
    "what is redux": "Redux is a library for managing application state in one central place.",
  },
  {
    "explain redux": "Redux is a library for managing application state in one central place.",
  },
  {
    "define redux": "Redux is a library for managing application state in one central place.",
  },
  {
    "what is a rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "explain a rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "define a rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "what is rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "explain rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "define rest api": "A REST API uses standard HTTP methods like GET and POST to let clients work with resources on a server.",
  },
  {
    "what is graphql": "GraphQL is a query language for APIs that lets clients ask for exactly the data they need.",
  },
  {
    "explain graphql": "GraphQL is a query language for APIs that lets clients ask for exactly the data they need.",
  },
  {
    "define graphql": "GraphQL is a query language for APIs that lets clients ask for exactly the data they need.",
  },
  {
    "what is mongodb": "MongoDB is a NoSQL database that stores data as flexible, JSON-like documents.",
  },
  {
    "explain mongodb": "MongoDB is a NoSQL database that stores data as flexible, JSON-like documents.",
  },
  {
    "define mongodb": "MongoDB is a NoSQL database that stores data as flexible, JSON-like documents.",
  },
  {
    "what is mysql": "MySQL is a popular open-source relational database.",
  },
  {
    "explain mysql": "MySQL is a popular open-source relational database.",
  },
  {
    "define mysql": "MySQL is a popular open-source relational database.",
  },
  {
    "what is firebase": "Firebase is a Google platform offering databases, authentication, and hosting for apps.",
  },
  {
    "explain firebase": "Firebase is a Google platform offering databases, authentication, and hosting for apps.",
  },
  {
    "define firebase": "Firebase is a Google platform offering databases, authentication, and hosting for apps.",
  },
  {
    "what is open source": "Open source software has publicly available code that anyone can view, use, and improve.",
  },
  {
    "explain open source": "Open source software has publicly available code that anyone can view, use, and improve.",
  },
  {
    "define open source": "Open source software has publicly available code that anyone can view, use, and improve.",
  },
  {
    "what is version control": "Version control tracks changes to your files over time so you can revert and collaborate.",
  },
  {
    "explain version control": "Version control tracks changes to your files over time so you can revert and collaborate.",
  },
  {
    "define version control": "Version control tracks changes to your files over time so you can revert and collaborate.",
  },
  {
    "what is a branch": "A branch in Git is a separate line of development, so you can work without affecting the main code.",
  },
  {
    "explain a branch": "A branch in Git is a separate line of development, so you can work without affecting the main code.",
  },
  {
    "define a branch": "A branch in Git is a separate line of development, so you can work without affecting the main code.",
  },
  {
    "what is a commit": "A commit is a saved snapshot of your changes in Git.",
  },
  {
    "explain a commit": "A commit is a saved snapshot of your changes in Git.",
  },
  {
    "define a commit": "A commit is a saved snapshot of your changes in Git.",
  },
  {
    "what is a pull request": "A pull request asks the maintainers to review and merge your changes into a project.",
  },
  {
    "explain a pull request": "A pull request asks the maintainers to review and merge your changes into a project.",
  },
  {
    "define a pull request": "A pull request asks the maintainers to review and merge your changes into a project.",
  },
  {
    "what is a merge conflict": "A merge conflict happens when Git can't automatically combine changes to the same lines of code.",
  },
  {
    "explain a merge conflict": "A merge conflict happens when Git can't automatically combine changes to the same lines of code.",
  },
  {
    "define a merge conflict": "A merge conflict happens when Git can't automatically combine changes to the same lines of code.",
  },
  {
    "what is an ide": "An IDE (Integrated Development Environment) is a tool that combines a code editor, debugger, and more.",
  },
  {
    "explain an ide": "An IDE (Integrated Development Environment) is a tool that combines a code editor, debugger, and more.",
  },
  {
    "define an ide": "An IDE (Integrated Development Environment) is a tool that combines a code editor, debugger, and more.",
  },
  {
    "what is vs code": "VS Code is a free, popular code editor from Microsoft with lots of extensions.",
  },
  {
    "explain vs code": "VS Code is a free, popular code editor from Microsoft with lots of extensions.",
  },
  {
    "define vs code": "VS Code is a free, popular code editor from Microsoft with lots of extensions.",
  },
  {
    "what is ai": "AI (artificial intelligence) is software that can perform tasks that normally need human intelligence, like understanding language or recognizing images.",
  },
  {
    "explain ai": "AI (artificial intelligence) is software that can perform tasks that normally need human intelligence, like understanding language or recognizing images.",
  },
  {
    "define ai": "AI (artificial intelligence) is software that can perform tasks that normally need human intelligence, like understanding language or recognizing images.",
  },
  {
    "what is machine learning": "Machine learning is a way for computers to learn patterns from data instead of being explicitly programmed.",
  },
  {
    "explain machine learning": "Machine learning is a way for computers to learn patterns from data instead of being explicitly programmed.",
  },
  {
    "define machine learning": "Machine learning is a way for computers to learn patterns from data instead of being explicitly programmed.",
  },
  {
    "what is deep learning": "Deep learning is a type of machine learning that uses many-layered neural networks.",
  },
  {
    "explain deep learning": "Deep learning is a type of machine learning that uses many-layered neural networks.",
  },
  {
    "define deep learning": "Deep learning is a type of machine learning that uses many-layered neural networks.",
  },
  {
    "what is a neural network": "A neural network is a computing model loosely inspired by the brain, made of connected layers of nodes.",
  },
  {
    "explain a neural network": "A neural network is a computing model loosely inspired by the brain, made of connected layers of nodes.",
  },
  {
    "define a neural network": "A neural network is a computing model loosely inspired by the brain, made of connected layers of nodes.",
  },
  {
    "what is a chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "explain a chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "define a chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "what is chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "explain chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "define chatbot": "A chatbot is a program that holds a conversation with people, like me!",
  },
  {
    "what is an llm": "An LLM (large language model) is an AI trained on huge amounts of text to understand and generate language.",
  },
  {
    "explain an llm": "An LLM (large language model) is an AI trained on huge amounts of text to understand and generate language.",
  },
  {
    "define an llm": "An LLM (large language model) is an AI trained on huge amounts of text to understand and generate language.",
  },
  {
    "what is cybersecurity": "Cybersecurity is the practice of protecting systems, networks, and data from attacks.",
  },
  {
    "explain cybersecurity": "Cybersecurity is the practice of protecting systems, networks, and data from attacks.",
  },
  {
    "define cybersecurity": "Cybersecurity is the practice of protecting systems, networks, and data from attacks.",
  },
  {
    "what is a firewall": "A firewall monitors and filters network traffic to block unauthorized access.",
  },
  {
    "explain a firewall": "A firewall monitors and filters network traffic to block unauthorized access.",
  },
  {
    "define a firewall": "A firewall monitors and filters network traffic to block unauthorized access.",
  },
  {
    "what is a vpn": "A VPN (Virtual Private Network) encrypts your internet connection and hides your IP address.",
  },
  {
    "explain a vpn": "A VPN (Virtual Private Network) encrypts your internet connection and hides your IP address.",
  },
  {
    "define a vpn": "A VPN (Virtual Private Network) encrypts your internet connection and hides your IP address.",
  },
  {
    "what is malware": "Malware is malicious software, such as viruses or spyware, designed to harm or exploit systems.",
  },
  {
    "explain malware": "Malware is malicious software, such as viruses or spyware, designed to harm or exploit systems.",
  },
  {
    "define malware": "Malware is malicious software, such as viruses or spyware, designed to harm or exploit systems.",
  },
  {
    "what is phishing": "Phishing is a scam where attackers pretend to be trustworthy to trick you into giving up passwords or money.",
  },
  {
    "explain phishing": "Phishing is a scam where attackers pretend to be trustworthy to trick you into giving up passwords or money.",
  },
  {
    "define phishing": "Phishing is a scam where attackers pretend to be trustworthy to trick you into giving up passwords or money.",
  },
  {
    "what is encryption": "Encryption scrambles data so only someone with the right key can read it.",
  },
  {
    "explain encryption": "Encryption scrambles data so only someone with the right key can read it.",
  },
  {
    "define encryption": "Encryption scrambles data so only someone with the right key can read it.",
  },
  {
    "what is a password manager": "A password manager stores and fills in strong, unique passwords for all your accounts.",
  },
  {
    "explain a password manager": "A password manager stores and fills in strong, unique passwords for all your accounts.",
  },
  {
    "define a password manager": "A password manager stores and fills in strong, unique passwords for all your accounts.",
  },
  {
    "what is two factor authentication": "Two-factor authentication adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "explain two factor authentication": "Two-factor authentication adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "define two factor authentication": "Two-factor authentication adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "what is 2fa": "2FA (two-factor authentication) adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "explain 2fa": "2FA (two-factor authentication) adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "define 2fa": "2FA (two-factor authentication) adds a second proof of identity, like a code on your phone, on top of your password.",
  },
  {
    "what is ransomware": "Ransomware is malware that locks your files and demands payment to unlock them.",
  },
  {
    "explain ransomware": "Ransomware is malware that locks your files and demands payment to unlock them.",
  },
  {
    "define ransomware": "Ransomware is malware that locks your files and demands payment to unlock them.",
  },
  {
    "what is bandwidth": "Bandwidth is the maximum amount of data that can be transferred over a connection in a given time.",
  },
  {
    "explain bandwidth": "Bandwidth is the maximum amount of data that can be transferred over a connection in a given time.",
  },
  {
    "define bandwidth": "Bandwidth is the maximum amount of data that can be transferred over a connection in a given time.",
  },
  {
    "what is ram": "RAM (Random Access Memory) is the computer's short-term memory for running programs.",
  },
  {
    "explain ram": "RAM (Random Access Memory) is the computer's short-term memory for running programs.",
  },
  {
    "define ram": "RAM (Random Access Memory) is the computer's short-term memory for running programs.",
  },
  {
    "what is a cpu": "The CPU (Central Processing Unit) is the brain of the computer that executes instructions.",
  },
  {
    "explain a cpu": "The CPU (Central Processing Unit) is the brain of the computer that executes instructions.",
  },
  {
    "define a cpu": "The CPU (Central Processing Unit) is the brain of the computer that executes instructions.",
  },
  {
    "what is a gpu": "A GPU (Graphics Processing Unit) is specialized hardware for rendering graphics and parallel computations.",
  },
  {
    "explain a gpu": "A GPU (Graphics Processing Unit) is specialized hardware for rendering graphics and parallel computations.",
  },
  {
    "define a gpu": "A GPU (Graphics Processing Unit) is specialized hardware for rendering graphics and parallel computations.",
  },
  {
    "what is an ssd": "An SSD (Solid State Drive) stores data on flash memory and is much faster than a traditional hard drive.",
  },
  {
    "explain an ssd": "An SSD (Solid State Drive) stores data on flash memory and is much faster than a traditional hard drive.",
  },
  {
    "define an ssd": "An SSD (Solid State Drive) stores data on flash memory and is much faster than a traditional hard drive.",
  },
  {
    "what is wifi": "Wi-Fi is wireless networking technology that connects devices to the internet through a router.",
  },
  {
    "explain wifi": "Wi-Fi is wireless networking technology that connects devices to the internet through a router.",
  },
  {
    "define wifi": "Wi-Fi is wireless networking technology that connects devices to the internet through a router.",
  },
  {
    "what is bluetooth": "Bluetooth is a short-range wireless technology for connecting devices like headphones.",
  },
  {
    "explain bluetooth": "Bluetooth is a short-range wireless technology for connecting devices like headphones.",
  },
  {
    "define bluetooth": "Bluetooth is a short-range wireless technology for connecting devices like headphones.",
  },
  {
    "what is binary": "Binary is a number system with only two digits, 0 and 1, used by computers.",
  },
  {
    "explain binary": "Binary is a number system with only two digits, 0 and 1, used by computers.",
  },
  {
    "define binary": "Binary is a number system with only two digits, 0 and 1, used by computers.",
  },
  {
    "what is a bit": "A bit is the smallest unit of data in computing: a 0 or a 1.",
  },
  {
    "explain a bit": "A bit is the smallest unit of data in computing: a 0 or a 1.",
  },
  {
    "define a bit": "A bit is the smallest unit of data in computing: a 0 or a 1.",
  },
  {
    "what is a byte": "A byte is 8 bits, enough to store a single character.",
  },
  {
    "explain a byte": "A byte is 8 bits, enough to store a single character.",
  },
  {
    "define a byte": "A byte is 8 bits, enough to store a single character.",
  },
  {
    "what is a pixel": "A pixel is the smallest dot of color on a screen.",
  },
  {
    "explain a pixel": "A pixel is the smallest dot of color on a screen.",
  },
  {
    "define a pixel": "A pixel is the smallest dot of color on a screen.",
  },
  {
    "what is an emoji": "An emoji is a small digital picture used to express emotion or ideas.",
  },
  {
    "explain an emoji": "An emoji is a small digital picture used to express emotion or ideas.",
  },
  {
    "define an emoji": "An emoji is a small digital picture used to express emotion or ideas.",
  },
  {
    "what is a bug report": "A bug report describes a problem in software, what you expected, and the steps to reproduce it.",
  },
  {
    "explain a bug report": "A bug report describes a problem in software, what you expected, and the steps to reproduce it.",
  },
  {
    "define a bug report": "A bug report describes a problem in software, what you expected, and the steps to reproduce it.",
  },
  {
    "what is a repository": "A repository (repo) is where a project's code and history are stored.",
  },
  {
    "explain a repository": "A repository (repo) is where a project's code and history are stored.",
  },
  {
    "define a repository": "A repository (repo) is where a project's code and history are stored.",
  },
  {
    "what is a framework vs library": "A library is code you call when you want to; a framework calls your code and sets the structure of your app.",
  },
  {
    "explain a framework vs library": "A library is code you call when you want to; a framework calls your code and sets the structure of your app.",
  },
  {
    "define a framework vs library": "A library is code you call when you want to; a framework calls your code and sets the structure of your app.",
  },
  {
    "what is semantic html": "Semantic HTML uses meaningful tags like header, nav, and footer to describe the purpose of content.",
  },
  {
    "explain semantic html": "Semantic HTML uses meaningful tags like header, nav, and footer to describe the purpose of content.",
  },
  {
    "define semantic html": "Semantic HTML uses meaningful tags like header, nav, and footer to describe the purpose of content.",
  },
  {
    "what is responsive design": "Responsive design makes a website look good on all screen sizes, from phones to desktops.",
  },
  {
    "explain responsive design": "Responsive design makes a website look good on all screen sizes, from phones to desktops.",
  },
  {
    "define responsive design": "Responsive design makes a website look good on all screen sizes, from phones to desktops.",
  },
  {
    "what is flexbox": "Flexbox is a CSS layout system for arranging items in rows or columns with flexible sizing.",
  },
  {
    "explain flexbox": "Flexbox is a CSS layout system for arranging items in rows or columns with flexible sizing.",
  },
  {
    "define flexbox": "Flexbox is a CSS layout system for arranging items in rows or columns with flexible sizing.",
  },
  {
    "what is css grid": "CSS Grid is a layout system for arranging content in rows and columns.",
  },
  {
    "explain css grid": "CSS Grid is a layout system for arranging content in rows and columns.",
  },
  {
    "define css grid": "CSS Grid is a layout system for arranging content in rows and columns.",
  },
  {
    "what is a media query": "A media query applies CSS only when certain conditions, such as screen width, are met.",
  },
  {
    "explain a media query": "A media query applies CSS only when certain conditions, such as screen width, are met.",
  },
  {
    "define a media query": "A media query applies CSS only when certain conditions, such as screen width, are met.",
  },
  {
    "what is a modal": "A modal is a pop-up window that appears over the page and requires the user's attention.",
  },
  {
    "explain a modal": "A modal is a pop-up window that appears over the page and requires the user's attention.",
  },
  {
    "define a modal": "A modal is a pop-up window that appears over the page and requires the user's attention.",
  },
  {
    "what is a spa": "A single-page app (SPA) loads one HTML page and updates content dynamically without full page reloads.",
  },
  {
    "explain a spa": "A single-page app (SPA) loads one HTML page and updates content dynamically without full page reloads.",
  },
  {
    "define a spa": "A single-page app (SPA) loads one HTML page and updates content dynamically without full page reloads.",
  },
  {
    "what is an sdk": "An SDK (Software Development Kit) is a bundle of tools and libraries for building software for a platform.",
  },
  {
    "explain an sdk": "An SDK (Software Development Kit) is a bundle of tools and libraries for building software for a platform.",
  },
  {
    "define an sdk": "An SDK (Software Development Kit) is a bundle of tools and libraries for building software for a platform.",
  },
  {
    "what is authentication": "Authentication is verifying who a user is, such as with a password.",
  },
  {
    "explain authentication": "Authentication is verifying who a user is, such as with a password.",
  },
  {
    "define authentication": "Authentication is verifying who a user is, such as with a password.",
  },
  {
    "what is authorization": "Authorization decides what an authenticated user is allowed to do.",
  },
  {
    "explain authorization": "Authorization decides what an authenticated user is allowed to do.",
  },
  {
    "define authorization": "Authorization decides what an authenticated user is allowed to do.",
  },
  {
    "what is a token": "A token is a small piece of data used to prove identity or permission, like a login token.",
  },
  {
    "explain a token": "A token is a small piece of data used to prove identity or permission, like a login token.",
  },
  {
    "define a token": "A token is a small piece of data used to prove identity or permission, like a login token.",
  },
  {
    "what is a hash": "A hash is a fixed-length value produced from data by a hash function, often used to store passwords safely.",
  },
  {
    "explain a hash": "A hash is a fixed-length value produced from data by a hash function, often used to store passwords safely.",
  },
  {
    "define a hash": "A hash is a fixed-length value produced from data by a hash function, often used to store passwords safely.",
  },
  {
    "what is open ai": "OpenAI is an AI research company that created models like GPT.",
  },
  {
    "explain open ai": "OpenAI is an AI research company that created models like GPT.",
  },
  {
    "define open ai": "OpenAI is an AI research company that created models like GPT.",
  },
  {
    "what is anthropic": "Anthropic is an AI safety company that created Claude.",
  },
  {
    "explain anthropic": "Anthropic is an AI safety company that created Claude.",
  },
  {
    "define anthropic": "Anthropic is an AI safety company that created Claude.",
  },
  {
    "what does html stand for": "HTML stands for HyperText Markup Language.",
  },
  {
    "what is the full meaning of html": "HTML stands for HyperText Markup Language.",
  },
  {
    "what does css stand for": "CSS stands for Cascading Style Sheets.",
  },
  {
    "what is the full meaning of css": "CSS stands for Cascading Style Sheets.",
  },
  {
    "what does http stand for": "HTTP stands for HyperText Transfer Protocol.",
  },
  {
    "what is the full meaning of http": "HTTP stands for HyperText Transfer Protocol.",
  },
  {
    "what does url stand for": "URL stands for Uniform Resource Locator.",
  },
  {
    "what is the full meaning of url": "URL stands for Uniform Resource Locator.",
  },
  {
    "what does api stand for": "API stands for Application Programming Interface.",
  },
  {
    "what is the full meaning of api": "API stands for Application Programming Interface.",
  },
  {
    "what does sql stand for": "SQL stands for Structured Query Language.",
  },
  {
    "what is the full meaning of sql": "SQL stands for Structured Query Language.",
  },
  {
    "what does ai stand for": "AI stands for artificial intelligence.",
  },
  {
    "what is the full meaning of ai": "AI stands for artificial intelligence.",
  },
  {
    "what does cpu stand for": "CPU stands for Central Processing Unit.",
  },
  {
    "what is the full meaning of cpu": "CPU stands for Central Processing Unit.",
  },
  {
    "what does ram stand for": "RAM stands for Random Access Memory.",
  },
  {
    "what is the full meaning of ram": "RAM stands for Random Access Memory.",
  },
  {
    "what does usb stand for": "USB stands for Universal Serial Bus.",
  },
  {
    "what is the full meaning of usb": "USB stands for Universal Serial Bus.",
  },
  {
    "what does pdf stand for": "PDF stands for Portable Document Format.",
  },
  {
    "what is the full meaning of pdf": "PDF stands for Portable Document Format.",
  },
  {
    "what does gps stand for": "GPS stands for Global Positioning System.",
  },
  {
    "what is the full meaning of gps": "GPS stands for Global Positioning System.",
  },
  {
    "what does dom stand for": "DOM stands for Document Object Model.",
  },
  {
    "what is the full meaning of dom": "DOM stands for Document Object Model.",
  },
  {
    "what does json stand for": "JSON stands for JavaScript Object Notation.",
  },
  {
    "what is the full meaning of json": "JSON stands for JavaScript Object Notation.",
  },
  {
    "what does ide stand for": "IDE stands for Integrated Development Environment.",
  },
  {
    "what is the full meaning of ide": "IDE stands for Integrated Development Environment.",
  },
  {
    "what does vpn stand for": "VPN stands for Virtual Private Network.",
  },
  {
    "what is the full meaning of vpn": "VPN stands for Virtual Private Network.",
  },
  {
    "what does dns stand for": "DNS stands for Domain Name System.",
  },
  {
    "what is the full meaning of dns": "DNS stands for Domain Name System.",
  },
  {
    "what does npm stand for": "npm stands for Node Package Manager.",
  },
  {
    "what is the full meaning of npm": "npm stands for Node Package Manager.",
  },
  {
    "what does ui stand for": "UI stands for User Interface.",
  },
  {
    "what is the full meaning of ui": "UI stands for User Interface.",
  },
  {
    "what does ux stand for": "UX stands for User Experience.",
  },
  {
    "what is the full meaning of ux": "UX stands for User Experience.",
  },
  {
    "what does cms stand for": "CMS stands for Content Management System.",
  },
  {
    "what is the full meaning of cms": "CMS stands for Content Management System.",
  },
  {
    "what does seo stand for": "SEO stands for Search Engine Optimization.",
  },
  {
    "what is the full meaning of seo": "SEO stands for Search Engine Optimization.",
  },
  {
    "what does atm stand for": "ATM stands for Automated Teller Machine.",
  },
  {
    "what is the full meaning of atm": "ATM stands for Automated Teller Machine.",
  },
  {
    "what does nasa stand for": "NASA stands for National Aeronautics and Space Administration.",
  },
  {
    "what is the full meaning of nasa": "NASA stands for National Aeronautics and Space Administration.",
  },
  {
    "what does wifi stand for": "Wi-Fi is a brand name and doesn't officially stand for anything.",
  },
  {
    "what is the full meaning of wifi": "Wi-Fi is a brand name and doesn't officially stand for anything.",
  },
  {
    "what does lol stand for": "LOL stands for 'laughing out loud'.",
  },
  {
    "what is the full meaning of lol": "LOL stands for 'laughing out loud'.",
  },
  {
    "what does brb stand for": "BRB stands for 'be right back'.",
  },
  {
    "what is the full meaning of brb": "BRB stands for 'be right back'.",
  },
  {
    "what does omg stand for": "OMG stands for 'oh my God'.",
  },
  {
    "what is the full meaning of omg": "OMG stands for 'oh my God'.",
  },
  {
    "what does idk stand for": "IDK stands for 'I don't know'.",
  },
  {
    "what is the full meaning of idk": "IDK stands for 'I don't know'.",
  },
  {
    "what does asap stand for": "ASAP stands for 'as soon as possible'.",
  },
  {
    "what is the full meaning of asap": "ASAP stands for 'as soon as possible'.",
  },
  {
    "what does fyi stand for": "FYI stands for 'for your information'.",
  },
  {
    "what is the full meaning of fyi": "FYI stands for 'for your information'.",
  },
  {
    "what does btw stand for": "BTW stands for 'by the way'.",
  },
  {
    "what is the full meaning of btw": "BTW stands for 'by the way'.",
  },
  {
    "what does imo stand for": "IMO stands for 'in my opinion'.",
  },
  {
    "what is the full meaning of imo": "IMO stands for 'in my opinion'.",
  },
  {
    "what does tbh stand for": "TBH stands for 'to be honest'.",
  },
  {
    "what is the full meaning of tbh": "TBH stands for 'to be honest'.",
  },
  {
    "who wrote romeo and juliet": "William Shakespeare wrote Romeo and Juliet.",
  },
  {
    "who painted the mona lisa": "Leonardo da Vinci painted the Mona Lisa.",
  },
  {
    "who discovered gravity": "Isaac Newton formulated the law of universal gravitation.",
  },
  {
    "who invented the telephone": "Alexander Graham Bell is credited with the telephone, patented in 1876.",
  },
  {
    "who invented the light bulb": "Thomas Edison developed a practical light bulb, building on the work of many inventors.",
  },
  {
    "who was the first president of nigeria": "Nnamdi Azikiwe was Nigeria's first President.",
  },
  {
    "who was the first prime minister of nigeria": "Abubakar Tafawa Balewa was Nigeria's first Prime Minister.",
  },
  {
    "when did nigeria gain independence": "Nigeria gained independence from Britain on 1 October 1960.",
  },
  {
    "who was the first man on the moon": "Neil Armstrong, in July 1969.",
  },
  {
    "who wrote things fall apart": "Chinua Achebe wrote Things Fall Apart, published in 1958.",
  },
  {
    "how many continents are there": "There are seven continents.",
  },
  {
    "how many oceans are there": "There are five oceans: Pacific, Atlantic, Indian, Southern, and Arctic.",
  },
  {
    "what is the largest ocean": "The Pacific Ocean is the largest.",
  },
  {
    "what is the longest river in the world": "The Nile and the Amazon are the top contenders. The Nile is traditionally listed as the longest at about 6,650 km.",
  },
  {
    "what is the tallest mountain in the world": "Mount Everest, at about 8,849 meters above sea level.",
  },
  {
    "what is the largest country in the world": "Russia is the largest country by area.",
  },
  {
    "what is the smallest country in the world": "Vatican City is the smallest country.",
  },
  {
    "what is the largest desert in the world": "Antarctica is the largest desert overall. The Sahara is the largest hot desert.",
  },
  {
    "what is the largest animal": "The blue whale is the largest animal.",
  },
  {
    "what is the fastest land animal": "The cheetah, reaching around 100 km/h.",
  },
  {
    "how many bones are in the human body": "An adult human has 206 bones.",
  },
  {
    "how many teeth do adults have": "Adults usually have 32 teeth, including wisdom teeth.",
  },
  {
    "what is the largest organ in the human body": "The skin is the largest organ.",
  },
  {
    "what is the speed of light": "About 299,792 kilometers per second.",
  },
  {
    "what is the boiling point of water": "100°C (212°F) at sea level.",
  },
  {
    "what is the freezing point of water": "0°C (32°F).",
  },
  {
    "what gas do plants absorb": "Plants absorb carbon dioxide and release oxygen during photosynthesis.",
  },
  {
    "what gas do we breathe": "We breathe oxygen. Air is about 78% nitrogen and 21% oxygen.",
  },
  {
    "what is the hardest natural substance": "Diamond is the hardest natural substance.",
  },
  {
    "what is the chemical formula for water": "H2O.",
  },
  {
    "what is the chemical formula for salt": "NaCl, sodium chloride.",
  },
  {
    "what is pi": "Pi is approximately 3.14159. It's the ratio of a circle's circumference to its diameter.",
  },
  {
    "how many days are in a year": "365 days, or 366 in a leap year.",
  },
  {
    "how many seconds are in a minute": "60 seconds.",
  },
  {
    "how many minutes are in an hour": "60 minutes.",
  },
  {
    "how many hours are in a day": "24 hours.",
  },
  {
    "how many days are in a week": "7 days.",
  },
  {
    "how many weeks are in a year": "52 weeks.",
  },
  {
    "how many months are in a year": "12 months.",
  },
  {
    "how many seconds are in an hour": "3,600 seconds.",
  },
  {
    "how many seconds are in a day": "86,400 seconds.",
  },
  {
    "how many sides does a triangle have": "A triangle has 3 sides.",
  },
  {
    "how many sides does a square have": "A square has 4 sides.",
  },
  {
    "how many sides does a pentagon have": "A pentagon has 5 sides.",
  },
  {
    "how many sides does a hexagon have": "A hexagon has 6 sides.",
  },
  {
    "how many sides does a heptagon have": "A heptagon has 7 sides.",
  },
  {
    "how many sides does an octagon have": "An octagon has 8 sides.",
  },
  {
    "how many sides does a nonagon have": "A nonagon has 9 sides.",
  },
  {
    "how many sides does a decagon have": "A decagon has 10 sides.",
  },
  {
    "what is the currency of nigeria": "The Nigerian naira (NGN).",
  },
  {
    "what is the currency of ghana": "The Ghanaian cedi (GHS).",
  },
  {
    "what is the currency of kenya": "The Kenyan shilling (KES).",
  },
  {
    "what is the currency of south africa": "The South African rand (ZAR).",
  },
  {
    "what is the currency of the united states": "The US dollar (USD).",
  },
  {
    "what is the currency of the united kingdom": "The pound sterling (GBP).",
  },
  {
    "what is the currency of japan": "The Japanese yen (JPY).",
  },
  {
    "what is the currency of india": "The Indian rupee (INR).",
  },
  {
    "what is the currency of china": "The Chinese yuan, also called the renminbi (CNY).",
  },
  {
    "what is the currency of canada": "The Canadian dollar (CAD).",
  },
  {
    "what is the currency of australia": "The Australian dollar (AUD).",
  },
  {
    "what is the currency of brazil": "The Brazilian real (BRL).",
  },
  {
    "what is the currency of russia": "The Russian ruble (RUB).",
  },
  {
    "what is the currency of switzerland": "The Swiss franc (CHF).",
  },
  {
    "what is the currency of egypt": "The Egyptian pound (EGP).",
  },
  {
    "what is the currency of saudi arabia": "The Saudi riyal (SAR).",
  },
  {
    "what is the currency of the uae": "The UAE dirham (AED).",
  },
  {
    "what is the currency of mexico": "The Mexican peso (MXN).",
  },
  {
    "what is the currency of turkey": "The Turkish lira (TRY).",
  },
  {
    "what is the currency of europe": "The euro (EUR) is used by most European Union countries.",
  },
  {
    "what languages are spoken in nigeria": "English is the official language. Major languages include Hausa, Yoruba, and Igbo, and there are hundreds more.",
  },
  {
    "what is the largest city in nigeria": "Lagos is Nigeria's largest city.",
  },
  {
    "what is the longest river in nigeria": "The River Niger is the longest river in Nigeria.",
  },
  {
    "what are the colors of the nigerian flag": "Green, white, green: two green vertical bands with a white band in the middle.",
  },
  {
    "how many states are in nigeria": "Nigeria has 36 states plus the Federal Capital Territory (Abuja).",
  },
  {
    "what is the tallest building in the world": "The Burj Khalifa in Dubai, at about 828 meters.",
  },
  {
    "what is the largest planet": "Jupiter is the largest planet in our solar system.",
  },
  {
    "how many planets are in the solar system": "There are eight planets in our solar system.",
  },
  {
    "who is the father of computers": "Charles Babbage is often called the father of the computer.",
  },
  {
    "who created javascript": "Brendan Eich created JavaScript in 1995 while working at Netscape.",
  },
  {
    "who created python": "Guido van Rossum created Python.",
  },
  {
    "who created linux": "Linus Torvalds created the Linux kernel in 1991.",
  },
  {
    "who created the world wide web": "Tim Berners-Lee invented the World Wide Web.",
  },
  {
    "who founded microsoft": "Bill Gates and Paul Allen founded Microsoft.",
  },
  {
    "who founded apple": "Steve Jobs, Steve Wozniak, and Ronald Wayne founded Apple.",
  },
  {
    "who founded google": "Larry Page and Sergey Brin founded Google.",
  },
  {
    "who founded facebook": "Mark Zuckerberg co-founded Facebook, now part of Meta.",
  },
  {
    "who painted the starry night": "Vincent van Gogh painted The Starry Night.",
  },
  {
    "who wrote harry potter": "J.K. Rowling wrote the Harry Potter series.",
  },
  {
    "who wrote the lion king": "The Lion King is a Disney film, not a book, created by a team of Disney writers and artists.",
  },
  {
    "who discovered penicillin": "Alexander Fleming discovered penicillin in 1928.",
  },
  {
    "who developed the theory of relativity": "Albert Einstein developed the theory of relativity.",
  },
  {
    "who is known as the father of modern physics": "Albert Einstein and Isaac Newton are both often given that title. Newton for classical physics and Einstein for modern physics.",
  },
  {
    "what is photosynthesis": "Photosynthesis is how plants use sunlight, water, and carbon dioxide to make food and release oxygen.",
  },
  {
    "what is gravity": "Gravity is the force that pulls objects toward each other, like how Earth pulls things toward its center.",
  },
  {
    "what is an atom": "An atom is the smallest unit of an element, made of protons, neutrons, and electrons.",
  },
  {
    "what is dna": "DNA is the molecule that carries the genetic instructions for living things.",
  },
  {
    "what is the water cycle": "The water cycle is how water evaporates, forms clouds, falls as rain, and returns to oceans and rivers.",
  },
  {
    "what is a noun": "A noun is a word that names a person, place, thing, or idea.",
  },
  {
    "what is a verb": "A verb is a word that describes an action or state, like run or be.",
  },
  {
    "what is an adjective": "An adjective is a word that describes a noun, like big or happy.",
  },
  {
    "what is an adverb": "An adverb describes a verb, adjective, or another adverb, like quickly or very.",
  },
  {
    "what is a pronoun": "A pronoun replaces a noun, like he, she, or they.",
  },
  {
    "what is democracy": "Democracy is a system of government where citizens choose their leaders through voting.",
  },
  {
    "what is inflation": "Inflation is a general rise in prices over time, which reduces the purchasing power of money.",
  },
  {
    "what is gdp": "GDP (Gross Domestic Product) is the total value of goods and services produced in a country.",
  },
  {
    "what is a budget": "A budget is a plan for how you will earn, spend, and save your money.",
  },
  {
    "what is an entrepreneur": "An entrepreneur is someone who starts and runs a business, taking on financial risk.",
  },
  {
    "what is the internet": "The internet is a global network of connected computers that share information.",
  },
  {
    "what is a website": "A website is a collection of web pages accessible on the internet.",
  },
  {
    "what is social media": "Social media are online platforms where people share content and connect with others.",
  },
  {
    "what is email": "Email is a way to send digital messages over the internet.",
  },
  {
    "what is a computer": "A computer is a machine that follows instructions to process data and perform tasks.",
  },
  {
    "what is a smartphone": "A smartphone is a mobile phone that works like a small computer, with apps and internet access.",
  },
  {
    "how many days are in january": "January has 31 days.",
  },
  {
    "what month comes after january": "February comes after January.",
  },
  {
    "what month comes before january": "December comes before January.",
  },
  {
    "what is the 1st month of the year": "The 1st month is January.",
  },
  {
    "how many days are in february": "February has 28 days (29 in a leap year).",
  },
  {
    "what month comes after february": "March comes after February.",
  },
  {
    "what month comes before february": "January comes before February.",
  },
  {
    "what is the 2nd month of the year": "The 2nd month is February.",
  },
  {
    "how many days are in march": "March has 31 days.",
  },
  {
    "what month comes after march": "April comes after March.",
  },
  {
    "what month comes before march": "February comes before March.",
  },
  {
    "what is the 3rd month of the year": "The 3rd month is March.",
  },
  {
    "how many days are in april": "April has 30 days.",
  },
  {
    "what month comes after april": "May comes after April.",
  },
  {
    "what month comes before april": "March comes before April.",
  },
  {
    "what is the 4th month of the year": "The 4th month is April.",
  },
  {
    "how many days are in may": "May has 31 days.",
  },
  {
    "what month comes after may": "June comes after May.",
  },
  {
    "what month comes before may": "April comes before May.",
  },
  {
    "what is the 5th month of the year": "The 5th month is May.",
  },
  {
    "how many days are in june": "June has 30 days.",
  },
  {
    "what month comes after june": "July comes after June.",
  },
  {
    "what month comes before june": "May comes before June.",
  },
  {
    "what is the 6th month of the year": "The 6th month is June.",
  },
  {
    "how many days are in july": "July has 31 days.",
  },
  {
    "what month comes after july": "August comes after July.",
  },
  {
    "what month comes before july": "June comes before July.",
  },
  {
    "what is the 7th month of the year": "The 7th month is July.",
  },
  {
    "how many days are in august": "August has 31 days.",
  },
  {
    "what month comes after august": "September comes after August.",
  },
  {
    "what month comes before august": "July comes before August.",
  },
  {
    "what is the 8th month of the year": "The 8th month is August.",
  },
  {
    "how many days are in september": "September has 30 days.",
  },
  {
    "what month comes after september": "October comes after September.",
  },
  {
    "what month comes before september": "August comes before September.",
  },
  {
    "what is the 9th month of the year": "The 9th month is September.",
  },
  {
    "how many days are in october": "October has 31 days.",
  },
  {
    "what month comes after october": "November comes after October.",
  },
  {
    "what month comes before october": "September comes before October.",
  },
  {
    "what is the 10th month of the year": "The 10th month is October.",
  },
  {
    "how many days are in november": "November has 30 days.",
  },
  {
    "what month comes after november": "December comes after November.",
  },
  {
    "what month comes before november": "October comes before November.",
  },
  {
    "what is the 11th month of the year": "The 11th month is November.",
  },
  {
    "how many days are in december": "December has 31 days.",
  },
  {
    "what month comes after december": "January comes after December.",
  },
  {
    "what month comes before december": "November comes before December.",
  },
  {
    "what is the 12th month of the year": "The 12th month is December.",
  },
  {
    "what day comes after monday": "Tuesday comes after Monday.",
  },
  {
    "what day comes before monday": "Sunday comes before Monday.",
  },
  {
    "what day comes after tuesday": "Wednesday comes after Tuesday.",
  },
  {
    "what day comes before tuesday": "Monday comes before Tuesday.",
  },
  {
    "what day comes after wednesday": "Thursday comes after Wednesday.",
  },
  {
    "what day comes before wednesday": "Tuesday comes before Wednesday.",
  },
  {
    "what day comes after thursday": "Friday comes after Thursday.",
  },
  {
    "what day comes before thursday": "Wednesday comes before Thursday.",
  },
  {
    "what day comes after friday": "Saturday comes after Friday.",
  },
  {
    "what day comes before friday": "Thursday comes before Friday.",
  },
  {
    "what day comes after saturday": "Sunday comes after Saturday.",
  },
  {
    "what day comes before saturday": "Friday comes before Saturday.",
  },
  {
    "what day comes after sunday": "Monday comes after Sunday.",
  },
  {
    "what day comes before sunday": "Saturday comes before Sunday.",
  },
  {
    "how do you say hello in spanish": "Hello in Spanish is 'hola'.",
  },
  {
    "how do you say thank you in spanish": "Thank you in Spanish is 'gracias'.",
  },
  {
    "how do you say goodbye in spanish": "Goodbye in Spanish is 'adiós'.",
  },
  {
    "how do you say hello in french": "Hello in French is 'bonjour'.",
  },
  {
    "how do you say thank you in french": "Thank you in French is 'merci'.",
  },
  {
    "how do you say goodbye in french": "Goodbye in French is 'au revoir'.",
  },
  {
    "how do you say hello in german": "Hello in German is 'hallo'.",
  },
  {
    "how do you say thank you in german": "Thank you in German is 'danke'.",
  },
  {
    "how do you say goodbye in german": "Goodbye in German is 'auf Wiedersehen'.",
  },
  {
    "how do you say hello in italian": "Hello in Italian is 'ciao'.",
  },
  {
    "how do you say thank you in italian": "Thank you in Italian is 'grazie'.",
  },
  {
    "how do you say goodbye in italian": "Goodbye in Italian is 'arrivederci'.",
  },
  {
    "how do you say hello in portuguese": "Hello in Portuguese is 'olá'.",
  },
  {
    "how do you say thank you in portuguese": "Thank you in Portuguese is 'obrigado (or obrigada if you're a woman)'.",
  },
  {
    "how do you say goodbye in portuguese": "Goodbye in Portuguese is 'tchau'.",
  },
  {
    "how do you say hello in hausa": "Hello in Hausa is 'sannu'.",
  },
  {
    "how do you say thank you in hausa": "Thank you in Hausa is 'na gode'.",
  },
  {
    "how do you say goodbye in hausa": "Goodbye in Hausa is 'sai an jima'.",
  },
  {
    "how do you say hello in yoruba": "Hello in Yoruba is 'bawo ni'.",
  },
  {
    "how do you say thank you in yoruba": "Thank you in Yoruba is 'e se (ẹ ṣé)'.",
  },
  {
    "how do you say goodbye in yoruba": "Goodbye in Yoruba is 'o dabo (ó dàbọ̀)'.",
  },
  {
    "how do you say hello in igbo": "Hello in Igbo is 'ndewo'.",
  },
  {
    "how do you say thank you in igbo": "Thank you in Igbo is 'daalụ'.",
  },
  {
    "how do you say goodbye in igbo": "Goodbye in Igbo is 'ka chi bọ'.",
  },
  {
    "how do you say hello in swahili": "Hello in Swahili is 'jambo'.",
  },
  {
    "how do you say thank you in swahili": "Thank you in Swahili is 'asante'.",
  },
  {
    "how do you say goodbye in swahili": "Goodbye in Swahili is 'kwaheri'.",
  },
  {
    "how do you say hello in arabic": "Hello in Arabic is 'marhaba'.",
  },
  {
    "how do you say thank you in arabic": "Thank you in Arabic is 'shukran'.",
  },
  {
    "how do you say goodbye in arabic": "Goodbye in Arabic is 'ma'a as-salama'.",
  },
  {
    "how do you say hello in mandarin": "Hello in Mandarin is 'nǐ hǎo'.",
  },
  {
    "how do you say thank you in mandarin": "Thank you in Mandarin is 'xièxie'.",
  },
  {
    "how do you say goodbye in mandarin": "Goodbye in Mandarin is 'zàijiàn'.",
  },
  {
    "how do you say hello in japanese": "Hello in Japanese is 'konnichiwa'.",
  },
  {
    "how do you say thank you in japanese": "Thank you in Japanese is 'arigatō'.",
  },
  {
    "how do you say goodbye in japanese": "Goodbye in Japanese is 'sayōnara'.",
  },
  {
    "how do you say hello in korean": "Hello in Korean is 'annyeonghaseyo'.",
  },
  {
    "how do you say thank you in korean": "Thank you in Korean is 'gamsahamnida'.",
  },
  {
    "how do you say goodbye in korean": "Goodbye in Korean is 'annyeonghi gaseyo'.",
  },
  {
    "how do you say hello in hindi": "Hello in Hindi is 'namaste'.",
  },
  {
    "how do you say thank you in hindi": "Thank you in Hindi is 'dhanyavaad'.",
  },
  {
    "how do you say goodbye in hindi": "Goodbye in Hindi is 'alvida'.",
  },
  {
    "how do you say hello in russian": "Hello in Russian is 'privet'.",
  },
  {
    "how do you say thank you in russian": "Thank you in Russian is 'spasibo'.",
  },
  {
    "how do you say goodbye in russian": "Goodbye in Russian is 'do svidaniya'.",
  },
  {
    "how do you say hello in turkish": "Hello in Turkish is 'merhaba'.",
  },
  {
    "how do you say thank you in turkish": "Thank you in Turkish is 'teşekkür ederim'.",
  },
  {
    "how do you say goodbye in turkish": "Goodbye in Turkish is 'hoşça kal'.",
  },
  {
    "how do you say hello in dutch": "Hello in Dutch is 'hallo'.",
  },
  {
    "how do you say thank you in dutch": "Thank you in Dutch is 'dank je'.",
  },
  {
    "how do you say goodbye in dutch": "Goodbye in Dutch is 'tot ziens'.",
  },
  {
    "how do you say hello in swedish": "Hello in Swedish is 'hej'.",
  },
  {
    "how do you say thank you in swedish": "Thank you in Swedish is 'tack'.",
  },
  {
    "how do you say goodbye in swedish": "Goodbye in Swedish is 'hej då'.",
  },
  {
    "how do you say hello in greek": "Hello in Greek is 'yia sou'.",
  },
  {
    "how do you say thank you in greek": "Thank you in Greek is 'efcharistó'.",
  },
  {
    "how do you say goodbye in greek": "Goodbye in Greek is 'antío'.",
  },
  {
    "how do you say hello in polish": "Hello in Polish is 'cześć'.",
  },
  {
    "how do you say thank you in polish": "Thank you in Polish is 'dziękuję'.",
  },
  {
    "how do you say goodbye in polish": "Goodbye in Polish is 'do widzenia'.",
  },
  {
    "how do you say hello in hebrew": "Hello in Hebrew is 'shalom'.",
  },
  {
    "how do you say thank you in hebrew": "Thank you in Hebrew is 'toda'.",
  },
  {
    "how do you say goodbye in hebrew": "Goodbye in Hebrew is 'lehitraot'.",
  },
  {
    "how do you say hello in thai": "Hello in Thai is 'sawasdee'.",
  },
  {
    "how do you say thank you in thai": "Thank you in Thai is 'khop khun'.",
  },
  {
    "how do you say goodbye in thai": "Goodbye in Thai is 'laa gon'.",
  },
  {
    "how do you say hello in vietnamese": "Hello in Vietnamese is 'xin chào'.",
  },
  {
    "how do you say thank you in vietnamese": "Thank you in Vietnamese is 'cảm ơn'.",
  },
  {
    "how do you say goodbye in vietnamese": "Goodbye in Vietnamese is 'tạm biệt'.",
  },
  {
    "how do you say hello in indonesian": "Hello in Indonesian is 'halo'.",
  },
  {
    "how do you say thank you in indonesian": "Thank you in Indonesian is 'terima kasih'.",
  },
  {
    "how do you say goodbye in indonesian": "Goodbye in Indonesian is 'selamat tinggal'.",
  },
  {
    "how do you say hello in zulu": "Hello in Zulu is 'sawubona'.",
  },
  {
    "how do you say thank you in zulu": "Thank you in Zulu is 'ngiyabonga'.",
  },
  {
    "how do you say goodbye in zulu": "Goodbye in Zulu is 'hamba kahle'.",
  },
  {
    "how do you say hello in amharic": "Hello in Amharic is 'selam'.",
  },
  {
    "how do you say thank you in amharic": "Thank you in Amharic is 'amesegnalehu'.",
  },
  {
    "how do you say goodbye in amharic": "Goodbye in Amharic is 'dehna hun'.",
  },
  {
    "how do you say hello in filipino": "Hello in Filipino is 'kumusta'.",
  },
  {
    "how do you say thank you in filipino": "Thank you in Filipino is 'salamat'.",
  },
  {
    "how do you say goodbye in filipino": "Goodbye in Filipino is 'paalam'.",
  },
  {
    "how do you say hello in irish": "Hello in Irish is 'dia duit'.",
  },
  {
    "how do you say thank you in irish": "Thank you in Irish is 'go raibh maith agat'.",
  },
  {
    "how do you say goodbye in irish": "Goodbye in Irish is 'slán'.",
  },
  {
    "how do you say hello in latin": "Hello in Latin is 'salve'.",
  },
  {
    "how do you say thank you in latin": "Thank you in Latin is 'gratias tibi ago'.",
  },
  {
    "how do you say goodbye in latin": "Goodbye in Latin is 'vale'.",
  },
  {
    "coding tip 1": "Name variables clearly. Good names beat comments.",
  },
  {
    "give me coding tip number 1": "Name variables clearly. Good names beat comments.",
  },
  {
    "coding tip 2": "Commit small and often, with meaningful messages.",
  },
  {
    "give me coding tip number 2": "Commit small and often, with meaningful messages.",
  },
  {
    "coding tip 3": "Read error messages from the top. They usually tell you the file and line.",
  },
  {
    "give me coding tip number 3": "Read error messages from the top. They usually tell you the file and line.",
  },
  {
    "coding tip 4": "Don't repeat yourself. Pull repeated logic into a function.",
  },
  {
    "give me coding tip number 4": "Don't repeat yourself. Pull repeated logic into a function.",
  },
  {
    "coding tip 5": "Use const by default, let when you must reassign, and avoid var.",
  },
  {
    "give me coding tip number 5": "Use const by default, let when you must reassign, and avoid var.",
  },
  {
    "coding tip 6": "Use the debugger instead of scattering console.log everywhere, and clean up logs when you finish.",
  },
  {
    "give me coding tip number 6": "Use the debugger instead of scattering console.log everywhere, and clean up logs when you finish.",
  },
  {
    "coding tip 7": "Break big problems into small functions that each do one job.",
  },
  {
    "give me coding tip number 7": "Break big problems into small functions that each do one job.",
  },
  {
    "coding tip 8": "Write code for humans first and computers second.",
  },
  {
    "give me coding tip number 8": "Write code for humans first and computers second.",
  },
  {
    "coding tip 9": "Learn your editor's keyboard shortcuts. They save hours.",
  },
  {
    "give me coding tip number 9": "Learn your editor's keyboard shortcuts. They save hours.",
  },
  {
    "coding tip 10": "Use === instead of == in JavaScript to avoid surprising type coercion.",
  },
  {
    "give me coding tip number 10": "Use === instead of == in JavaScript to avoid surprising type coercion.",
  },
  {
    "coding tip 11": "Keep functions short and focused on a single task.",
  },
  {
    "give me coding tip number 11": "Keep functions short and focused on a single task.",
  },
  {
    "coding tip 12": "Test edge cases: empty input, null, very large values, and negative numbers.",
  },
  {
    "give me coding tip number 12": "Test edge cases: empty input, null, very large values, and negative numbers.",
  },
  {
    "coding tip 13": "Never commit secrets or API keys. Use environment variables instead.",
  },
  {
    "give me coding tip number 13": "Never commit secrets or API keys. Use environment variables instead.",
  },
  {
    "coding tip 14": "Use version control for every project, even small ones.",
  },
  {
    "give me coding tip number 14": "Use version control for every project, even small ones.",
  },
  {
    "coding tip 15": "Format your code automatically with a tool like Prettier.",
  },
  {
    "give me coding tip number 15": "Format your code automatically with a tool like Prettier.",
  },
  {
    "coding tip 16": "Use a linter such as ESLint to catch bugs early.",
  },
  {
    "give me coding tip number 16": "Use a linter such as ESLint to catch bugs early.",
  },
  {
    "coding tip 17": "Read the docs. MDN is a web developer's best friend.",
  },
  {
    "give me coding tip number 17": "Read the docs. MDN is a web developer's best friend.",
  },
  {
    "coding tip 18": "Explain your code to a rubber duck. You'll often find the bug while talking.",
  },
  {
    "give me coding tip number 18": "Explain your code to a rubber duck. You'll often find the bug while talking.",
  },
  {
    "coding tip 19": "Take a break when you're stuck. Fresh eyes spot bugs faster.",
  },
  {
    "give me coding tip number 19": "Take a break when you're stuck. Fresh eyes spot bugs faster.",
  },
  {
    "coding tip 20": "Build small projects to practice. Tutorials alone aren't enough.",
  },
  {
    "give me coding tip number 20": "Build small projects to practice. Tutorials alone aren't enough.",
  },
  {
    "coding tip 21": "Don't optimize too early. Make it work, make it right, then make it fast.",
  },
  {
    "give me coding tip number 21": "Don't optimize too early. Make it work, make it right, then make it fast.",
  },
  {
    "coding tip 22": "Handle errors with try/catch and give users helpful messages.",
  },
  {
    "give me coding tip number 22": "Handle errors with try/catch and give users helpful messages.",
  },
  {
    "coding tip 23": "Always validate user input.",
  },
  {
    "give me coding tip number 23": "Always validate user input.",
  },
  {
    "coding tip 24": "Use meaningful branch and commit names.",
  },
  {
    "give me coding tip number 24": "Use meaningful branch and commit names.",
  },
  {
    "coding tip 25": "Keep dependencies minimal and up to date.",
  },
  {
    "give me coding tip number 25": "Keep dependencies minimal and up to date.",
  },
  {
    "coding tip 26": "Learn map, filter, and reduce for working with arrays.",
  },
  {
    "give me coding tip number 26": "Learn map, filter, and reduce for working with arrays.",
  },
  {
    "coding tip 27": "Prefer early returns to deeply nested if statements.",
  },
  {
    "give me coding tip number 27": "Prefer early returns to deeply nested if statements.",
  },
  {
    "coding tip 28": "Be consistent with indentation and code style.",
  },
  {
    "give me coding tip number 28": "Be consistent with indentation and code style.",
  },
  {
    "coding tip 29": "Read other people's code to learn new patterns.",
  },
  {
    "give me coding tip number 29": "Read other people's code to learn new patterns.",
  },
  {
    "coding tip 30": "Learn Git branching. It makes experimenting safe.",
  },
  {
    "give me coding tip number 30": "Learn Git branching. It makes experimenting safe.",
  },
  {
    "coding tip 31": "Write a README so future you (and others) know how to run your project.",
  },
  {
    "give me coding tip number 31": "Write a README so future you (and others) know how to run your project.",
  },
  {
    "coding tip 32": "Avoid magic numbers. Give constants descriptive names.",
  },
  {
    "give me coding tip number 32": "Avoid magic numbers. Give constants descriptive names.",
  },
  {
    "coding tip 33": "Make small changes and test after each one.",
  },
  {
    "give me coding tip number 33": "Make small changes and test after each one.",
  },
  {
    "coding tip 34": "Search the exact error message. Someone has likely solved it already.",
  },
  {
    "give me coding tip number 34": "Search the exact error message. Someone has likely solved it already.",
  },
  {
    "coding tip 35": "Don't copy code you don't understand.",
  },
  {
    "give me coding tip number 35": "Don't copy code you don't understand.",
  },
  {
    "study tip 1": "Use the Pomodoro technique: 25 minutes of focus, then a 5-minute break.",
  },
  {
    "give me study tip number 1": "Use the Pomodoro technique: 25 minutes of focus, then a 5-minute break.",
  },
  {
    "study tip 2": "Test yourself instead of just rereading. Active recall beats passive review.",
  },
  {
    "give me study tip number 2": "Test yourself instead of just rereading. Active recall beats passive review.",
  },
  {
    "study tip 3": "Space out your study sessions rather than cramming.",
  },
  {
    "give me study tip number 3": "Space out your study sessions rather than cramming.",
  },
  {
    "study tip 4": "Teach the topic to someone else. If you can explain it, you know it.",
  },
  {
    "give me study tip number 4": "Teach the topic to someone else. If you can explain it, you know it.",
  },
  {
    "study tip 5": "Sleep well. Memory is consolidated while you rest.",
  },
  {
    "give me study tip number 5": "Sleep well. Memory is consolidated while you rest.",
  },
  {
    "study tip 6": "Plan your study time and stick to a schedule.",
  },
  {
    "give me study tip number 6": "Plan your study time and stick to a schedule.",
  },
  {
    "study tip 7": "Put your phone out of reach while you study.",
  },
  {
    "give me study tip number 7": "Put your phone out of reach while you study.",
  },
  {
    "study tip 8": "Summarize what you learn in your own words.",
  },
  {
    "give me study tip number 8": "Summarize what you learn in your own words.",
  },
  {
    "study tip 9": "Practice with past questions to learn the exam style.",
  },
  {
    "give me study tip number 9": "Practice with past questions to learn the exam style.",
  },
  {
    "study tip 10": "Study with a friend or group for motivation and different perspectives.",
  },
  {
    "give me study tip number 10": "Study with a friend or group for motivation and different perspectives.",
  },
  {
    "study tip 11": "Start with the hardest subject while your mind is fresh.",
  },
  {
    "give me study tip number 11": "Start with the hardest subject while your mind is fresh.",
  },
  {
    "study tip 12": "Study in short, focused sessions rather than one long marathon.",
  },
  {
    "give me study tip number 12": "Study in short, focused sessions rather than one long marathon.",
  },
  {
    "study tip 13": "Take handwritten notes. Writing helps memory.",
  },
  {
    "give me study tip number 13": "Take handwritten notes. Writing helps memory.",
  },
  {
    "study tip 14": "Review your notes within 24 hours of class.",
  },
  {
    "give me study tip number 14": "Review your notes within 24 hours of class.",
  },
  {
    "study tip 15": "Set specific goals, like 'finish chapter 3', instead of 'study'.",
  },
  {
    "give me study tip number 15": "Set specific goals, like 'finish chapter 3', instead of 'study'.",
  },
  {
    "study tip 16": "Stay hydrated and eat well. Your brain needs fuel.",
  },
  {
    "give me study tip number 16": "Stay hydrated and eat well. Your brain needs fuel.",
  },
  {
    "study tip 17": "Reward yourself after finishing a study goal.",
  },
  {
    "give me study tip number 17": "Reward yourself after finishing a study goal.",
  },
  {
    "study tip 18": "Mix up topics while practicing. It strengthens learning.",
  },
  {
    "give me study tip number 18": "Mix up topics while practicing. It strengthens learning.",
  },
  {
    "study tip 19": "Explain concepts out loud as if teaching a class.",
  },
  {
    "give me study tip number 19": "Explain concepts out loud as if teaching a class.",
  },
  {
    "study tip 20": "Use flashcards for facts, definitions, and formulas.",
  },
  {
    "give me study tip number 20": "Use flashcards for facts, definitions, and formulas.",
  },
  {
    "study tip 21": "Draw mind maps to connect ideas.",
  },
  {
    "give me study tip number 21": "Draw mind maps to connect ideas.",
  },
  {
    "study tip 22": "Avoid all-night cramming. It hurts memory and performance.",
  },
  {
    "give me study tip number 22": "Avoid all-night cramming. It hurts memory and performance.",
  },
  {
    "study tip 23": "Write your own practice questions.",
  },
  {
    "give me study tip number 23": "Write your own practice questions.",
  },
  {
    "study tip 24": "Find the time of day when you focus best and use it.",
  },
  {
    "give me study tip number 24": "Find the time of day when you focus best and use it.",
  },
  {
    "study tip 25": "Keep your study space tidy and well lit.",
  },
  {
    "give me study tip number 25": "Keep your study space tidy and well lit.",
  },
  {
    "life tip 1": "Drink water regularly throughout the day.",
  },
  {
    "give me life tip number 1": "Drink water regularly throughout the day.",
  },
  {
    "life tip 2": "Take a 10-minute walk. It clears your mind.",
  },
  {
    "give me life tip number 2": "Take a 10-minute walk. It clears your mind.",
  },
  {
    "life tip 3": "Aim for 7 to 9 hours of sleep each night.",
  },
  {
    "give me life tip number 3": "Aim for 7 to 9 hours of sleep each night.",
  },
  {
    "life tip 4": "Stretch for a few minutes every hour you sit.",
  },
  {
    "give me life tip number 4": "Stretch for a few minutes every hour you sit.",
  },
  {
    "life tip 5": "Try slow breathing: inhale for 4 seconds, exhale for 6.",
  },
  {
    "give me life tip number 5": "Try slow breathing: inhale for 4 seconds, exhale for 6.",
  },
  {
    "life tip 6": "Write down three things you're grateful for each day.",
  },
  {
    "give me life tip number 6": "Write down three things you're grateful for each day.",
  },
  {
    "life tip 7": "Avoid screens for 30 minutes before bed.",
  },
  {
    "give me life tip number 7": "Avoid screens for 30 minutes before bed.",
  },
  {
    "life tip 8": "Eat regular, balanced meals.",
  },
  {
    "give me life tip number 8": "Eat regular, balanced meals.",
  },
  {
    "life tip 9": "Talk to a friend or family member when you feel low.",
  },
  {
    "give me life tip number 9": "Talk to a friend or family member when you feel low.",
  },
  {
    "life tip 10": "Set healthy boundaries and protect your time.",
  },
  {
    "give me life tip number 10": "Set healthy boundaries and protect your time.",
  },
  {
    "life tip 11": "It's okay to say no.",
  },
  {
    "give me life tip number 11": "It's okay to say no.",
  },
  {
    "life tip 12": "Pick your top three priorities for the day.",
  },
  {
    "give me life tip number 12": "Pick your top three priorities for the day.",
  },
  {
    "life tip 13": "Take short breaks between tasks.",
  },
  {
    "give me life tip number 13": "Take short breaks between tasks.",
  },
  {
    "life tip 14": "Get some sunlight each day if you can.",
  },
  {
    "give me life tip number 14": "Get some sunlight each day if you can.",
  },
  {
    "life tip 15": "Tidy your space. A clear space helps a clear mind.",
  },
  {
    "give me life tip number 15": "Tidy your space. A clear space helps a clear mind.",
  },
  {
    "life tip 16": "Learn something new each week.",
  },
  {
    "give me life tip number 16": "Learn something new each week.",
  },
  {
    "life tip 17": "Keep small promises to yourself to build self-trust.",
  },
  {
    "give me life tip number 17": "Keep small promises to yourself to build self-trust.",
  },
  {
    "life tip 18": "Follow the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.",
  },
  {
    "give me life tip number 18": "Follow the 20-20-20 rule: every 20 minutes, look at something 20 feet away for 20 seconds.",
  },
  {
    "life tip 19": "Sit with your back supported and your feet flat on the floor.",
  },
  {
    "give me life tip number 19": "Sit with your back supported and your feet flat on the floor.",
  },
  {
    "life tip 20": "Keep a journal to sort out your thoughts.",
  },
  {
    "give me life tip number 20": "Keep a journal to sort out your thoughts.",
  },
  {
    "life tip 21": "Be as kind to yourself as you would be to a friend.",
  },
  {
    "give me life tip number 21": "Be as kind to yourself as you would be to a friend.",
  },
  {
    "life tip 22": "Celebrate small wins. They add up.",
  },
  {
    "give me life tip number 22": "Celebrate small wins. They add up.",
  },
  {
    "life tip 23": "Save a small amount regularly, even if it's tiny.",
  },
  {
    "give me life tip number 23": "Save a small amount regularly, even if it's tiny.",
  },
  {
    "life tip 24": "Take one day a week to unplug from social media.",
  },
  {
    "give me life tip number 24": "Take one day a week to unplug from social media.",
  },
  {
    "life tip 25": "Ask for help when you need it. It's a sign of strength.",
  },
  {
    "give me life tip number 25": "Ask for help when you need it. It's a sign of strength.",
  },
  {
    "give me a coding tip": "Name variables clearly. Good names beat comments.",
  },
  {
    "give me a study tip": "Use the Pomodoro technique: 25 minutes of focus, then a 5-minute break.",
  },
  {
    "give me a life tip": "Drink water regularly throughout the day.",
  },
  {
    "what is double 1": "Double 1 is 2.",
  },
  {
    "what is half of 1": "Half of 1 is 0.5.",
  },
  {
    "what is triple 1": "Triple 1 is 3.",
  },
  {
    "what is double 2": "Double 2 is 4.",
  },
  {
    "what is half of 2": "Half of 2 is 1.",
  },
  {
    "what is triple 2": "Triple 2 is 6.",
  },
  {
    "what is double 3": "Double 3 is 6.",
  },
  {
    "what is half of 3": "Half of 3 is 1.5.",
  },
  {
    "what is triple 3": "Triple 3 is 9.",
  },
  {
    "what is double 4": "Double 4 is 8.",
  },
  {
    "what is half of 4": "Half of 4 is 2.",
  },
  {
    "what is triple 4": "Triple 4 is 12.",
  },
  {
    "what is double 5": "Double 5 is 10.",
  },
  {
    "what is half of 5": "Half of 5 is 2.5.",
  },
  {
    "what is triple 5": "Triple 5 is 15.",
  },
  {
    "what is double 6": "Double 6 is 12.",
  },
  {
    "what is half of 6": "Half of 6 is 3.",
  },
  {
    "what is triple 6": "Triple 6 is 18.",
  },
  {
    "what is double 7": "Double 7 is 14.",
  },
  {
    "what is half of 7": "Half of 7 is 3.5.",
  },
  {
    "what is triple 7": "Triple 7 is 21.",
  },
  {
    "what is double 8": "Double 8 is 16.",
  },
  {
    "what is half of 8": "Half of 8 is 4.",
  },
  {
    "what is triple 8": "Triple 8 is 24.",
  },
  {
    "what is double 9": "Double 9 is 18.",
  },
  {
    "what is half of 9": "Half of 9 is 4.5.",
  },
  {
    "what is triple 9": "Triple 9 is 27.",
  },
  {
    "what is double 10": "Double 10 is 20.",
  },
  {
    "what is half of 10": "Half of 10 is 5.",
  },
  {
    "what is triple 10": "Triple 10 is 30.",
  },
  {
    "what is double 11": "Double 11 is 22.",
  },
  {
    "what is half of 11": "Half of 11 is 5.5.",
  },
  {
    "what is triple 11": "Triple 11 is 33.",
  },
  {
    "what is double 12": "Double 12 is 24.",
  },
  {
    "what is half of 12": "Half of 12 is 6.",
  },
  {
    "what is triple 12": "Triple 12 is 36.",
  },
  {
    "what is double 13": "Double 13 is 26.",
  },
  {
    "what is half of 13": "Half of 13 is 6.5.",
  },
  {
    "what is triple 13": "Triple 13 is 39.",
  },
  {
    "what is double 14": "Double 14 is 28.",
  },
  {
    "what is half of 14": "Half of 14 is 7.",
  },
  {
    "what is triple 14": "Triple 14 is 42.",
  },
  {
    "what is double 15": "Double 15 is 30.",
  },
  {
    "what is half of 15": "Half of 15 is 7.5.",
  },
  {
    "what is triple 15": "Triple 15 is 45.",
  },
  {
    "what is double 16": "Double 16 is 32.",
  },
  {
    "what is half of 16": "Half of 16 is 8.",
  },
  {
    "what is triple 16": "Triple 16 is 48.",
  },
  {
    "what is double 17": "Double 17 is 34.",
  },
  {
    "what is half of 17": "Half of 17 is 8.5.",
  },
  {
    "what is triple 17": "Triple 17 is 51.",
  },
  {
    "what is double 18": "Double 18 is 36.",
  },
  {
    "what is half of 18": "Half of 18 is 9.",
  },
  {
    "what is triple 18": "Triple 18 is 54.",
  },
  {
    "what is double 19": "Double 19 is 38.",
  },
  {
    "what is half of 19": "Half of 19 is 9.5.",
  },
  {
    "what is triple 19": "Triple 19 is 57.",
  },
  {
    "what is double 20": "Double 20 is 40.",
  },
  {
    "what is half of 20": "Half of 20 is 10.",
  },
  {
    "what is triple 20": "Triple 20 is 60.",
  },
  {
    "what is double 21": "Double 21 is 42.",
  },
  {
    "what is half of 21": "Half of 21 is 10.5.",
  },
  {
    "what is triple 21": "Triple 21 is 63.",
  },
  {
    "what is double 22": "Double 22 is 44.",
  },
  {
    "what is half of 22": "Half of 22 is 11.",
  },
  {
    "what is triple 22": "Triple 22 is 66.",
  },
  {
    "what is double 23": "Double 23 is 46.",
  },
  {
    "what is half of 23": "Half of 23 is 11.5.",
  },
  {
    "what is triple 23": "Triple 23 is 69.",
  },
  {
    "what is double 24": "Double 24 is 48.",
  },
  {
    "what is half of 24": "Half of 24 is 12.",
  },
  {
    "what is triple 24": "Triple 24 is 72.",
  },
  {
    "what is double 25": "Double 25 is 50.",
  },
  {
    "what is half of 25": "Half of 25 is 12.5.",
  },
  {
    "what is triple 25": "Triple 25 is 75.",
  },
  {
    "what is double 26": "Double 26 is 52.",
  },
  {
    "what is half of 26": "Half of 26 is 13.",
  },
  {
    "what is triple 26": "Triple 26 is 78.",
  },
  {
    "what is double 27": "Double 27 is 54.",
  },
  {
    "what is half of 27": "Half of 27 is 13.5.",
  },
  {
    "what is triple 27": "Triple 27 is 81.",
  },
  {
    "what is double 28": "Double 28 is 56.",
  },
  {
    "what is half of 28": "Half of 28 is 14.",
  },
  {
    "what is triple 28": "Triple 28 is 84.",
  },
  {
    "what is double 29": "Double 29 is 58.",
  },
  {
    "what is half of 29": "Half of 29 is 14.5.",
  },
  {
    "what is triple 29": "Triple 29 is 87.",
  },
  {
    "what is double 30": "Double 30 is 60.",
  },
  {
    "what is half of 30": "Half of 30 is 15.",
  },
  {
    "what is triple 30": "Triple 30 is 90.",
  },
  {
    "what is double 31": "Double 31 is 62.",
  },
  {
    "what is half of 31": "Half of 31 is 15.5.",
  },
  {
    "what is triple 31": "Triple 31 is 93.",
  },
  {
    "what is double 32": "Double 32 is 64.",
  },
  {
    "what is half of 32": "Half of 32 is 16.",
  },
  {
    "what is triple 32": "Triple 32 is 96.",
  },
  {
    "what is double 33": "Double 33 is 66.",
  },
  {
    "what is half of 33": "Half of 33 is 16.5.",
  },
  {
    "what is triple 33": "Triple 33 is 99.",
  },
  {
    "what is double 34": "Double 34 is 68.",
  },
  {
    "what is half of 34": "Half of 34 is 17.",
  },
  {
    "what is triple 34": "Triple 34 is 102.",
  },
  {
    "what is double 35": "Double 35 is 70.",
  },
  {
    "what is half of 35": "Half of 35 is 17.5.",
  },
  {
    "what is triple 35": "Triple 35 is 105.",
  },
  {
    "what is double 36": "Double 36 is 72.",
  },
  {
    "what is half of 36": "Half of 36 is 18.",
  },
  {
    "what is triple 36": "Triple 36 is 108.",
  },
  {
    "what is double 37": "Double 37 is 74.",
  },
  {
    "what is half of 37": "Half of 37 is 18.5.",
  },
  {
    "what is triple 37": "Triple 37 is 111.",
  },
  {
    "what is double 38": "Double 38 is 76.",
  },
  {
    "what is half of 38": "Half of 38 is 19.",
  },
  {
    "what is triple 38": "Triple 38 is 114.",
  },
  {
    "what is double 39": "Double 39 is 78.",
  },
  {
    "what is half of 39": "Half of 39 is 19.5.",
  },
  {
    "what is triple 39": "Triple 39 is 117.",
  },
  {
    "what is double 40": "Double 40 is 80.",
  },
  {
    "what is half of 40": "Half of 40 is 20.",
  },
  {
    "what is triple 40": "Triple 40 is 120.",
  },
  {
    "what is double 41": "Double 41 is 82.",
  },
  {
    "what is half of 41": "Half of 41 is 20.5.",
  },
  {
    "what is triple 41": "Triple 41 is 123.",
  },
  {
    "what is double 42": "Double 42 is 84.",
  },
  {
    "what is half of 42": "Half of 42 is 21.",
  },
  {
    "what is triple 42": "Triple 42 is 126.",
  },
  {
    "what is double 43": "Double 43 is 86.",
  },
  {
    "what is half of 43": "Half of 43 is 21.5.",
  },
  {
    "what is triple 43": "Triple 43 is 129.",
  },
  {
    "what is double 44": "Double 44 is 88.",
  },
  {
    "what is half of 44": "Half of 44 is 22.",
  },
  {
    "what is triple 44": "Triple 44 is 132.",
  },
  {
    "what is double 45": "Double 45 is 90.",
  },
  {
    "what is half of 45": "Half of 45 is 22.5.",
  },
  {
    "what is triple 45": "Triple 45 is 135.",
  },
  {
    "what is double 46": "Double 46 is 92.",
  },
  {
    "what is half of 46": "Half of 46 is 23.",
  },
  {
    "what is triple 46": "Triple 46 is 138.",
  },
  {
    "what is double 47": "Double 47 is 94.",
  },
  {
    "what is half of 47": "Half of 47 is 23.5.",
  },
  {
    "what is triple 47": "Triple 47 is 141.",
  },
  {
    "what is double 48": "Double 48 is 96.",
  },
  {
    "what is half of 48": "Half of 48 is 24.",
  },
  {
    "what is triple 48": "Triple 48 is 144.",
  },
  {
    "what is double 49": "Double 49 is 98.",
  },
  {
    "what is half of 49": "Half of 49 is 24.5.",
  },
  {
    "what is triple 49": "Triple 49 is 147.",
  },
  {
    "what is double 50": "Double 50 is 100.",
  },
  {
    "what is half of 50": "Half of 50 is 25.",
  },
  {
    "what is triple 50": "Triple 50 is 150.",
  },
  {
    "what is double 51": "Double 51 is 102.",
  },
  {
    "what is half of 51": "Half of 51 is 25.5.",
  },
  {
    "what is triple 51": "Triple 51 is 153.",
  },
  {
    "what is double 52": "Double 52 is 104.",
  },
  {
    "what is half of 52": "Half of 52 is 26.",
  },
  {
    "what is triple 52": "Triple 52 is 156.",
  },
  {
    "what is double 53": "Double 53 is 106.",
  },
  {
    "what is half of 53": "Half of 53 is 26.5.",
  },
  {
    "what is triple 53": "Triple 53 is 159.",
  },
  {
    "what is double 54": "Double 54 is 108.",
  },
  {
    "what is half of 54": "Half of 54 is 27.",
  },
  {
    "what is triple 54": "Triple 54 is 162.",
  },
  {
    "what is double 55": "Double 55 is 110.",
  },
  {
    "what is half of 55": "Half of 55 is 27.5.",
  },
  {
    "what is triple 55": "Triple 55 is 165.",
  },
  {
    "what is double 56": "Double 56 is 112.",
  },
  {
    "what is half of 56": "Half of 56 is 28.",
  },
  {
    "what is triple 56": "Triple 56 is 168.",
  },
  {
    "what is double 57": "Double 57 is 114.",
  },
  {
    "what is half of 57": "Half of 57 is 28.5.",
  },
  {
    "what is triple 57": "Triple 57 is 171.",
  },
  {
    "what is double 58": "Double 58 is 116.",
  },
  {
    "what is half of 58": "Half of 58 is 29.",
  },
  {
    "what is triple 58": "Triple 58 is 174.",
  },
  {
    "what is double 59": "Double 59 is 118.",
  },
  {
    "what is half of 59": "Half of 59 is 29.5.",
  },
  {
    "what is triple 59": "Triple 59 is 177.",
  },
  {
    "what is double 60": "Double 60 is 120.",
  },
  {
    "what is half of 60": "Half of 60 is 30.",
  },
  {
    "what is triple 60": "Triple 60 is 180.",
  },
  {
    "what is double 61": "Double 61 is 122.",
  },
  {
    "what is half of 61": "Half of 61 is 30.5.",
  },
  {
    "what is triple 61": "Triple 61 is 183.",
  },
  {
    "what is double 62": "Double 62 is 124.",
  },
  {
    "what is half of 62": "Half of 62 is 31.",
  },
  {
    "what is triple 62": "Triple 62 is 186.",
  },
  {
    "what is double 63": "Double 63 is 126.",
  },
  {
    "what is half of 63": "Half of 63 is 31.5.",
  },
  {
    "what is triple 63": "Triple 63 is 189.",
  },
  {
    "what is double 64": "Double 64 is 128.",
  },
  {
    "what is half of 64": "Half of 64 is 32.",
  },
  {
    "what is triple 64": "Triple 64 is 192.",
  },
  {
    "what is double 65": "Double 65 is 130.",
  },
  {
    "what is half of 65": "Half of 65 is 32.5.",
  },
  {
    "what is triple 65": "Triple 65 is 195.",
  },
  {
    "what is double 66": "Double 66 is 132.",
  },
  {
    "what is half of 66": "Half of 66 is 33.",
  },
  {
    "what is triple 66": "Triple 66 is 198.",
  },
  {
    "what is double 67": "Double 67 is 134.",
  },
  {
    "what is half of 67": "Half of 67 is 33.5.",
  },
  {
    "what is triple 67": "Triple 67 is 201.",
  },
  {
    "what is double 68": "Double 68 is 136.",
  },
  {
    "what is half of 68": "Half of 68 is 34.",
  },
  {
    "what is triple 68": "Triple 68 is 204.",
  },
  {
    "what is double 69": "Double 69 is 138.",
  },
  {
    "what is half of 69": "Half of 69 is 34.5.",
  },
  {
    "what is triple 69": "Triple 69 is 207.",
  },
  {
    "what is double 70": "Double 70 is 140.",
  },
  {
    "what is half of 70": "Half of 70 is 35.",
  },
  {
    "what is triple 70": "Triple 70 is 210.",
  },
  {
    "what is double 71": "Double 71 is 142.",
  },
  {
    "what is half of 71": "Half of 71 is 35.5.",
  },
  {
    "what is triple 71": "Triple 71 is 213.",
  },
  {
    "what is double 72": "Double 72 is 144.",
  },
  {
    "what is half of 72": "Half of 72 is 36.",
  },
  {
    "what is triple 72": "Triple 72 is 216.",
  },
  {
    "what is double 73": "Double 73 is 146.",
  },
  {
    "what is half of 73": "Half of 73 is 36.5.",
  },
  {
    "what is triple 73": "Triple 73 is 219.",
  },
  {
    "what is double 74": "Double 74 is 148.",
  },
  {
    "what is half of 74": "Half of 74 is 37.",
  },
  {
    "what is triple 74": "Triple 74 is 222.",
  },
  {
    "what is double 75": "Double 75 is 150.",
  },
  {
    "what is half of 75": "Half of 75 is 37.5.",
  },
  {
    "what is triple 75": "Triple 75 is 225.",
  },
  {
    "what is double 76": "Double 76 is 152.",
  },
  {
    "what is half of 76": "Half of 76 is 38.",
  },
  {
    "what is triple 76": "Triple 76 is 228.",
  },
  {
    "what is double 77": "Double 77 is 154.",
  },
  {
    "what is half of 77": "Half of 77 is 38.5.",
  },
  {
    "what is triple 77": "Triple 77 is 231.",
  },
  {
    "what is double 78": "Double 78 is 156.",
  },
  {
    "what is half of 78": "Half of 78 is 39.",
  },
  {
    "what is triple 78": "Triple 78 is 234.",
  },
  {
    "what is double 79": "Double 79 is 158.",
  },
  {
    "what is half of 79": "Half of 79 is 39.5.",
  },
  {
    "what is triple 79": "Triple 79 is 237.",
  },
  {
    "what is double 80": "Double 80 is 160.",
  },
  {
    "what is half of 80": "Half of 80 is 40.",
  },
  {
    "what is triple 80": "Triple 80 is 240.",
  },
  {
    "what is double 81": "Double 81 is 162.",
  },
  {
    "what is half of 81": "Half of 81 is 40.5.",
  },
  {
    "what is triple 81": "Triple 81 is 243.",
  },
  {
    "what is double 82": "Double 82 is 164.",
  },
  {
    "what is half of 82": "Half of 82 is 41.",
  },
  {
    "what is triple 82": "Triple 82 is 246.",
  },
  {
    "what is double 83": "Double 83 is 166.",
  },
  {
    "what is half of 83": "Half of 83 is 41.5.",
  },
  {
    "what is triple 83": "Triple 83 is 249.",
  },
  {
    "what is double 84": "Double 84 is 168.",
  },
  {
    "what is half of 84": "Half of 84 is 42.",
  },
  {
    "what is triple 84": "Triple 84 is 252.",
  },
  {
    "what is double 85": "Double 85 is 170.",
  },
  {
    "what is half of 85": "Half of 85 is 42.5.",
  },
  {
    "what is triple 85": "Triple 85 is 255.",
  },
  {
    "what is double 86": "Double 86 is 172.",
  },
  {
    "what is half of 86": "Half of 86 is 43.",
  },
  {
    "what is triple 86": "Triple 86 is 258.",
  },
  {
    "what is double 87": "Double 87 is 174.",
  },
  {
    "what is half of 87": "Half of 87 is 43.5.",
  },
  {
    "what is triple 87": "Triple 87 is 261.",
  },
  {
    "what is double 88": "Double 88 is 176.",
  },
  {
    "what is half of 88": "Half of 88 is 44.",
  },
  {
    "what is triple 88": "Triple 88 is 264.",
  },
  {
    "what is double 89": "Double 89 is 178.",
  },
  {
    "what is half of 89": "Half of 89 is 44.5.",
  },
  {
    "what is triple 89": "Triple 89 is 267.",
  },
  {
    "what is double 90": "Double 90 is 180.",
  },
  {
    "what is half of 90": "Half of 90 is 45.",
  },
  {
    "what is triple 90": "Triple 90 is 270.",
  },
  {
    "what is double 91": "Double 91 is 182.",
  },
  {
    "what is half of 91": "Half of 91 is 45.5.",
  },
  {
    "what is triple 91": "Triple 91 is 273.",
  },
  {
    "what is double 92": "Double 92 is 184.",
  },
  {
    "what is half of 92": "Half of 92 is 46.",
  },
  {
    "what is triple 92": "Triple 92 is 276.",
  },
  {
    "what is double 93": "Double 93 is 186.",
  },
  {
    "what is half of 93": "Half of 93 is 46.5.",
  },
  {
    "what is triple 93": "Triple 93 is 279.",
  },
  {
    "what is double 94": "Double 94 is 188.",
  },
  {
    "what is half of 94": "Half of 94 is 47.",
  },
  {
    "what is triple 94": "Triple 94 is 282.",
  },
  {
    "what is double 95": "Double 95 is 190.",
  },
  {
    "what is half of 95": "Half of 95 is 47.5.",
  },
  {
    "what is triple 95": "Triple 95 is 285.",
  },
  {
    "what is double 96": "Double 96 is 192.",
  },
  {
    "what is half of 96": "Half of 96 is 48.",
  },
  {
    "what is triple 96": "Triple 96 is 288.",
  },
  {
    "what is double 97": "Double 97 is 194.",
  },
  {
    "what is half of 97": "Half of 97 is 48.5.",
  },
  {
    "what is triple 97": "Triple 97 is 291.",
  },
  {
    "what is double 98": "Double 98 is 196.",
  },
  {
    "what is half of 98": "Half of 98 is 49.",
  },
  {
    "what is triple 98": "Triple 98 is 294.",
  },
  {
    "what is double 99": "Double 99 is 198.",
  },
  {
    "what is half of 99": "Half of 99 is 49.5.",
  },
  {
    "what is triple 99": "Triple 99 is 297.",
  },
  {
    "what is double 100": "Double 100 is 200.",
  },
  {
    "what is half of 100": "Half of 100 is 50.",
  },
  {
    "what is triple 100": "Triple 100 is 300.",
  },
  {
    "what is 5 percent of 10": "5 percent of 10 is 0.5.",
  },
  {
    "what is 5 percent of 20": "5 percent of 20 is 1.",
  },
  {
    "what is 5 percent of 30": "5 percent of 30 is 1.5.",
  },
  {
    "what is 5 percent of 40": "5 percent of 40 is 2.",
  },
  {
    "what is 5 percent of 50": "5 percent of 50 is 2.5.",
  },
  {
    "what is 5 percent of 60": "5 percent of 60 is 3.",
  },
  {
    "what is 5 percent of 70": "5 percent of 70 is 3.5.",
  },
  {
    "what is 5 percent of 80": "5 percent of 80 is 4.",
  },
  {
    "what is 5 percent of 90": "5 percent of 90 is 4.5.",
  },
  {
    "what is 5 percent of 100": "5 percent of 100 is 5.",
  },
  {
    "what is 5 percent of 110": "5 percent of 110 is 5.5.",
  },
  {
    "what is 5 percent of 120": "5 percent of 120 is 6.",
  },
  {
    "what is 5 percent of 130": "5 percent of 130 is 6.5.",
  },
  {
    "what is 5 percent of 140": "5 percent of 140 is 7.",
  },
  {
    "what is 5 percent of 150": "5 percent of 150 is 7.5.",
  },
  {
    "what is 5 percent of 160": "5 percent of 160 is 8.",
  },
  {
    "what is 5 percent of 170": "5 percent of 170 is 8.5.",
  },
  {
    "what is 5 percent of 180": "5 percent of 180 is 9.",
  },
  {
    "what is 5 percent of 190": "5 percent of 190 is 9.5.",
  },
  {
    "what is 5 percent of 200": "5 percent of 200 is 10.",
  },
  {
    "what is 5 percent of 210": "5 percent of 210 is 10.5.",
  },
  {
    "what is 5 percent of 220": "5 percent of 220 is 11.",
  },
  {
    "what is 5 percent of 230": "5 percent of 230 is 11.5.",
  },
  {
    "what is 5 percent of 240": "5 percent of 240 is 12.",
  },
  {
    "what is 5 percent of 250": "5 percent of 250 is 12.5.",
  },
  {
    "what is 5 percent of 260": "5 percent of 260 is 13.",
  },
  {
    "what is 5 percent of 270": "5 percent of 270 is 13.5.",
  },
  {
    "what is 5 percent of 280": "5 percent of 280 is 14.",
  },
  {
    "what is 5 percent of 290": "5 percent of 290 is 14.5.",
  },
  {
    "what is 5 percent of 300": "5 percent of 300 is 15.",
  },
  {
    "what is 5 percent of 310": "5 percent of 310 is 15.5.",
  },
  {
    "what is 5 percent of 320": "5 percent of 320 is 16.",
  },
  {
    "what is 5 percent of 330": "5 percent of 330 is 16.5.",
  },
  {
    "what is 5 percent of 340": "5 percent of 340 is 17.",
  },
  {
    "what is 5 percent of 350": "5 percent of 350 is 17.5.",
  },
  {
    "what is 5 percent of 360": "5 percent of 360 is 18.",
  },
  {
    "what is 5 percent of 370": "5 percent of 370 is 18.5.",
  },
  {
    "what is 5 percent of 380": "5 percent of 380 is 19.",
  },
  {
    "what is 5 percent of 390": "5 percent of 390 is 19.5.",
  },
  {
    "what is 5 percent of 400": "5 percent of 400 is 20.",
  },
  {
    "what is 5 percent of 410": "5 percent of 410 is 20.5.",
  },
  {
    "what is 5 percent of 420": "5 percent of 420 is 21.",
  },
  {
    "what is 5 percent of 430": "5 percent of 430 is 21.5.",
  },
  {
    "what is 5 percent of 440": "5 percent of 440 is 22.",
  },
  {
    "what is 5 percent of 450": "5 percent of 450 is 22.5.",
  },
  {
    "what is 5 percent of 460": "5 percent of 460 is 23.",
  },
  {
    "what is 5 percent of 470": "5 percent of 470 is 23.5.",
  },
  {
    "what is 5 percent of 480": "5 percent of 480 is 24.",
  },
  {
    "what is 5 percent of 490": "5 percent of 490 is 24.5.",
  },
  {
    "what is 5 percent of 500": "5 percent of 500 is 25.",
  },
  {
    "what is 5 percent of 510": "5 percent of 510 is 25.5.",
  },
  {
    "what is 5 percent of 520": "5 percent of 520 is 26.",
  },
  {
    "what is 5 percent of 530": "5 percent of 530 is 26.5.",
  },
  {
    "what is 5 percent of 540": "5 percent of 540 is 27.",
  },
  {
    "what is 5 percent of 550": "5 percent of 550 is 27.5.",
  },
  {
    "what is 5 percent of 560": "5 percent of 560 is 28.",
  },
  {
    "what is 5 percent of 570": "5 percent of 570 is 28.5.",
  },
  {
    "what is 5 percent of 580": "5 percent of 580 is 29.",
  },
  {
    "what is 5 percent of 590": "5 percent of 590 is 29.5.",
  },
  {
    "what is 5 percent of 600": "5 percent of 600 is 30.",
  },
  {
    "what is 5 percent of 610": "5 percent of 610 is 30.5.",
  },
  {
    "what is 5 percent of 620": "5 percent of 620 is 31.",
  },
  {
    "what is 5 percent of 630": "5 percent of 630 is 31.5.",
  },
  {
    "what is 5 percent of 640": "5 percent of 640 is 32.",
  },
  {
    "what is 5 percent of 650": "5 percent of 650 is 32.5.",
  },
  {
    "what is 5 percent of 660": "5 percent of 660 is 33.",
  },
  {
    "what is 5 percent of 670": "5 percent of 670 is 33.5.",
  },
  {
    "what is 5 percent of 680": "5 percent of 680 is 34.",
  },
  {
    "what is 5 percent of 690": "5 percent of 690 is 34.5.",
  },
  {
    "what is 5 percent of 700": "5 percent of 700 is 35.",
  },
  {
    "what is 5 percent of 710": "5 percent of 710 is 35.5.",
  },
  {
    "what is 5 percent of 720": "5 percent of 720 is 36.",
  },
  {
    "what is 5 percent of 730": "5 percent of 730 is 36.5.",
  },
  {
    "what is 5 percent of 740": "5 percent of 740 is 37.",
  },
  {
    "what is 5 percent of 750": "5 percent of 750 is 37.5.",
  },
  {
    "what is 5 percent of 760": "5 percent of 760 is 38.",
  },
  {
    "what is 5 percent of 770": "5 percent of 770 is 38.5.",
  },
  {
    "what is 5 percent of 780": "5 percent of 780 is 39.",
  },
  {
    "what is 5 percent of 790": "5 percent of 790 is 39.5.",
  },
  {
    "what is 5 percent of 800": "5 percent of 800 is 40.",
  },
  {
    "what is 5 percent of 810": "5 percent of 810 is 40.5.",
  },
  {
    "what is 5 percent of 820": "5 percent of 820 is 41.",
  },
  {
    "what is 5 percent of 830": "5 percent of 830 is 41.5.",
  },
  {
    "what is 5 percent of 840": "5 percent of 840 is 42.",
  },
  {
    "what is 5 percent of 850": "5 percent of 850 is 42.5.",
  },
  {
    "what is 5 percent of 860": "5 percent of 860 is 43.",
  },
  {
    "what is 5 percent of 870": "5 percent of 870 is 43.5.",
  },
  {
    "what is 5 percent of 880": "5 percent of 880 is 44.",
  },
  {
    "what is 5 percent of 890": "5 percent of 890 is 44.5.",
  },
  {
    "what is 5 percent of 900": "5 percent of 900 is 45.",
  },
  {
    "what is 5 percent of 910": "5 percent of 910 is 45.5.",
  },
  {
    "what is 5 percent of 920": "5 percent of 920 is 46.",
  },
  {
    "what is 5 percent of 930": "5 percent of 930 is 46.5.",
  },
  {
    "what is 5 percent of 940": "5 percent of 940 is 47.",
  },
  {
    "what is 5 percent of 950": "5 percent of 950 is 47.5.",
  },
  {
    "what is 5 percent of 960": "5 percent of 960 is 48.",
  },
  {
    "what is 5 percent of 970": "5 percent of 970 is 48.5.",
  },
  {
    "what is 5 percent of 980": "5 percent of 980 is 49.",
  },
  {
    "what is 5 percent of 990": "5 percent of 990 is 49.5.",
  },
  {
    "what is 5 percent of 1000": "5 percent of 1000 is 50.",
  },
  {
    "what is 5 percent of 1010": "5 percent of 1010 is 50.5.",
  },
  {
    "what is 5 percent of 1020": "5 percent of 1020 is 51.",
  },
  {
    "what is 5 percent of 1030": "5 percent of 1030 is 51.5.",
  },
  {
    "what is 5 percent of 1040": "5 percent of 1040 is 52.",
  },
  {
    "what is 5 percent of 1050": "5 percent of 1050 is 52.5.",
  },
  {
    "what is 5 percent of 1060": "5 percent of 1060 is 53.",
  },
  {
    "what is 5 percent of 1070": "5 percent of 1070 is 53.5.",
  },
  {
    "what is 5 percent of 1080": "5 percent of 1080 is 54.",
  },
  {
    "what is 5 percent of 1090": "5 percent of 1090 is 54.5.",
  },
  {
    "what is 5 percent of 1100": "5 percent of 1100 is 55.",
  },
  {
    "what is 5 percent of 1110": "5 percent of 1110 is 55.5.",
  },
  {
    "what is 5 percent of 1120": "5 percent of 1120 is 56.",
  },
  {
    "what is 5 percent of 1130": "5 percent of 1130 is 56.5.",
  },
  {
    "what is 5 percent of 1140": "5 percent of 1140 is 57.",
  },
  {
    "what is 5 percent of 1150": "5 percent of 1150 is 57.5.",
  },
  {
    "what is 5 percent of 1160": "5 percent of 1160 is 58.",
  },
  {
    "what is 5 percent of 1170": "5 percent of 1170 is 58.5.",
  },
  {
    "what is 5 percent of 1180": "5 percent of 1180 is 59.",
  },
  {
    "what is 5 percent of 1190": "5 percent of 1190 is 59.5.",
  },
  {
    "what is 5 percent of 1200": "5 percent of 1200 is 60.",
  },
  {
    "what is 5 percent of 1210": "5 percent of 1210 is 60.5.",
  },
  {
    "what is 5 percent of 1220": "5 percent of 1220 is 61.",
  },
  {
    "what is 5 percent of 1230": "5 percent of 1230 is 61.5.",
  },
  {
    "what is 5 percent of 1240": "5 percent of 1240 is 62.",
  },
  {
    "what is 5 percent of 1250": "5 percent of 1250 is 62.5.",
  },
  {
    "what is 5 percent of 1260": "5 percent of 1260 is 63.",
  },
  {
    "what is 5 percent of 1270": "5 percent of 1270 is 63.5.",
  },
  {
    "what is 5 percent of 1280": "5 percent of 1280 is 64.",
  },
  {
    "what is 5 percent of 1290": "5 percent of 1290 is 64.5.",
  },
  {
    "what is 5 percent of 1300": "5 percent of 1300 is 65.",
  },
  {
    "what is 5 percent of 1310": "5 percent of 1310 is 65.5.",
  },
  {
    "what is 5 percent of 1320": "5 percent of 1320 is 66.",
  },
  {
    "what is 5 percent of 1330": "5 percent of 1330 is 66.5.",
  },
  {
    "what is 5 percent of 1340": "5 percent of 1340 is 67.",
  },
  {
    "what is 5 percent of 1350": "5 percent of 1350 is 67.5.",
  },
  {
    "what is 5 percent of 1360": "5 percent of 1360 is 68.",
  },
  {
    "what is 5 percent of 1370": "5 percent of 1370 is 68.5.",
  },
  {
    "what is 5 percent of 1380": "5 percent of 1380 is 69.",
  },
  {
    "what is 5 percent of 1390": "5 percent of 1390 is 69.5.",
  },
  {
    "what is 5 percent of 1400": "5 percent of 1400 is 70.",
  },
  {
    "what is 5 percent of 1410": "5 percent of 1410 is 70.5.",
  },
  {
    "what is 5 percent of 1420": "5 percent of 1420 is 71.",
  },
  {
    "what is 5 percent of 1430": "5 percent of 1430 is 71.5.",
  },
  {
    "what is 5 percent of 1440": "5 percent of 1440 is 72.",
  },
  {
    "what is 5 percent of 1450": "5 percent of 1450 is 72.5.",
  },
  {
    "what is 5 percent of 1460": "5 percent of 1460 is 73.",
  },
  {
    "what is 5 percent of 1470": "5 percent of 1470 is 73.5.",
  },
  {
    "what is 5 percent of 1480": "5 percent of 1480 is 74.",
  },
  {
    "what is 5 percent of 1490": "5 percent of 1490 is 74.5.",
  },
  {
    "what is 5 percent of 1500": "5 percent of 1500 is 75.",
  },
  {
    "what is 5 percent of 1510": "5 percent of 1510 is 75.5.",
  },
  {
    "what is 5 percent of 1520": "5 percent of 1520 is 76.",
  },
  {
    "what is 5 percent of 1530": "5 percent of 1530 is 76.5.",
  },
  {
    "what is 5 percent of 1540": "5 percent of 1540 is 77.",
  },
  {
    "what is 5 percent of 1550": "5 percent of 1550 is 77.5.",
  },
  {
    "what is 5 percent of 1560": "5 percent of 1560 is 78.",
  },
  {
    "what is 5 percent of 1570": "5 percent of 1570 is 78.5.",
  },
  {
    "what is 5 percent of 1580": "5 percent of 1580 is 79.",
  },
  {
    "what is 5 percent of 1590": "5 percent of 1590 is 79.5.",
  },
  {
    "what is 5 percent of 1600": "5 percent of 1600 is 80.",
  },
  {
    "what is 5 percent of 1610": "5 percent of 1610 is 80.5.",
  },
  {
    "what is 5 percent of 1620": "5 percent of 1620 is 81.",
  },
  {
    "what is 5 percent of 1630": "5 percent of 1630 is 81.5.",
  },
  {
    "what is 5 percent of 1640": "5 percent of 1640 is 82.",
  },
  {
    "what is 5 percent of 1650": "5 percent of 1650 is 82.5.",
  },
  {
    "what is 5 percent of 1660": "5 percent of 1660 is 83.",
  },
  {
    "what is 5 percent of 1670": "5 percent of 1670 is 83.5.",
  },
  {
    "what is 5 percent of 1680": "5 percent of 1680 is 84.",
  },
  {
    "what is 5 percent of 1690": "5 percent of 1690 is 84.5.",
  },
  {
    "what is 5 percent of 1700": "5 percent of 1700 is 85.",
  },
  {
    "what is 5 percent of 1710": "5 percent of 1710 is 85.5.",
  },
  {
    "what is 5 percent of 1720": "5 percent of 1720 is 86.",
  },
  {
    "what is 5 percent of 1730": "5 percent of 1730 is 86.5.",
  },
  {
    "what is 5 percent of 1740": "5 percent of 1740 is 87.",
  },
  {
    "what is 5 percent of 1750": "5 percent of 1750 is 87.5.",
  },
  {
    "what is 5 percent of 1760": "5 percent of 1760 is 88.",
  },
  {
    "what is 5 percent of 1770": "5 percent of 1770 is 88.5.",
  },
  {
    "what is 5 percent of 1780": "5 percent of 1780 is 89.",
  },
  {
    "what is 5 percent of 1790": "5 percent of 1790 is 89.5.",
  },
  {
    "what is 5 percent of 1800": "5 percent of 1800 is 90.",
  },
  {
    "what is 5 percent of 1810": "5 percent of 1810 is 90.5.",
  },
  {
    "what is 5 percent of 1820": "5 percent of 1820 is 91.",
  },
  {
    "what is 5 percent of 1830": "5 percent of 1830 is 91.5.",
  },
  {
    "what is 5 percent of 1840": "5 percent of 1840 is 92.",
  },
  {
    "what is 5 percent of 1850": "5 percent of 1850 is 92.5.",
  },
  {
    "what is 5 percent of 1860": "5 percent of 1860 is 93.",
  },
  {
    "what is 5 percent of 1870": "5 percent of 1870 is 93.5.",
  },
  {
    "what is 5 percent of 1880": "5 percent of 1880 is 94.",
  },
  {
    "what is 5 percent of 1890": "5 percent of 1890 is 94.5.",
  },
  {
    "what is 5 percent of 1900": "5 percent of 1900 is 95.",
  },
  {
    "what is 5 percent of 1910": "5 percent of 1910 is 95.5.",
  },
  {
    "what is 5 percent of 1920": "5 percent of 1920 is 96.",
  },
  {
    "what is 5 percent of 1930": "5 percent of 1930 is 96.5.",
  },
  {
    "what is 5 percent of 1940": "5 percent of 1940 is 97.",
  },
  {
    "what is 5 percent of 1950": "5 percent of 1950 is 97.5.",
  },
  {
    "what is 5 percent of 1960": "5 percent of 1960 is 98.",
  },
  {
    "what is 5 percent of 1970": "5 percent of 1970 is 98.5.",
  },
  {
    "what is 5 percent of 1980": "5 percent of 1980 is 99.",
  },
  {
    "what is 5 percent of 1990": "5 percent of 1990 is 99.5.",
  },
  {
    "what is 10 percent of 10": "10 percent of 10 is 1.",
  },
  {
    "what is 10 percent of 20": "10 percent of 20 is 2.",
  },
  {
    "what is 10 percent of 30": "10 percent of 30 is 3.",
  },
  {
    "what is 10 percent of 40": "10 percent of 40 is 4.",
  },
  {
    "what is 10 percent of 50": "10 percent of 50 is 5.",
  },
  {
    "what is 10 percent of 60": "10 percent of 60 is 6.",
  },
  {
    "what is 10 percent of 70": "10 percent of 70 is 7.",
  },
  {
    "what is 10 percent of 80": "10 percent of 80 is 8.",
  },
  {
    "what is 10 percent of 90": "10 percent of 90 is 9.",
  },
  {
    "what is 10 percent of 100": "10 percent of 100 is 10.",
  },
  {
    "what is 10 percent of 110": "10 percent of 110 is 11.",
  },
  {
    "what is 10 percent of 120": "10 percent of 120 is 12.",
  },
  {
    "what is 10 percent of 130": "10 percent of 130 is 13.",
  },
  {
    "what is 10 percent of 140": "10 percent of 140 is 14.",
  },
  {
    "what is 10 percent of 150": "10 percent of 150 is 15.",
  },
  {
    "what is 10 percent of 160": "10 percent of 160 is 16.",
  },
  {
    "what is 10 percent of 170": "10 percent of 170 is 17.",
  },
  {
    "what is 10 percent of 180": "10 percent of 180 is 18.",
  },
  {
    "what is 10 percent of 190": "10 percent of 190 is 19.",
  },
  {
    "what is 10 percent of 200": "10 percent of 200 is 20.",
  },
  {
    "what is 10 percent of 210": "10 percent of 210 is 21.",
  },
  {
    "what is 10 percent of 220": "10 percent of 220 is 22.",
  },
  {
    "what is 10 percent of 230": "10 percent of 230 is 23.",
  },
  {
    "what is 10 percent of 240": "10 percent of 240 is 24.",
  },
  {
    "what is 10 percent of 250": "10 percent of 250 is 25.",
  },
  {
    "what is 10 percent of 260": "10 percent of 260 is 26.",
  },
  {
    "what is 10 percent of 270": "10 percent of 270 is 27.",
  },
  {
    "what is 10 percent of 280": "10 percent of 280 is 28.",
  },
  {
    "what is 10 percent of 290": "10 percent of 290 is 29.",
  },
  {
    "what is 10 percent of 300": "10 percent of 300 is 30.",
  },
  {
    "what is 10 percent of 310": "10 percent of 310 is 31.",
  },
  {
    "what is 10 percent of 320": "10 percent of 320 is 32.",
  },
  {
    "what is 10 percent of 330": "10 percent of 330 is 33.",
  },
  {
    "what is 10 percent of 340": "10 percent of 340 is 34.",
  },
  {
    "what is 10 percent of 350": "10 percent of 350 is 35.",
  },
  {
    "what is 10 percent of 360": "10 percent of 360 is 36.",
  },
  {
    "what is 10 percent of 370": "10 percent of 370 is 37.",
  },
  {
    "what is 10 percent of 380": "10 percent of 380 is 38.",
  },
  {
    "what is 10 percent of 390": "10 percent of 390 is 39.",
  },
  {
    "what is 10 percent of 400": "10 percent of 400 is 40.",
  },
  {
    "what is 10 percent of 410": "10 percent of 410 is 41.",
  },
  {
    "what is 10 percent of 420": "10 percent of 420 is 42.",
  },
  {
    "what is 10 percent of 430": "10 percent of 430 is 43.",
  },
  {
    "what is 10 percent of 440": "10 percent of 440 is 44.",
  },
  {
    "what is 10 percent of 450": "10 percent of 450 is 45.",
  },
  {
    "what is 10 percent of 460": "10 percent of 460 is 46.",
  },
  {
    "what is 10 percent of 470": "10 percent of 470 is 47.",
  },
  {
    "what is 10 percent of 480": "10 percent of 480 is 48.",
  },
  {
    "what is 10 percent of 490": "10 percent of 490 is 49.",
  },
  {
    "what is 10 percent of 500": "10 percent of 500 is 50.",
  },
  {
    "what is 10 percent of 510": "10 percent of 510 is 51.",
  },
  {
    "what is 10 percent of 520": "10 percent of 520 is 52.",
  },
  {
    "what is 10 percent of 530": "10 percent of 530 is 53.",
  },
  {
    "what is 10 percent of 540": "10 percent of 540 is 54.",
  },
  {
    "what is 10 percent of 550": "10 percent of 550 is 55.",
  },
  {
    "what is 10 percent of 560": "10 percent of 560 is 56.",
  },
  {
    "what is 10 percent of 570": "10 percent of 570 is 57.",
  },
  {
    "what is 10 percent of 580": "10 percent of 580 is 58.",
  },
  {
    "what is 10 percent of 590": "10 percent of 590 is 59.",
  },
  {
    "what is 10 percent of 600": "10 percent of 600 is 60.",
  },
  {
    "what is 10 percent of 610": "10 percent of 610 is 61.",
  },
  {
    "what is 10 percent of 620": "10 percent of 620 is 62.",
  },
  {
    "what is 10 percent of 630": "10 percent of 630 is 63.",
  },
  {
    "what is 10 percent of 640": "10 percent of 640 is 64.",
  },
  {
    "what is 10 percent of 650": "10 percent of 650 is 65.",
  },
  {
    "what is 10 percent of 660": "10 percent of 660 is 66.",
  },
  {
    "what is 10 percent of 670": "10 percent of 670 is 67.",
  },
  {
    "what is 10 percent of 680": "10 percent of 680 is 68.",
  },
  {
    "what is 10 percent of 690": "10 percent of 690 is 69.",
  },
  {
    "what is 10 percent of 700": "10 percent of 700 is 70.",
  },
  {
    "what is 10 percent of 710": "10 percent of 710 is 71.",
  },
  {
    "what is 10 percent of 720": "10 percent of 720 is 72.",
  },
  {
    "what is 10 percent of 730": "10 percent of 730 is 73.",
  },
  {
    "what is 10 percent of 740": "10 percent of 740 is 74.",
  },
  {
    "what is 10 percent of 750": "10 percent of 750 is 75.",
  },
  {
    "what is 10 percent of 760": "10 percent of 760 is 76.",
  },
  {
    "what is 10 percent of 770": "10 percent of 770 is 77.",
  },
  {
    "what is 10 percent of 780": "10 percent of 780 is 78.",
  },
  {
    "what is 10 percent of 790": "10 percent of 790 is 79.",
  },
  {
    "what is 10 percent of 800": "10 percent of 800 is 80.",
  },
  {
    "what is 10 percent of 810": "10 percent of 810 is 81.",
  },
  {
    "what is 10 percent of 820": "10 percent of 820 is 82.",
  },
  {
    "what is 10 percent of 830": "10 percent of 830 is 83.",
  },
  {
    "what is 10 percent of 840": "10 percent of 840 is 84.",
  },
  {
    "what is 10 percent of 850": "10 percent of 850 is 85.",
  },
  {
    "what is 10 percent of 860": "10 percent of 860 is 86.",
  },
  {
    "what is 10 percent of 870": "10 percent of 870 is 87.",
  },
  {
    "what is 10 percent of 880": "10 percent of 880 is 88.",
  },
  {
    "what is 10 percent of 890": "10 percent of 890 is 89.",
  },
  {
    "what is 10 percent of 900": "10 percent of 900 is 90.",
  },
  {
    "what is 10 percent of 910": "10 percent of 910 is 91.",
  },
  {
    "what is 10 percent of 920": "10 percent of 920 is 92.",
  },
  {
    "what is 10 percent of 930": "10 percent of 930 is 93.",
  },
  {
    "what is 10 percent of 940": "10 percent of 940 is 94.",
  },
  {
    "what is 10 percent of 950": "10 percent of 950 is 95.",
  },
  {
    "what is 10 percent of 960": "10 percent of 960 is 96.",
  },
  {
    "what is 10 percent of 970": "10 percent of 970 is 97.",
  },
  {
    "what is 10 percent of 980": "10 percent of 980 is 98.",
  },
  {
    "what is 10 percent of 990": "10 percent of 990 is 99.",
  },
  {
    "what is 10 percent of 1000": "10 percent of 1000 is 100.",
  },
  {
    "what is 10 percent of 1010": "10 percent of 1010 is 101.",
  },
  {
    "what is 10 percent of 1020": "10 percent of 1020 is 102.",
  },
  {
    "what is 10 percent of 1030": "10 percent of 1030 is 103.",
  },
  {
    "what is 10 percent of 1040": "10 percent of 1040 is 104.",
  },
  {
    "what is 10 percent of 1050": "10 percent of 1050 is 105.",
  },
  {
    "what is 10 percent of 1060": "10 percent of 1060 is 106.",
  },
  {
    "what is 10 percent of 1070": "10 percent of 1070 is 107.",
  },
  {
    "what is 10 percent of 1080": "10 percent of 1080 is 108.",
  },
  {
    "what is 10 percent of 1090": "10 percent of 1090 is 109.",
  },
  {
    "what is 10 percent of 1100": "10 percent of 1100 is 110.",
  },
  {
    "what is 10 percent of 1110": "10 percent of 1110 is 111.",
  },
  {
    "what is 10 percent of 1120": "10 percent of 1120 is 112.",
  },
  {
    "what is 10 percent of 1130": "10 percent of 1130 is 113.",
  },
  {
    "what is 10 percent of 1140": "10 percent of 1140 is 114.",
  },
  {
    "what is 10 percent of 1150": "10 percent of 1150 is 115.",
  },
  {
    "what is 10 percent of 1160": "10 percent of 1160 is 116.",
  },
  {
    "what is 10 percent of 1170": "10 percent of 1170 is 117.",
  },
  {
    "what is 10 percent of 1180": "10 percent of 1180 is 118.",
  },
  {
    "what is 10 percent of 1190": "10 percent of 1190 is 119.",
  },
  {
    "what is 10 percent of 1200": "10 percent of 1200 is 120.",
  },
  {
    "what is 10 percent of 1210": "10 percent of 1210 is 121.",
  },
  {
    "what is 10 percent of 1220": "10 percent of 1220 is 122.",
  },
  {
    "what is 10 percent of 1230": "10 percent of 1230 is 123.",
  },
  {
    "what is 10 percent of 1240": "10 percent of 1240 is 124.",
  },
  {
    "what is 10 percent of 1250": "10 percent of 1250 is 125.",
  },
  {
    "what is 10 percent of 1260": "10 percent of 1260 is 126.",
  },
  {
    "what is 10 percent of 1270": "10 percent of 1270 is 127.",
  },
  {
    "what is 10 percent of 1280": "10 percent of 1280 is 128.",
  },
  {
    "what is 10 percent of 1290": "10 percent of 1290 is 129.",
  },
  {
    "what is 10 percent of 1300": "10 percent of 1300 is 130.",
  },
  {
    "what is 10 percent of 1310": "10 percent of 1310 is 131.",
  },
  {
    "default": "I'm not quite sure how to respond to that yet. Can you try asking me something else, or rephrase your question?",
  },
];

export default responsesObj;