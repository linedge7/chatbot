import React from "react";
import "./exercise.css";
import dayjs from "../../../lib/day.js";
function Exercise_2() {
  function LoginForm() {
    const [showPassword, setShowPassword] = React.useState(false);

    const [time, setTime] = React.useState();
    setInterval(()=>{
      setTime(dayjs().format("HH:mm:ss"))
    },1000)

    function passwordReadable() {
      if (showPassword) {
        setShowPassword(false);
      } else {
        setShowPassword(true);
      }
    }
    return (
      <>
        <div className="title-container">
          <p className="title">Hello, welcome to my website</p>
          <p className="time">TIME: {time}</p>
        </div>
        <input placeholder="Email" className="input-text" />

        <div>
          <input
            placeholder="Password"
            type={showPassword ? "text" : "password"}
            className={`input-password`}
          />
          <button className="hide" onClick={passwordReadable}>
            {showPassword ? "Hide" : "Show"}
          </button>
        </div>

        <button className="login">Login</button>
        <button className="sign-up">Sign up</button>
      </>
    );
  }
  function E_commerce({ product, price, discount, imageSrc }) {
    return (
      <div className="product-container">
        <img src={imageSrc} alt="" className="product-img"/>
        <p>{product}</p>
        {discount ? <del>Price: {price}</del> : <p>Price: ${price}</p>}
        <p>Discount price: ${discount ? discount : 0}</p>
        <button>Add to Cart</button>
      </div>
    );
  }
  return (
    <>
      <LoginForm />
      <hr />
      <E_commerce
        product="Cotton socks"
        price={(10.9).toFixed(2)}
        discount={(5.45).toFixed(2)}
        imageSrc="cotton-socks.jpg"
      />
      <E_commerce
        product="Tennis balls"
        price={(6.0).toFixed(2)}
        imageSrc="basketball.jpg"
      />
      <E_commerce
        price={(7.99).toFixed(2)}
        product="Plain T-Shirt"
        imageSrc="plain-tshirt.jpg"
      />
    </>
  );
}

export function Exercise() {
  return (
    <>
      <Exercise_2 />
    </>
  );
}
