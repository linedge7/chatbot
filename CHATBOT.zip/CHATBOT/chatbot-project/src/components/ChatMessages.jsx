import { useEffect, useRef } from "react";
import ChatMessage from "./ChatMessage.jsx";
import "./styles/ChatMessages.css";

function ChatMessages({ chatMessages }) {
  function useAutoScroll(chatMessages) {
    const chatMessagesRef = useRef(null);

    useEffect(() => {
      const containerElem = chatMessagesRef.current;

      if (containerElem) {
        containerElem.scrollTop = containerElem.scrollHeight;
      }
    }, [chatMessages]);
    return chatMessagesRef;
  }

  return (
    <div className="chat-messages-container" ref={useAutoScroll(chatMessages)}>
      {chatMessages.map((chatMessage) => {
        return (
          <ChatMessage
            message={chatMessage.message}
            sender={chatMessage.sender}
            key={chatMessage.id}
          />
        );
      })}
    </div>
  );
}

export default ChatMessages;
