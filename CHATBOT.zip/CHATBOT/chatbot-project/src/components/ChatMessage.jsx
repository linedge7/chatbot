import RobotProfileImage from "../assets/robot.jpeg";
import UserProfileImage from "../assets/user.jpeg";
import "./styles/ChatMessage.css";
import dayjs from "dayjs";

function ChatMessage({ message, sender }) {
  return (
    <div
      className={sender === "user" ? "chat-message-user" : "chat-message-robot"}
    >
      {sender === "user" && <img className="profile" src={UserProfileImage} />}
      <div className="chat-message-text">
        {message}
        <div className="time">{dayjs().format("h:mma")}</div>
      </div>

      {sender === "robot" && (
        <img className="profile" src={RobotProfileImage} />
      )}
    </div>
  );
}

export default ChatMessage;
