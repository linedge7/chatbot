import { useState } from "react";
import { Chatbot } from "supersimpledev";
import "./styles/ChatInPut.css";

function ChatInPut({ setChatmessages, chatMessages }) {
  const [inputText, setInputText] = useState("");

  function saveInputText(event) {
    setInputText(event.target.value);
  }
  function SendMessage() {
    const newChatMessage = [
      ...chatMessages,
      {
        message: inputText,
        sender: "user",
        id: crypto.randomUUID(),
      },
    ];

    setChatmessages(newChatMessage);
    const response = Chatbot.getResponse(inputText);
    setChatmessages([
      ...newChatMessage,
      {
        message: response,
        sender: "robot",
        id: crypto.randomUUID(),
      },
    ]);
    setInputText("");
  }

  function sendMessageWithEnterKey(event) {
    if (event.key === "Enter") {
      SendMessage();
    } else if (event.key === "Escape") {
      setInputText("");
    }
  }

  return (
    <div className="chat-input-container">
      <input
        placeholder="Send a message to Chatbot"
        size={30}
        onChange={saveInputText}
        value={inputText}
        onKeyDown={sendMessageWithEnterKey}
        className="chat-input"
      />
      <button className="send-button" onClick={SendMessage}>
        Send
      </button>
    </div>
  );
}

export default ChatInPut;
